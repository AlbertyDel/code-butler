import { fakerRU as faker } from '@faker-js/faker';

// Seed faker to ensure deterministic user profile data
faker.seed(2026);

export interface UserProfile {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  language: string;
  mode: string;
}

// Default operator profile. This data persists across sessions.
export const defaultUser: UserProfile = {
  id: faker.string.uuid(),
  name: faker.person.fullName(),
  company: faker.company.name(),
  email: faker.internet.email(),
  phone: faker.phone.number(),
  language: 'ru',
  mode: 'Коммерческий',
};
