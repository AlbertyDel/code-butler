import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import { ModeProvider } from './contexts/ModeContext';
import { UserProvider } from './contexts/UserContext';
import { TariffProvider } from './contexts/TariffContext';
import { FinanceProvider } from './contexts/FinanceContext';
import { ToastProvider } from './components/ui/ToastContext';
import { ResponsiveLayout } from './components/layout/ResponsiveLayout';
import { useMode } from './contexts/useMode';

// Lazy load pages for code splitting
const Dashboard = lazy(() => import('./pages/Dashboard').then(module => ({ default: module.Dashboard })));
const Stations = lazy(() => import('./pages/Stations').then(module => ({ default: module.Stations })));
const Sessions = lazy(() => import('./pages/Sessions').then(module => ({ default: module.Sessions })));
const Tariffs = lazy(() => import('./pages/Tariffs').then(module => ({ default: module.Tariffs })));
const Finance = lazy(() => import('./pages/Finance').then(module => ({ default: module.Finance })));
const Profile = lazy(() => import('./pages/Profile').then(module => ({ default: module.Profile })));
const UIShowcase = lazy(() => import('./pages/UIShowcase').then(module => ({ default: module.default })));

// Loading fallback component
const PageLoading = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="text-center">
      <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-brand border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
      <p className="mt-4 text-muted">Загрузка...</p>
    </div>
  </div>
);

// Protected route component
const ProtectedRoute: React.FC<{ 
  children: React.ReactNode; 
  allowedModes: ('personal' | 'commercial')[] 
}> = ({ children, allowedModes }) => {
  const { mode } = useMode();
  
  if (!allowedModes.includes(mode)) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <ToastProvider>
      <UserProvider>
        <ModeProvider>
          <TariffProvider>
            <FinanceProvider>
              <Router>
                <ResponsiveLayout>
                  <Suspense fallback={<PageLoading />}>
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/stations" element={<Stations />} />
                      <Route path="/sessions" element={<Sessions />} />
                      <Route path="/tariffs" element={
                        <ProtectedRoute allowedModes={['commercial']}>
                          <Tariffs />
                        </ProtectedRoute>
                      } />
                      <Route path="/finance" element={
                        <ProtectedRoute allowedModes={['commercial']}>
                          <Finance />
                        </ProtectedRoute>
                      } />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/ui-showcase" element={<UIShowcase />} />
                    </Routes>
                  </Suspense>
                </ResponsiveLayout>
              </Router>
            </FinanceProvider>
          </TariffProvider>
        </ModeProvider>
      </UserProvider>
    </ToastProvider>
  );
}

export default App;
