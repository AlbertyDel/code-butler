import React, { useState } from 'react';
import { ChevronUp, ChevronDown, Plus, Trash2, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import type { 
  TariffFormData, 
  TariffRule
} from '../../types/tariff';
import { 
  WEEK_DAYS, 
  generateRuleId, 
  validateTimeRange,
  checkRuleOverlap,
  formatRuleDescription 
} from '../../types/tariff';

interface TariffFormProps {
  isExpanded: boolean;
  onToggleExpand: () => void;
  onSubmit: (tariffData: TariffFormData) => void;
  initialData?: TariffFormData | null;
  existingNames: string[];
  mode: 'create' | 'edit';
}

export const TariffForm: React.FC<TariffFormProps> = ({
  isExpanded,
  onToggleExpand,
  onSubmit,
  initialData,
  existingNames,
  mode,
}) => {
  const [formData, setFormData] = useState<TariffFormData>(() => {
    if (initialData) {
      return initialData;
    }
    return {
      name: '',
      description: '',
      basePricePerKwh: 25, // Changed from 30 to 25 as requested
      rules: [],
      sessionLimits: {
        maxTime: 0,
        maxEnergy: 0,
      },
    };
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ruleErrors, setRuleErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert any rule with empty days array to 'all' days
    const processedFormData = {
      ...formData,
      rules: formData.rules.map(rule => ({
        ...rule,
        days: rule.days === 'all' || rule.days.length > 0 ? rule.days : 'all'
      }))
    };
    
    const newErrors: Record<string, string> = {};

    // Валидация названия
    if (!processedFormData.name.trim()) {
      newErrors.name = 'Название обязательно';
    } else if (initialData?.name !== processedFormData.name && existingNames.includes(processedFormData.name)) {
      newErrors.name = 'Тариф с таким названием уже существует';
    }

    // Валидация описания
    if (!processedFormData.description.trim()) {
      newErrors.description = 'Описание обязательно';
    }

    // Валидация базовой стоимости
    if (processedFormData.basePricePerKwh < 0) {
      newErrors.basePricePerKwh = 'Стоимость не может быть отрицательной';
    }

    // Валидация правил
    const newRuleErrors: Record<string, string> = {};
    processedFormData.rules.forEach((rule, index) => {
      if (rule.days.length === 0) { // Only show error for empty array, not for 'all'
        newRuleErrors[`rule_${index}_days`] = 'Выберите хотя бы один день';
      }
      if (!validateTimeRange(rule.startTime, rule.endTime)) {
        newRuleErrors[`rule_${index}_time`] = 'Время начала должно быть раньше времени окончания';
      }
      if (rule.pricePerKwh < 0) {
        newRuleErrors[`rule_${index}_price`] = 'Стоимость не может быть отрицательной';
      }
    });

    // Проверка пересечений правил
    const overlappingRules: number[] = [];
    processedFormData.rules.forEach((rule1, i) => {
      processedFormData.rules.forEach((rule2, j) => {
        if (i !== j && checkRuleOverlap(rule1, rule2)) {
          overlappingRules.push(i, j);
        }
      });
    });

    if (overlappingRules.length > 0) {
      newErrors.rules = 'Обнаружены пересекающиеся правила';
    }

    setErrors(newErrors);
    setRuleErrors(newRuleErrors);

    if (Object.keys(newErrors).length === 0 && Object.keys(newRuleErrors).length === 0) {
      onSubmit(processedFormData);
      // Форма не сворачивается автоматически - оставляем решение родительскому компоненту
    }
  };

  const addRule = () => {
    setFormData(prev => {
      const newRule: TariffRule = {
        id: generateRuleId(),
        days: 'all',
        startTime: '08:00',
        endTime: '17:00',
        pricePerKwh: prev.basePricePerKwh,
      };
      return {
        ...prev,
        rules: [...prev.rules, newRule],
      };
    });
  };

  const updateRule = (index: number, field: keyof TariffRule, value: string | number | 'all' | number[]) => {
    setFormData(prev => {
      const newRules = [...prev.rules];
      newRules[index] = { ...newRules[index], [field]: value };
      return { ...prev, rules: newRules };
    });
    
    // Очистка ошибок для этого правила
    if (ruleErrors[`rule_${index}_${field}`]) {
      const newRuleErrors = { ...ruleErrors };
      delete newRuleErrors[`rule_${index}_${field}`];
      setRuleErrors(newRuleErrors);
    }
  };

  const deleteRule = (index: number) => {
    setFormData(prev => ({
      ...prev,
      rules: prev.rules.filter((_, i) => i !== index)
    }));
    
    // Очистка ошибок для удаленного правила
    const newRuleErrors = { ...ruleErrors };
    Object.keys(newRuleErrors).forEach(key => {
      if (key.startsWith(`rule_${index}_`)) {
        delete newRuleErrors[key];
      }
    });
    setRuleErrors(newRuleErrors);
  };

  const toggleDay = (ruleIndex: number, dayId: number) => {
    setFormData(prev => {
      const rule = prev.rules[ruleIndex];
      if (rule.days === 'all') return prev;
      
      const newDays = rule.days.includes(dayId)
        ? rule.days.filter(d => d !== dayId)
        : [...rule.days, dayId];
      
      const newRules = [...prev.rules];
      newRules[ruleIndex] = { ...rule, days: newDays };
      return { ...prev, rules: newRules };
    });
  };

  const toggleAllDays = (ruleIndex: number) => {
    setFormData(prev => {
      const rule = prev.rules[ruleIndex];
      const newRules = [...prev.rules];
      newRules[ruleIndex] = { ...rule, days: rule.days === 'all' ? [] : 'all' };
      return { ...prev, rules: newRules };
    });
  };

  // Свёрнутое состояние - только заголовок и кнопка
  if (!isExpanded) {
    return (
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h3 className="text-lg font-bold text-ink mr-4">
                {mode === 'create' ? 'Форма создания тарифа' : 'Форма редактирования тарифа'}
              </h3>
              {initialData?.name && (
                <span className="text-sm text-muted">Редактирование: {initialData.name}</span>
              )}
            </div>
            <Button variant="secondary" icon={ChevronDown} onClick={onToggleExpand}>
              Развернуть
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Развёрнутое состояние - полная форма
  return (
    <Card className="mb-6">
      <CardContent className="p-0">
        {/* Header */}
        <div className="border-b border-bg-2 p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-ink">
              {mode === 'edit' ? 'Редактировать тариф' : 'Создать новый тариф'}
            </h2>
            {initialData?.name && (
              <p className="text-muted mt-1">Редактирование: {initialData.name}</p>
            )}
          </div>
          <Button variant="secondary" icon={ChevronUp} onClick={onToggleExpand}>
            Свернуть
          </Button>
        </div>

        {/* Форма */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Основные поля */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
              <label className="block text-sm font-medium text-ink mb-2">
                Название тарифа *
              </label>
              <input
                type="text"
                className={`w-full bg-bg-2 border ${errors.name ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Например, Базовый"
              />
              {errors.name && (
                <div className="absolute z-50 bottom-full left-0 mb-1">
                  <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                    <AlertCircle size={14} className="flex-shrink-0" />
                    <span>{errors.name}</span>
                    <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="relative">
              <label className="block text-sm font-medium text-ink mb-2">
                Базовая стоимость (руб./кВт*ч) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                className={`w-full bg-bg-2 border ${errors.basePricePerKwh ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
                value={formData.basePricePerKwh}
                onChange={(e) => setFormData({ ...formData, basePricePerKwh: parseFloat(e.target.value) || 0 })}
                onFocus={(e) => e.target.select()}
              />
              {errors.basePricePerKwh && (
                <div className="absolute z-50 bottom-full left-0 mb-1">
                  <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                    <AlertCircle size={14} className="flex-shrink-0" />
                    <span>{errors.basePricePerKwh}</span>
                    <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="md:col-span-2 relative">
              <label className="block text-sm font-medium text-ink mb-2">
                Описание *
              </label>
              <textarea
                className={`w-full bg-bg-2 border ${errors.description ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand min-h-[80px]`}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Краткое описание тарифа"
              />
              {errors.description && (
                <div className="absolute z-50 bottom-full left-0 mb-1">
                  <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                    <AlertCircle size={14} className="flex-shrink-0" />
                    <span>{errors.description}</span>
                    <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Правила */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-ink">Правила</h3>
                <div className="flex items-center space-x-2">
                  <Button variant="secondary" icon={Plus} onClick={addRule} type="button">
                    Добавить правило
                  </Button>
                </div>
              </div>

              {errors.rules && (
                <div className="mb-4 p-3 bg-danger/10 border border-danger rounded-lg">
                  <p className="text-sm text-danger flex items-center">
                    <AlertCircle size={14} className="mr-2" /> {errors.rules}
                  </p>
                </div>
              )}

              {formData.rules.length === 0 ? (
                <p className="text-muted text-center py-4">
                  Правила не добавлены. Базовая стоимость будет применяться ко всем дням и времени.
                </p>
              ) : (
                <div className="space-y-4">
                  {formData.rules.map((rule, index) => (
                    <div key={rule.id} className="border border-bg-2 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-medium text-ink">Правило {index + 1}</h4>
                        <Button
                          variant="icon"
                          size="sm"
                          onClick={() => deleteRule(index)}
                          className="text-danger hover:text-danger/80"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* Дни недели */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Дни недели *
                          </label>
                          <div className="space-y-2">
                            <label className="flex items-center">
                              <input
                                type="checkbox"
                                checked={rule.days === 'all'}
                                onChange={() => toggleAllDays(index)}
                                className="mr-2"
                              />
                              <span className="text-sm">Все дни</span>
                            </label>
                            <div className="flex flex-wrap gap-4">
                              {WEEK_DAYS.map(day => (
                                <button
                                  key={day.id}
                                  type="button"
                                  onClick={() => toggleDay(index, day.id)}
                                  className={`px-4 py-3 rounded text-base transition-all focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2 ${rule.days === 'all' || rule.days.includes(day.id)
                                      ? 'bg-bg-3 text-ink font-medium border border-bg-1'
                                      : 'bg-bg-2 text-muted hover:bg-bg-1 hover:text-ink'
                                    }`}
                                  disabled={rule.days === 'all'}
                                >
                                  {day.label}
                                </button>
                              ))}
                            </div>
                            {ruleErrors[`rule_${index}_days`] && (
                              <div className="absolute z-50 bottom-full left-0 mb-1">
                                <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                                  <AlertCircle size={14} className="flex-shrink-0" />
                                  <span>{ruleErrors[`rule_${index}_days`]}</span>
                                  <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Время - только часы (24-часовой формат) */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Временной интервал (часы) *
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <select
                                className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_time`] ? 'border-danger' : 'border-bg-1'} rounded px-3 py-1 text-ink`}
                                value={rule.startTime.split(':')[0]}
                                onChange={(e) => updateRule(index, 'startTime', `${e.target.value.padStart(2, '0')}:00`)}
                              >
                                {Array.from({ length: 24 }, (_, i) => (
                                  <option key={i} value={i.toString().padStart(2, '0')}>
                                    {i.toString().padStart(2, '0')}:00
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <select
                                className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_time`] ? 'border-danger' : 'border-bg-1'} rounded px-3 py-1 text-ink`}
                                value={rule.endTime.split(':')[0]}
                                onChange={(e) => updateRule(index, 'endTime', `${e.target.value.padStart(2, '0')}:00`)}
                              >
                                {Array.from({ length: 24 }, (_, i) => (
                                  <option key={i} value={i.toString().padStart(2, '0')}>
                                    {i.toString().padStart(2, '0')}:00
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                          {ruleErrors[`rule_${index}_time`] && (
                            <div className="absolute z-50 bottom-full left-0 mb-1">
                              <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                                <AlertCircle size={14} className="flex-shrink-0" />
                                <span>{ruleErrors[`rule_${index}_time`]}</span>
                                <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Стоимость */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Стоимость (руб./кВт*ч) *
                          </label>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_price`] ? 'border-danger' : 'border-bg-1'} rounded px-3 py-1 text-ink [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
                            value={rule.pricePerKwh}
                            onChange={(e) => updateRule(index, 'pricePerKwh', parseFloat(e.target.value) || 0)}
                            onFocus={(e) => e.target.select()}
                          />
                          {ruleErrors[`rule_${index}_price`] && (
                            <div className="absolute z-50 bottom-full left-0 mb-1">
                              <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                                <AlertCircle size={14} className="flex-shrink-0" />
                                <span>{ruleErrors[`rule_${index}_price`]}</span>
                                <div className="absolute top-full left-4 -translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Предпросмотр правила */}
                      <div className="mt-4 pt-4 border-t border-bg-2">
                        <p className="text-sm text-muted">
                          {formatRuleDescription(rule)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Session Limits */}
          <div className="border border-bg-2 rounded-lg p-6">
            <h3 className="text-lg font-bold text-ink mb-4">Ограничения сессии</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-ink mb-2">
                  Макс. время (мин)
                </label>
                <input
                  type="number"
                  min="0"
                  className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  value={formData.sessionLimits.maxTime === 0 ? '' : formData.sessionLimits.maxTime}
                  onChange={(e) => setFormData({
                    ...formData,
                    sessionLimits: {
                      ...formData.sessionLimits,
                      maxTime: parseInt(e.target.value) || 0,
                    },
                  })}
                  onFocus={(e) => e.target.select()}
                  placeholder="Без ограничения"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-ink mb-2">
                  Макс. энергия (кВт*ч)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  value={formData.sessionLimits.maxEnergy === 0 ? '' : formData.sessionLimits.maxEnergy}
                  onChange={(e) => setFormData({
                    ...formData,
                    sessionLimits: {
                      ...formData.sessionLimits,
                      maxEnergy: parseFloat(e.target.value) || 0,
                    },
                  })}
                  onFocus={(e) => e.target.select()}
                  placeholder="Без ограничения"
                />
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
            <Button variant="secondary" onClick={onToggleExpand} type="button">
              Отмена
            </Button>
            <Button variant="primary" type="submit">
              {mode === 'edit' ? 'Сохранить изменения' : 'Создать тариф'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};
