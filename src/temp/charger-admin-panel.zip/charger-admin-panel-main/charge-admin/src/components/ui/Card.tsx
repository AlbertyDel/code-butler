import React from 'react';
import { cn } from '../../utils/cn';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'outline' | 'filled' | 'elevated' | 'ghost' | 'gradient';
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  hover?: boolean;
  shadow?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'personal' | 'commercial';
  border?: 'none' | 'light' | 'medium' | 'heavy';
  animation?: 'none' | 'fade-in' | 'slide-up' | 'bounce-subtle';
  sizeMode?: 'auto' | 'fixed' | 'compact' | 'metric';
  matchHeight?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className,
  variant = 'default',
  padding = 'md',
  hover = false,
  shadow = 'none',
  border = 'light',
  animation = 'none',
  sizeMode = 'auto',
  matchHeight = false,
  ...props
}) => {
  const variants = {
    default: 'bg-mode-card border border-mode-card',
    outline: 'border-2 border-mode-border-strong bg-transparent',
    filled: 'bg-mode-surface-alt',
    elevated: 'bg-mode-surface shadow-mode border border-mode-card',
    ghost: 'bg-transparent border-0',
    gradient: 'bg-gradient-card border-0',
  };

  const paddings = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
    xl: 'p-10',
  };

  const shadows = {
    none: '',
    sm: 'shadow-sm',
    md: 'shadow-md',
    lg: 'shadow-lg',
    xl: 'shadow-xl',
    personal: 'shadow-personal',
    commercial: 'shadow-commercial',
  };

  const borders = {
    none: 'border-0',
    light: 'border border-gray-400',
    medium: 'border-2 border-gray-500',
    heavy: 'border-4 border-gray-600',
  };

  const animations = {
    none: '',
    'fade-in': 'animate-fade-in',
    'slide-up': 'animate-slide-up',
    'bounce-subtle': 'animate-bounce-subtle',
  };

  const sizeModes = {
    auto: 'h-auto min-h-fit',
    fixed: 'h-full',
    compact: 'h-auto min-h-[200px]',
    metric: 'h-auto min-h-[120px]',
  };

  const hoverEffects = hover 
    ? 'relative transition-all duration-300 ease-in-out hover:shadow-xl hover:border-brand/30 hover:-translate-y-1 hover:scale-[1.02] hover:z-50 will-change-transform motion-reduce:transition-none motion-reduce:transform-none overflow-hidden max-w-full' 
    : 'transition-shadow duration-200 ease-in-out motion-reduce:transition-none max-w-full';

  return (
    <div
      className={cn(
        'card', // Add card class for CSS targeting
        'box-border', // Ensure borders and padding are included in width/height
        hoverEffects,
        variants[variant],
        paddings[padding],
        shadows[shadow],
        borders[border],
        animations[animation],
        sizeModes[sizeMode],
        'rounded-xl', // Moved to after border classes
        matchHeight && 'h-full',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};

interface CardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  description?: string;
  action?: React.ReactNode;
  icon?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
}

export const CardHeader: React.FC<CardHeaderProps> = ({
  title,
  description,
  action,
  icon,
  size = 'md',
  className,
  children,
  ...props
}) => {
  const titleSizes = {
    sm: 'text-heading-sm font-semibold',
    md: 'text-heading-md font-semibold',
    lg: 'text-heading-lg font-semibold',
  };

  const descriptionSizes = {
    sm: 'text-caption',
    md: 'text-body-sm',
    lg: 'text-body-md',
  };

  return (
    <div className={cn('flex items-start justify-between mb-6', className)} {...props}>
      <div className="flex-1 max-w-prose">
        <div className="flex items-start gap-3">
          {icon && (
            <div className="flex-shrink-0 mt-1">
              {icon}
            </div>
          )}
          <div className="flex-1">
            {title && <h3 className={cn(titleSizes[size], 'text-ink')}>{title}</h3>}
            {description && (
              <p className={cn(descriptionSizes[size], 'text-muted mt-2')}>
                {description}
              </p>
            )}
            {children}
          </div>
        </div>
      </div>
      {action && <div className="ml-4 flex-shrink-0">{action}</div>}
    </div>
  );
};

export const CardContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, children, ...props }) => {
  return (
    <div className={cn('text-body-md text-ink', className)} {...props}>
      {children}
    </div>
  );
};

interface CardFooterProps extends React.HTMLAttributes<HTMLDivElement> {
  align?: 'left' | 'center' | 'right' | 'between';
  variant?: 'default' | 'subtle' | 'accent';
}

export const CardFooter: React.FC<CardFooterProps> = ({
  className,
  align = 'left',
  variant = 'default',
  children,
  ...props
}) => {
  const alignment = {
    left: 'justify-start',
    center: 'justify-center',
    right: 'justify-end',
    between: 'justify-between',
  };

  const variants = {
    default: 'border-t border-gray-400',
    subtle: 'border-t border-gray-400 bg-bg-1/50',
    accent: 'border-t-2 border-brand',
  };

  return (
    <div
      className={cn(
        'flex items-center mt-6 pt-6',
        alignment[align],
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
