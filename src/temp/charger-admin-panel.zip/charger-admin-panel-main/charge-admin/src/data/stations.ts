import { fakerRU as faker } from '@faker-js/faker';

// Ensure deterministic results on each app start
faker.seed(2026);

export interface Station {
  id: string;
  name: string;
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;
  ports: number;
  location: string;
  tariffName: string;
  energyToday: number;
  
  // New technical parameters for mode 3 slow charging stations
  voltagePhase1?: number; // Напряжение сети на фазе 1 (вольты)
  voltagePhase2?: number; // Напряжение сети на фазе 2 (вольты)
  voltagePhase3?: number; // Напряжение сети на фазе 3 (вольты)
  inputContactTemp?: number; // Температура контактов сети на входе (°C)
  outputPort0Temp?: number; // Температура контактов выход порта 0 (°C)
  outputPort1Temp?: number; // Температура контактов выход порта 1 (°C)
  internalTemp?: number; // Температура внутри коробки ЗУ (°C)
  phaseIndicator?: '1 фаза' | '3 фазы'; // Индикация сколько фаз в сети
  portRelayStatus?: 'выключено' | 'включено'; // Состояние реле порта
  connectorType?: 'Розетка' | 'пистолет'; // Розетка (0), пистолет (1)
  portType?: 'NONE' | 'GBT' | 'CCS' | 'CHADEMO'; // Тип порта
  maxCurrentLimit?: '16А' | '32А'; // Максимальный лимит тока на порт
  totalSessions?: number; // Полное количество сессий зарядной станции
  totalOperatingMinutes?: number; // Полное количество минут работы зарядной станции
  totalEnergyDelivered?: number; // Полное количество отданной энергии (кВт час) зарядной станции
}

// Utility function to generate technical parameters for mode 3 slow charging stations
export function generateStationTechnicalParameters(): Omit<Station, 
  'id' | 'name' | 'status' | 'power' | 'ports' | 'location' | 'tariffName' | 'energyToday'
> {
  const phaseIndicator = faker.helpers.arrayElement(['1 фаза', '3 фазы'] as const);
  const isThreePhase = phaseIndicator === '3 фазы';
  
  // Generate voltages: for single-phase stations, only phase 1 has voltage
  const voltagePhase1 = faker.number.float({ min: 220, max: 240, multipleOf: 0.1 });
  const voltagePhase2 = isThreePhase ? faker.number.float({ min: 220, max: 240, multipleOf: 0.1 }) : 0;
  const voltagePhase3 = isThreePhase ? faker.number.float({ min: 220, max: 240, multipleOf: 0.1 }) : 0;
  
  return {
    voltagePhase1,
    voltagePhase2,
    voltagePhase3,
    inputContactTemp: faker.number.float({ min: 20, max: 80, multipleOf: 0.1 }),
    outputPort0Temp: faker.number.float({ min: 20, max: 80, multipleOf: 0.1 }),
    outputPort1Temp: faker.number.float({ min: 20, max: 80, multipleOf: 0.1 }),
    internalTemp: faker.number.float({ min: 30, max: 60, multipleOf: 0.1 }),
    phaseIndicator,
    portRelayStatus: faker.helpers.arrayElement(['выключено', 'включено'] as const),
    connectorType: faker.helpers.arrayElement(['Розетка', 'пистолет'] as const),
    portType: faker.helpers.arrayElement(['NONE', 'GBT', 'CCS', 'CHADEMO'] as const),
    maxCurrentLimit: faker.helpers.arrayElement(['16А', '32А'] as const),
    totalSessions: faker.number.int({ min: 0, max: 5000 }),
    totalOperatingMinutes: faker.number.int({ min: 0, max: 1000000 }),
    totalEnergyDelivered: faker.number.float({ min: 0, max: 50000, multipleOf: 0.1 }),
  };
}

// Utility function to ensure a station has all technical parameters
export function ensureStationHasTechnicalParameters(station: Station): Station {
  // If station already has all technical parameters, return as is
  if (
    station.voltagePhase1 !== undefined &&
    station.phaseIndicator !== undefined &&
    station.portRelayStatus !== undefined &&
    station.connectorType !== undefined &&
    station.portType !== undefined &&
    station.maxCurrentLimit !== undefined
  ) {
    return station;
  }
  
  // Generate missing technical parameters
  const technicalParams = generateStationTechnicalParameters();
  
  return {
    ...station,
    ...technicalParams,
  };
}

// Default list of stations generated using Faker.js with Russian locale
export const defaultStations: Station[] = Array.from({ length: 12 }).map((_, i) => {
  const baseStation = {
    id: `CHG-${1000 + i}`,
    // Станция А, Б, В... using Cyrillic letters starting from 1040 (А)
    name: `Станция ${String.fromCharCode(1040 + i)}`,
    status: faker.helpers.arrayElement(['charging', 'ready', 'offline', 'pending', 'fault']) as Station['status'],
    power: faker.helpers.arrayElement([7, 11, 22]),
    ports: faker.helpers.arrayElement([1, 2]),
    location: `${faker.location.streetAddress()}, ${faker.location.city()}`,
    tariffName: faker.helpers.arrayElement(['Базовый', 'Премиум', 'Ночной']),
    energyToday: faker.number.float({ min: 5, max: 90, multipleOf: 0.1 }),
  };
  
  // Generate technical parameters for default stations
  const technicalParams = generateStationTechnicalParameters();
  
  return {
    ...baseStation,
    ...technicalParams,
  };
});
