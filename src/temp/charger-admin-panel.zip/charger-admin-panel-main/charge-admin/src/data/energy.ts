import { fakerRU as faker } from '@faker-js/faker';

// Ensure deterministic results on each app start
faker.seed(2026);

export interface EnergyDataPoint {
  date: string;
  kwh: number;
}

// Mock energy data for chart - matches exact structure from Dashboard.tsx
export const mockEnergyData: EnergyDataPoint[] = [
  { date: '01 Jan', kwh: 120 },
  { date: '02 Jan', kwh: 180 },
  { date: '03 Jan', kwh: 150 },
  { date: '04 Jan', kwh: 220 },
  { date: '05 Jan', kwh: 190 },
  { date: '06 Jan', kwh: 240 },
  { date: '07 Jan', kwh: 210 },
];

// Generate additional energy data using Faker for variety
export const generateEnergyData = (days: number = 7): EnergyDataPoint[] => {
  const data: EnergyDataPoint[] = [];
  const baseDate = new Date(2025, 0, 1); // January 1, 2025
  
  for (let i = 0; i < days; i++) {
    const date = new Date(baseDate);
    date.setDate(baseDate.getDate() + i);
    
    data.push({
      date: `${date.getDate()} ${getMonthAbbreviation(date.getMonth())}`,
      kwh: faker.number.float({ min: 100, max: 250, multipleOf: 0.1 }),
    });
  }
  
  return data;
};

// Helper function to get month abbreviation in Russian format
const getMonthAbbreviation = (month: number): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[month];
};