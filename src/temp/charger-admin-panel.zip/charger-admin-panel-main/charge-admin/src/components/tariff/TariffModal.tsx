import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Plus, Trash2, AlertCircle, Save } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useToast } from '../ui/useToast';
import { useMode } from '../../contexts/useMode';
import type { 
  TariffFormData, 
  TariffRule
} from '../../types/tariff';
import { 
  WEEK_DAYS, 
  generateRuleId, 
  validateTimeRange,
  normalizeTimeRange,
  checkRuleOverlap,
  formatRuleDescription 
} from '../../types/tariff';

interface TariffModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (tariffData: TariffFormData) => void;
  initialData?: TariffFormData | null;
  existingNames: string[];
}

export const TariffModal: React.FC<TariffModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  existingNames,
}) => {
  const { showToast } = useToast();
  const { mode } = useMode();
  const dialogRef = useRef<HTMLDialogElement>(null);
  const rulesSectionRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  
  // Note: showAdvanced state is kept for potential future use
  // Removed unused variable to fix ESLint error
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ruleErrors, setRuleErrors] = useState<Record<string, string>>({});
  const [timeSwapNotification, setTimeSwapNotification] = useState<{
    ruleIndex: number;
    message: string;
  } | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Инициализация формы - use useState initializer and reset when props change
  const [formData, setFormData] = useState<TariffFormData>(() => {
    if (initialData) {
      return initialData;
    } else {
      return {
        name: '',
        description: '',
        basePricePerKwh: 25,
        rules: [],
        sessionLimits: {
          maxTime: 0,
          maxEnergy: 0,
        },
      };
    }
  });

  // Reset form when initialData changes and modal is open
  const prevInitialData = useRef(initialData);
  const prevIsOpen = useRef(isOpen);
  
  useEffect(() => {
    // Only reset if initialData changed or modal just opened
    if (isOpen && (initialData !== prevInitialData.current || !prevIsOpen.current)) {
      // Use setTimeout to avoid synchronous setState in effect
      const timer = setTimeout(() => {
        if (initialData) {
          setFormData(initialData);
        } else {
          setFormData({
            name: '',
            description: '',
            basePricePerKwh: 25,
            rules: [],
            sessionLimits: {
              maxTime: 0,
              maxEnergy: 0,
            },
          });
        }
        setErrors({});
        setRuleErrors({});
      }, 0);
      
      return () => clearTimeout(timer);
    }
    
    prevInitialData.current = initialData;
    prevIsOpen.current = isOpen;
  }, [initialData, isOpen]);

  // Open/close dialog based on isOpen prop
  useEffect(() => {
    if (!dialogRef.current) return;
    
    if (isOpen) {
      dialogRef.current.showModal();
    } else {
      dialogRef.current.close();
    }
  }, [isOpen]);

  // Handle click on backdrop to close
  const handleBackdropClick = (e: React.MouseEvent<HTMLDialogElement>) => {
    if (e.target === dialogRef.current) {
      onClose();
    }
  };

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert any rule with empty days array to 'all' days
    const processedFormData = {
      ...formData,
      rules: formData.rules.map(rule => ({
        ...rule,
        days: rule.days === 'all' || rule.days.length > 0 ? rule.days : 'all'
      }))
    };
    
    const newErrors: Record<string, string> = {};

    // Валидация названия
    if (!processedFormData.name.trim()) {
      newErrors.name = 'Название обязательно';
    } else if (initialData?.name !== processedFormData.name && existingNames.includes(processedFormData.name)) {
      newErrors.name = 'Тариф с таким названием уже существует';
    }

    // Валидация описания
    if (!processedFormData.description.trim()) {
      newErrors.description = 'Описание обязательно';
    }

    // Валидация базовой стоимости
    if (processedFormData.basePricePerKwh < 0) {
      newErrors.basePricePerKwh = 'Стоимость не может быть отрицательной';
    }

    // Валидация правил
    const newRuleErrors: Record<string, string> = {};
    processedFormData.rules.forEach((rule, index) => {
      if (rule.days.length === 0) { // Only show error for empty array, not for 'all'
        newRuleErrors[`rule_${index}_days`] = 'Выберите хотя бы один день';
      }
      if (!validateTimeRange(rule.startTime, rule.endTime)) {
        newRuleErrors[`rule_${index}_time`] = 'Время начала должно быть раньше времени окончания';
      }
      if (rule.pricePerKwh < 0) {
        newRuleErrors[`rule_${index}_price`] = 'Стоимость не может быть отрицательной';
      }
    });

    // Проверка пересечений правил
    const overlappingRules: number[] = [];
    processedFormData.rules.forEach((rule1, i) => {
      processedFormData.rules.forEach((rule2, j) => {
        if (i !== j && checkRuleOverlap(rule1, rule2)) {
          overlappingRules.push(i, j);
        }
      });
    });

    if (overlappingRules.length > 0) {
      newErrors.rules = 'Обнаружены пересекающиеся правила';
    }

    setErrors(newErrors);
    setRuleErrors(newRuleErrors);

    if (Object.keys(newErrors).length === 0 && Object.keys(newRuleErrors).length === 0) {
      onSubmit(processedFormData);
      onClose();
    } else {
      // Show error toast
      showToast('Пожалуйста, исправьте ошибки в форме', 'error');
      
      // Scroll to appropriate section
      // Find first rule with error
      const firstErrorRuleIndex = Object.keys(newRuleErrors).reduce((min, key) => {
        const match = key.match(/rule_(\d+)_/);
        if (match) {
          const index = parseInt(match[1]);
          return index < min ? index : min;
        }
        return min;
      }, Infinity);

      if (firstErrorRuleIndex !== Infinity) {
        const ruleElement = document.getElementById(`rule-card-${firstErrorRuleIndex}`);
        if (ruleElement) {
          ruleElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else if (rulesSectionRef.current) {
          rulesSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      } else if (newErrors.rules && rulesSectionRef.current) {
        rulesSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if ((newErrors.name || newErrors.basePricePerKwh || newErrors.description) && formRef.current) {
        formRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  const addRule = () => {
    setFormData(prev => {
      const newRule: TariffRule = {
        id: generateRuleId(),
        days: 'all',
        startTime: '08:00',
        endTime: '17:00',
        pricePerKwh: prev.basePricePerKwh,
      };
      return {
        ...prev,
        rules: [...prev.rules, newRule],
      };
    });
  };

  const updateRule = (index: number, field: keyof TariffRule, value: string | number) => {
    setFormData(prev => {
      const newRules = [...prev.rules];
      const rule = newRules[index];
      
      // Create updated rule with proper type conversion
      const updatedRule = { ...rule };
      
      // Handle different field types
      if (field === 'startTime' || field === 'endTime') {
        // For time fields, ensure value is string
        const timeValue = value.toString();
        updatedRule[field] = timeValue;
        
        // Normalize the time range
        const normalized = normalizeTimeRange(
          field === 'startTime' ? timeValue : rule.startTime,
          field === 'endTime' ? timeValue : rule.endTime
        );
        
        // Apply normalized times
        updatedRule.startTime = normalized.startTime;
        updatedRule.endTime = normalized.endTime;
        
        // Show visual feedback if times were swapped
        if (normalized.wasSwapped) {
          // Clear previous timeout
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
          }
          
          setTimeSwapNotification({
            ruleIndex: index,
            message: `Время скорректировано: ${normalized.startTime} → ${normalized.endTime}`
          });
          
          // Clear notification after 3 seconds (3000ms)
          timeoutRef.current = setTimeout(() => {
            setTimeSwapNotification(null);
          }, 3000);
        }
      } else if (field === 'pricePerKwh') {
        // For price field, ensure value is number
        updatedRule[field] = typeof value === 'number' ? value : parseFloat(value.toString()) || 0;
      } else if (field === 'days') {
        // For days field, handle the union type
        if (value === 'all' || (Array.isArray(value) && value.length === 0)) {
          updatedRule[field] = 'all';
        } else if (Array.isArray(value)) {
          updatedRule[field] = value;
        }
      }
      
      newRules[index] = updatedRule;
      return { ...prev, rules: newRules };
    });
    
    // Очистка ошибок для этого правила
    if (ruleErrors[`rule_${index}_${field}`]) {
      const newRuleErrors = { ...ruleErrors };
      delete newRuleErrors[`rule_${index}_${field}`];
      setRuleErrors(newRuleErrors);
    }
  };

  const deleteRule = (index: number) => {
    setFormData(prev => ({
      ...prev,
      rules: prev.rules.filter((_, i) => i !== index)
    }));
    
    // Очистка ошибок для удаленного правила
    const newRuleErrors = { ...ruleErrors };
    Object.keys(newRuleErrors).forEach(key => {
      if (key.startsWith(`rule_${index}_`)) {
        delete newRuleErrors[key];
      }
    });
    setRuleErrors(newRuleErrors);
  };

  const toggleDay = (ruleIndex: number, dayId: number) => {
    setFormData(prev => {
      const rule = prev.rules[ruleIndex];
      if (rule.days === 'all') return prev;
      
      const newDays = rule.days.includes(dayId)
        ? rule.days.filter(d => d !== dayId)
        : [...rule.days, dayId];
      
      const newRules = [...prev.rules];
      newRules[ruleIndex] = { ...rule, days: newDays };
      return { ...prev, rules: newRules };
    });
  };

  const toggleAllDays = (ruleIndex: number) => {
    setFormData(prev => {
      const rule = prev.rules[ruleIndex];
      const newRules = [...prev.rules];
      newRules[ruleIndex] = { ...rule, days: rule.days === 'all' ? [] : 'all' };
      return { ...prev, rules: newRules };
    });
  };

  if (!isOpen) return null;

  return createPortal(
    <dialog
      ref={dialogRef}
      onClick={handleBackdropClick}
      className="fixed inset-0 z-50 flex items-center justify-center bg-transparent border-0 shadow-none charge-dialog-override"
      aria-labelledby="tariff-modal-title"
    >
      {/* Single container with solid background - TRANSPARENCY FIX */}
      <div 
        className="modal-responsive-container w-full flex-shrink-0 h-auto border border-bg-2 rounded-lg shadow-xl max-h-[calc(100vh-4rem)] overflow-visible p-4"
        style={{ backgroundColor: '#FFFFFF' }} // Using design system color directly
        data-mode={mode}
      >
        {/* Header */}
        <div className="border-b border-bg-2 p-6 flex items-center justify-between">
          <h2 id="tariff-modal-title" className="text-2xl font-bold text-ink">
            {initialData ? 'Редактировать тариф' : 'Создать новый тариф'}
          </h2>
          <Button variant="icon" onClick={onClose}>
            <X size={24} />
          </Button>
        </div>

        {/* Form content */}
        <form 
          ref={formRef}
          onSubmit={handleSubmit} 
          className="overflow-y-auto p-6 space-y-6 max-h-[calc(100vh-12rem)]"
        >
          {/* Основные поля */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
              <label htmlFor="tariff-name" className="block text-sm font-medium text-ink mb-2">
                Название тарифа *
              </label>
              <input
                id="tariff-name"
                name="tariff-name"
                type="text"
                className={`w-full bg-bg-2 border ${errors.name ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand box-border`}
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Например, Базовый"
              />
              {errors.name && (
                <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                  <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                    <AlertCircle size={14} className="flex-shrink-0 text-white" />
                    <span className="text-white">{errors.name}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="relative">
              <label htmlFor="tariff-base-price" className="block text-sm font-medium text-ink mb-2">
                Базовая стоимость (руб./кВт*ч) *
              </label>
              <input
                id="tariff-base-price"
                name="tariff-base-price"
                type="number"
                step="0.1"
                min="0"
                className={`w-full bg-bg-2 border ${errors.basePricePerKwh ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none box-border`}
                value={formData.basePricePerKwh}
                onChange={(e) => setFormData({ ...formData, basePricePerKwh: parseFloat(e.target.value) || 0 })}
                onFocus={(e) => e.target.select()}
              />
              {errors.basePricePerKwh && (
                <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                  <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                    <AlertCircle size={14} className="flex-shrink-0 text-white" />
                    <span className="text-white">{errors.basePricePerKwh}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="md:col-span-2 relative">
              <label htmlFor="tariff-description" className="block text-sm font-medium text-ink mb-2">
                Описание *
              </label>
              <textarea
                id="tariff-description"
                name="tariff-description"
                className={`w-full bg-bg-2 border ${errors.description ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand min-h-[80px] box-border`}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Краткое описание тарифа"
              />
              {errors.description && (
                <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                  <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                    <AlertCircle size={14} className="flex-shrink-0 text-white" />
                    <span className="text-white">{errors.description}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Правила */}
          <Card>
            <CardContent className="p-6">
              <div 
                className="flex items-center justify-between mb-4" 
                ref={rulesSectionRef}
              >
                <h3 className="text-lg font-bold text-ink">Правила</h3>
                <div className="flex items-center space-x-2">
                  <Button variant="secondary" icon={Plus} onClick={addRule} type="button">
                    Добавить правило
                  </Button>
                </div>
              </div>

              {errors.rules && (
                <div className="mb-4 p-3 bg-danger/10 border border-danger rounded-lg animate-pulse">
                  <p className="text-sm text-danger flex items-center font-medium">
                    <AlertCircle size={14} className="mr-2" /> {errors.rules}
                  </p>
                </div>
              )}

              {/* Time swap notification */}
              {timeSwapNotification && (
                <div className="mb-4 p-4 bg-danger/20 border-l-4 border-danger rounded-r-lg shadow-sm">
                  <p className="text-sm text-danger flex items-center font-semibold">
                    <AlertCircle size={16} className="mr-2" /> {timeSwapNotification.message}
                  </p>
                </div>
              )}

              {formData.rules.length === 0 ? (
                <p className="text-muted text-center py-4">
                  Правила не добавлены. Базовая стоимость будет применяться ко всем дням и времени.
                </p>
              ) : (
                <div className="space-y-4">
              {formData.rules.map((rule, index) => (
                <div 
                  key={rule.id} 
                  id={`rule-card-${index}`}
                  className={`border rounded-lg p-4 transition-colors ${
                    Object.keys(ruleErrors).some(k => k.startsWith(`rule_${index}_`)) 
                      ? 'border-danger/50 bg-danger/5' 
                      : 'border-bg-2'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-ink">Правило {index + 1}</h4>
                        <Button
                          variant="icon"
                          size="sm"
                          onClick={() => deleteRule(index)}
                          className="text-danger hover:text-danger/80"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* Дни недели */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Дни недели *
                          </label>
                          <div className="space-y-2">
                            <label className="inline-flex items-center">
                              <input
                                type="checkbox"
                                checked={rule.days === 'all'}
                                onChange={() => toggleAllDays(index)}
                                className="mr-2"
                              />
                              <span className="text-sm">Все дни</span>
                            </label>
                            <div className="flex flex-wrap gap-4">
                              {WEEK_DAYS.map(day => (
                                <button
                                  key={day.id}
                                  type="button"
                                  onClick={() => toggleDay(index, day.id)}
                                  className={`px-4 py-3 rounded text-base transition-all focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2 ${rule.days === 'all' || rule.days.includes(day.id)
                                      ? 'bg-bg-3 text-ink font-medium border border-bg-1'
                                      : 'bg-bg-2 text-muted hover:bg-bg-1 hover:text-ink'
                                    }`}
                                  disabled={rule.days === 'all'}
                                >
                                  {day.label}
                                </button>
                              ))}
                            </div>
                            {ruleErrors[`rule_${index}_days`] && (
                              <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                                <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                                  <AlertCircle size={14} className="flex-shrink-0 text-white" />
                                  <span className="text-white">{ruleErrors[`rule_${index}_days`]}</span>
                                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Время - только часы (24-часовой формат) */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Временной интервал (часы) *
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <select
                                className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_time`] ? 'border-error' : 'border-bg-1'} rounded px-3 py-1 text-ink box-border`}
                                value={rule.startTime.split(':')[0]}
                                onChange={(e) => updateRule(index, 'startTime', `${e.target.value.padStart(2, '0')}:00`)}
                              >
                                {Array.from({ length: 24 }, (_, i) => (
                                  <option key={i} value={i.toString().padStart(2, '0')}>
                                    {i.toString().padStart(2, '0')}:00
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <select
                                className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_time`] ? 'border-error' : 'border-bg-1'} rounded px-3 py-1 text-ink box-border`}
                                value={rule.endTime.split(':')[0]}
                                onChange={(e) => updateRule(index, 'endTime', `${e.target.value.padStart(2, '0')}:00`)}
                              >
                                {Array.from({ length: 24 }, (_, i) => (
                                  <option key={i} value={i.toString().padStart(2, '0')}>
                                    {i.toString().padStart(2, '0')}:00
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                          {ruleErrors[`rule_${index}_time`] && (
                            <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                              <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                                <AlertCircle size={14} className="flex-shrink-0 text-white" />
                                <span className="text-white">{ruleErrors[`rule_${index}_time`]}</span>
                                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Стоимость */}
                        <div className="relative">
                          <label className="block text-sm font-medium text-ink mb-2">
                            Стоимость (руб./кВт*ч) *
                          </label>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            className={`w-full bg-bg-2 border ${ruleErrors[`rule_${index}_price`] ? 'border-error' : 'border-bg-1'} rounded px-3 py-1 text-ink [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none box-border`}
                            value={rule.pricePerKwh}
                            onChange={(e) => updateRule(index, 'pricePerKwh', parseFloat(e.target.value) || 0)}
                            onFocus={(e) => e.target.select()}
                          />
                          {ruleErrors[`rule_${index}_price`] && (
                            <div className="absolute z-50 bottom-[calc(100%-20px)] left-1/2 transform -translate-x-1/2">
                              <div className="bg-error text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative">
                                <AlertCircle size={14} className="flex-shrink-0 text-white" />
                                <span className="text-white">{ruleErrors[`rule_${index}_price`]}</span>
                                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-error"></div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Предпросмотр правила */}
                      <div className="mt-4 pt-4 border-t border-bg-2">
                        <p className="text-sm text-muted">
                          {formatRuleDescription(rule)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Session Limits */}
          <div className="border border-bg-2 rounded-lg p-6">
            <h3 className="text-lg font-bold text-ink mb-4">Ограничения сессии</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="max-time" className="block text-sm font-medium text-ink mb-2">
                  Макс. время (мин)
                </label>
                <input
                  id="max-time"
                  name="max-time"
                  type="number"
                  min="0"
                  className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  value={formData.sessionLimits.maxTime === 0 ? '' : formData.sessionLimits.maxTime}
                  onChange={(e) => setFormData({
                    ...formData,
                    sessionLimits: {
                      ...formData.sessionLimits,
                      maxTime: parseInt(e.target.value) || 0,
                    },
                  })}
                  onFocus={(e) => e.target.select()}
                  placeholder="Без ограничения"
                />
              </div>

              <div>
                <label htmlFor="max-energy" className="block text-sm font-medium text-ink mb-2">
                  Макс. энергия (кВт*ч)
                </label>
                <input
                  id="max-energy"
                  name="max-energy"
                  type="number"
                  step="0.1"
                  min="0"
                  className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  value={formData.sessionLimits.maxEnergy === 0 ? '' : formData.sessionLimits.maxEnergy}
                  onChange={(e) => setFormData({
                    ...formData,
                    sessionLimits: {
                      ...formData.sessionLimits,
                      maxEnergy: parseFloat(e.target.value) || 0,
                    },
                  })}
                  onFocus={(e) => e.target.select()}
                  placeholder="Без ограничения"
                />
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
            <Button variant="secondary" onClick={onClose} icon={X} type="button">
              Отмена
            </Button>
            <Button variant="primary" type="submit" icon={Save}>
              {initialData ? 'Сохранить изменения' : 'Создать тариф'}
            </Button>
          </div>
        </form>
      </div>
    </dialog>,
    document.body
  );
};
