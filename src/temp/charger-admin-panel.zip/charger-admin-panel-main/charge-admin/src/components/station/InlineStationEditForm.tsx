import React, { useState } from 'react';
import { Save, XCircle, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { useTariff } from '../../contexts/useTariff';
import { useMode } from '../../contexts/useMode';
import type { Station } from '../../data/stations';

interface InlineStationEditFormProps {
  station: Station;
  onSubmit: (station: Station) => void;
  onCancel: () => void;
}

export const InlineStationEditForm: React.FC<InlineStationEditFormProps> = ({
  station,
  onSubmit,
  onCancel,
}) => {
  const { tariffs } = useTariff();
  const { mode: appMode } = useMode();

  const [formData, setFormData] = useState<Station>(station);
  const [errors, setErrors] = useState<{
    name?: string;
    id?: string;
    location?: string;
    tariffName?: string;
  }>({});

  // Reset form when station changes - use key prop on parent instead of effect
  // The parent component should provide a new key when station changes

  const validateForm = (): boolean => {
    const newErrors: typeof errors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Название станции обязательно';
    } else if (formData.name.length > 100) {
      newErrors.name = 'Название не должно превышать 100 символов';
    }

    if (formData.id.length > 8) {
      newErrors.id = 'ID станции не должен превышать 8 символов';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Локация обязательна';
    }

    // В коммерческом режиме тариф обязателен
    if (appMode === 'commercial' && !formData.tariffName?.trim()) {
      newErrors.tariffName = 'Выберите тариф для станции';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <div className="bg-bg-0 rounded-lg border border-bg-2 p-6 mb-6">
      <h3 className="text-xl font-bold text-ink mb-4">Редактировать станцию: {station.name}</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <label className="block text-sm font-medium text-muted mb-2">Название станции *</label>
          <input
            type="text"
            maxLength={100}
            className={`w-full bg-bg-2 border ${errors.name ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Введите название станции"
          />
          {errors.name && (
            <div className="absolute z-50 -top-2 left-0 transform -translate-y-full">
              <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                <AlertCircle size={14} className="flex-shrink-0" />
                <span>{errors.name}</span>
                <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
              </div>
            </div>
          )}
        </div>

        <div className="relative">
          <label className="block text-sm font-medium text-muted mb-2">ID станции</label>
          <input
            type="text"
            maxLength={8}
            className={`w-full bg-bg-2 border ${errors.id ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
            value={formData.id}
            onChange={(e) => setFormData({ ...formData, id: e.target.value })}
            placeholder="CHG-XXXX"
          />
          {errors.id && (
            <div className="absolute z-50 -top-2 left-0 transform -translate-y-full">
              <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                <AlertCircle size={14} className="flex-shrink-0" />
                <span>{errors.id}</span>
                <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
              </div>
            </div>
          )}
          <p className="mt-1 text-xs text-muted">Максимум 8 символов</p>
        </div>

        <div className="relative">
          <label className="block text-sm font-medium text-muted mb-2">Локация *</label>
          <input
            type="text"
            className={`w-full bg-bg-2 border ${errors.location ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="Введите адрес станции"
          />
          {errors.location && (
            <div className="absolute z-50 -top-2 left-0 transform -translate-y-full">
              <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                <AlertCircle size={14} className="flex-shrink-0" />
                <span>{errors.location}</span>
                <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-muted mb-2">Мощность (кВт) *</label>
            <select
              className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
              value={formData.power}
              onChange={(e) => setFormData({ ...formData, power: Number(e.target.value) })}
            >
              <option value="7">7 кВт</option>
              <option value="11">11 кВт</option>
              <option value="22">22 кВт</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-muted mb-2">Количество портов *</label>
            <select
              className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
              value={formData.ports}
              onChange={(e) => setFormData({ ...formData, ports: Number(e.target.value) })}
            >
              <option value="1">1 порт</option>
              <option value="2">2 порта</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-muted mb-2">Статус *</label>
          <select
            className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as Station['status'] })}
          >
            <option value="ready">Готов</option>
            <option value="charging">Зарядка</option>
            <option value="offline">Оффлайн</option>
            <option value="pending">Ожидание</option>
            <option value="fault">Ошибка</option>
          </select>
        </div>

        {appMode === 'commercial' && (
          <div className="relative">
            <label className="block text-sm font-medium text-muted mb-2">Тариф *</label>
            <select
              className={`w-full bg-bg-2 border ${errors.tariffName ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
              value={formData.tariffName || ''}
              onChange={(e) => setFormData({ ...formData, tariffName: e.target.value })}
            >
              <option value="">Выберите тариф</option>
              {tariffs.map((tariff) => (
                <option key={tariff.name} value={tariff.name}>
                  {tariff.name}
                </option>
              ))}
            </select>
            {errors.tariffName && (
              <div className="absolute z-50 -top-2 left-0 transform -translate-y-full">
                <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
                  <AlertCircle size={14} className="flex-shrink-0" />
                  <span>{errors.tariffName}</span>
                  <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
          <Button variant="secondary" onClick={onCancel} icon={XCircle} type="button">
            Отмена
          </Button>
          <Button variant="primary" type="submit" icon={Save}>
            Сохранить изменения
          </Button>
        </div>
      </form>
    </div>
  );
};
