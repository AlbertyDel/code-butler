import React, { useEffect, useRef, useState } from 'react';
import { cn } from '../../utils/cn';
// Use contextual icons to represent various statuses
import {
  CheckCircle,
  AlertTriangle,
  Circle,
  Plug,
  Clock,
} from 'lucide-react';

export type StatusType = 'success' | 'info' | 'warning' | 'danger' | 'offline';

interface StatusBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  status: StatusType;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  clickable?: boolean;
  forceShowText?: boolean; // Force text to show even on mobile (for modals)
}

const statusConfig = {
  success: {
    // Use a plug icon for charging stations to be more intuitive
    icon: Plug,
    bg: 'bg-success/10',
    text: 'text-success',
    border: 'border-success/20',
    iconColor: 'text-success',
  },
  info: {
    // Ready stations use a check mark
    icon: CheckCircle,
    bg: 'bg-brand/light',
    text: 'text-brand-dark',
    border: 'border-brand/30',
    iconColor: 'text-brand-dark',
  },
  warning: {
    // Pending stations use a clock icon
    icon: Clock,
    bg: 'bg-warning/10',
    text: 'text-warning',
    border: 'border-warning/20',
    iconColor: 'text-warning',
  },
  danger: {
    // Faulty stations are flagged with an alert triangle
    icon: AlertTriangle,
    bg: 'bg-error/10',
    text: 'text-error',
    border: 'border-error/20',
    iconColor: 'text-error',
  },
  offline: {
    // Offline stations use a plain circle
    icon: Circle,
    bg: 'bg-error/10',
    text: 'text-error',
    border: 'border-error/20',
    iconColor: 'text-error',
  },
};

const sizeConfig = {
  sm: {
    container: 'px-2 py-0.5 text-xs',
    icon: 'h-3 w-3',
  },
  md: {
    container: 'px-4 py-1 text-sm', // Increased from px-3 to px-4 for better text spacing
    icon: 'h-4 w-4',
  },
  lg: {
    container: 'px-5 py-1.5 text-base', // Increased from px-4 to px-5 for better text spacing
    icon: 'h-5 w-5',
  },
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  label,
  size = 'md',
  showIcon = true,
  clickable = false,
  forceShowText = false,
  className,
  children,
  ...props
}) => {
  const config = statusConfig[status];
  const sizeStyle = sizeConfig[size];
  const Icon = config.icon;

  const displayLabel = label || children;
  const ariaLabel = displayLabel?.toString() || '';
  
  // Refs and state for dynamic width calculation
  const badgeRef = useRef<HTMLSpanElement>(null);
  const [isInTable, setIsInTable] = useState(false);
  const [dynamicWidth, setDynamicWidth] = useState<string | null>(null);

  useEffect(() => {
    if (!badgeRef.current) return;

    // Check if badge is inside a table cell (td)
    const parentTd = badgeRef.current.closest('td');
    const isInsideTable = !!parentTd;
    setIsInTable(isInsideTable);

    if (!isInsideTable) return;

    // Function to check if we're in desktop view
    const isDesktopView = () => window.innerWidth >= 640;

    // Function to update badge styles for table (only for desktop)
    const updateTableBadgeStyles = () => {
      if (!parentTd || !isDesktopView()) {
        // Reset on mobile
        setDynamicWidth(null);
        return;
      }
      
      // For table badges on desktop: use 100% of cell width but cap at 150px maximum
      // This ensures all badges in same column have same width but don't get too big
      const cellWidth = parentTd.getBoundingClientRect().width;
      
      // Calculate width: full cell width minus padding (8px each side = 16px total)
      // But apply maximum of 150px for desktop badges
      const calculatedWidth = cellWidth - 16;
      const targetWidth = Math.max(100, Math.min(150, calculatedWidth));
      
      setDynamicWidth(`${targetWidth}px`);
    };

    // Initial update
    updateTableBadgeStyles();

    // Set up ResizeObserver to track table cell size changes
    const resizeObserver = new ResizeObserver(updateTableBadgeStyles);
    resizeObserver.observe(parentTd);

    // Also observe window resize for viewport changes
    const handleWindowResize = () => {
      // Debounce resize events
      clearTimeout((window as any).__statusBadgeResizeTimer);
      (window as any).__statusBadgeResizeTimer = setTimeout(updateTableBadgeStyles, 100);
    };
    
    window.addEventListener('resize', handleWindowResize);

    // Media query listener for desktop/mobile breakpoint
    const mediaQuery = window.matchMedia('(min-width: 640px)');
    const handleMediaChange = () => {
      updateTableBadgeStyles();
    };
    mediaQuery.addEventListener('change', handleMediaChange);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      mediaQuery.removeEventListener('change', handleMediaChange);
      clearTimeout((window as any).__statusBadgeResizeTimer);
    };
  }, []);

  // Determine if we should apply dynamic width (only for desktop, in tables)
  const shouldApplyDynamicWidth = isInTable && dynamicWidth;

  return (
    <>
      {/* Inline style for dynamic width and overflow handling */}
      <style>{`
        @media (min-width: 640px) {
          .status-badge-text {
            display: inline !important;
          }
          .status-badge-desktop {
            min-width: 0 !important;
            min-height: 0 !important;
          }
          /* Increase icon size by 40% from current (cumulative 124% from original) */
          .status-badge-icon-sm {
            height: 23px !important;
            width: 23px !important;
          }
          .status-badge-icon-md {
            height: 36px !important;
            width: 36px !important;
          }
          .status-badge-icon-lg {
            height: 45px !important;
            width: 45px !important;
          }
          
          /* Table status badges - use flex display to respect width, no text truncation */
          .status-badge-in-table {
            display: flex !important;
            white-space: nowrap !important;
            /* Ensure text is fully visible, no clipping or truncation */
            overflow: visible !important;
            text-overflow: unset !important;
            box-sizing: border-box !important;
            justify-content: center !important;
            align-items: center !important;
            /* Prevent flex shrinking to ensure consistent width */
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
          }
        }
      `}</style>
      <span
        ref={badgeRef}
        className={cn(
          'inline-flex items-center justify-center rounded-full border font-medium transition-all duration-200',
          config.bg,
          config.text,
          config.border,
          sizeStyle.container,
          clickable && 'cursor-pointer hover:scale-105 active:scale-95',
          'min-w-[44px] min-h-[44px]', // Mobile touch target
          'status-badge-desktop', // Desktop styles via CSS
          isInTable && 'status-badge-in-table', // Additional styles for table badges
          className
        )}
        aria-label={ariaLabel}
        title={ariaLabel}
        style={{
          ...props.style,
          ...(shouldApplyDynamicWidth ? {
            width: dynamicWidth,
            minWidth: dynamicWidth,
            maxWidth: dynamicWidth,
          } : {})
        }}
        {...props}
      >
        {showIcon && (
          <Icon 
            className={cn(
              sizeStyle.icon, 
              config.iconColor,
              forceShowText ? 'mr-1.5' : 'sm:mr-1.5', // Always margin when text is forced
              `status-badge-icon-${size}` // Size-specific class for desktop scaling
            )} 
            aria-hidden="true"
          />
        )}
        {forceShowText ? (
          <span 
            className={cn()}
            aria-hidden="false"
          >
            {displayLabel}
          </span>
        ) : (
          <>
            <span 
              className={cn(
                'hidden status-badge-text'
              )} 
              aria-hidden="false"
            >
              {displayLabel}
            </span>
            <span className="sr-only" aria-hidden="true">{displayLabel}</span>
          </>
        )}
      </span>
    </>
  );
};

// Helper component for station status
export const StationStatusBadge: React.FC<{ 
  status: string; 
  forceShowText?: boolean;
}> = ({ status, forceShowText = false }) => {
  const statusMap: Record<string, StatusType> = {
    charging: 'success',
    ready: 'info',
    pending: 'warning',
    fault: 'danger',
    offline: 'offline',
    disconnected: 'offline',
  };

  const statusLabels: Record<string, string> = {
    charging: 'Зарядка',
    ready: 'Готов',
    pending: 'Ожидание',
    fault: 'Ошибка',
    offline: 'Офлайн',
    disconnected: 'Отключен',
  };

  const mappedStatus = statusMap[status.toLowerCase()] || 'offline';
  const label = statusLabels[status.toLowerCase()] || status;

  return <StatusBadge status={mappedStatus} label={label} forceShowText={forceShowText} />;
};
