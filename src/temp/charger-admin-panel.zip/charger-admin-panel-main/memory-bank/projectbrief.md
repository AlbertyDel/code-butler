# CHARGE_admin Project Brief

## Project Overview
CHARGE_admin is a React-based admin dashboard for managing electric vehicle charging stations, built with TypeScript and Vite. The application implements a sophisticated dual-mode architecture supporting both personal and commercial operation modes, providing tailored experiences for individual EV station owners and commercial operators managing multiple stations.

## Core Requirements and Goals

### Primary Objectives
1. **Dual-Mode Operation**: Support both "personal" (individual owners) and "commercial" (business operators) modes with distinct UI/UX and feature sets
2. **Comprehensive Station Management**: Provide complete CRUD operations for charging station infrastructure
3. **Advanced Pricing System**: Implement complex tariff management with time-based pricing rules and visual validation
4. **Financial Operations**: Support financial tracking, balance management, and subscription handling for commercial users
5. **Real-time Monitoring**: Enable session tracking, energy consumption analysis, and operational insights
6. **User-Centric Design**: Deliver intuitive, responsive interfaces optimized for both desktop and mobile devices

### Key Functional Requirements
- **Dashboard**: Dual-mode display with mode-specific KPIs, energy charts, and station overviews
- **Station Management**: Table-based station management with create, edit, delete operations and data validation
- **Tariff Management**: Advanced pricing rule system with visual rule visualization and overlap detection
- **Session Tracking**: Comprehensive session history with expandable details and time-based filtering
- **Financial Operations**: Balance management, withdrawal requests, and subscription handling (commercial only)
- **User Profile**: Mode-specific profile management with personal and organizational data
- **Navigation System**: Responsive layout with mode-aware filtering and protected route access

### Technical Goals
- **Type Safety**: Full TypeScript implementation for robust type checking
- **Responsive Design**: Mobile-first responsive design with adaptive layouts
- **State Management**: Context-based state management with localStorage persistence
- **Code Quality**: Maintainable, well-structured code with clear separation of concerns
- **Performance**: Optimized performance with lazy loading, memoization, and efficient state updates

## Project Scope

### In Scope
- Frontend web application built with React 19, TypeScript, and Vite
- Dual-mode architecture (personal/commercial) with mode context management
- Six main pages: Dashboard, Stations, Sessions, Tariffs, Finance, Profile
- LocalStorage-based data persistence with mock data fallback
- Responsive design system with Tailwind CSS and custom components
- Comprehensive UI component library with consistent design patterns
- Form validation, error handling, and user feedback systems
- Protected routes for mode-based access control

### Out of Scope
- Backend API integration (currently uses localStorage and mock data)
- Real-time WebSocket connections for live updates
- Multi-user authentication and authorization
- Payment processing integration
- Mobile app (web application only)
- Advanced analytics and reporting beyond basic KPIs
- Third-party service integrations (maps, weather, etc.)

## Target Users

### Personal Mode Users
- **Profile**: Individual EV station owners managing their personal charging infrastructure
- **Use Cases**: Monitor personal charging activity, manage 1-3 stations, track energy consumption
- **Key Features**: Simplified dashboard, basic station controls, personal session history

### Commercial Mode Users
- **Profile**: Commercial operators managing multiple charging stations for business purposes
- **Use Cases**: Fleet management, complex pricing strategies, financial operations, team collaboration
- **Key Features**: Advanced KPIs, tariff management, financial tracking, organizational tools

## Success Criteria

### Functional Success
- All six main pages fully functional with mode-appropriate features
- Seamless mode switching without data loss
- Complete CRUD operations for stations and tariffs
- Responsive design working on desktop and mobile devices
- Data persistence across browser sessions

### Technical Success
- TypeScript compilation without critical errors
- ESLint compliance (addressing existing linting issues)
- Build process producing optimized production bundles
- Efficient performance with minimal bundle size
- Clean, maintainable code architecture

### User Experience Success
- Intuitive navigation with clear mode indicators
- Responsive interfaces with appropriate touch targets
- Clear feedback for user actions (toasts, loading states)
- Accessible design meeting WCAG standards
- Consistent visual design across all components

## Project Constraints

### Technical Constraints
- **Frontend Only**: No backend integration in current implementation
- **LocalStorage**: Primary data persistence mechanism with 5-10MB storage limits
- **Browser Support**: Modern browsers with ES6+ support
- **Performance**: Must load within 3 seconds on average connections
- **Bundle Size**: Target under 500KB for initial load

### Design Constraints
- **Dual-Mode Consistency**: Maintain visual consistency while providing distinct mode experiences
- **Responsive Requirements**: Support screens from 320px (mobile) to 3840px (4K desktop)
- **Internationalization**: Russian language interface with Cyrillic support
- **Accessibility**: WCAG 2.1 AA compliance for all interactive elements

## Future Considerations
- **Backend Integration**: Replace localStorage with REST API or GraphQL endpoints
- **Real-time Updates**: Implement WebSocket connections for live station status
- **Advanced Analytics**: Add predictive analytics, usage patterns, and forecasting
- **Mobile App**: Consider React Native or Progressive Web App implementation
- **Multi-tenant Support**: Extend commercial mode for multiple organizations
- **Payment Processing**: Integrate with payment gateways for revenue collection
- **API Ecosystem**: Develop public API for third-party integrations

This project brief defines the foundation for CHARGE_admin, establishing clear requirements, scope, and success criteria for the dual-mode EV charging station management system.
