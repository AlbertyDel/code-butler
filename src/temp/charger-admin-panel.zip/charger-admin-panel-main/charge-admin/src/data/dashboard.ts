import { Zap, Clock, Battery, DollarSign } from 'lucide-react';

// KPI widgets displayed on the dashboard. Values are static for the demo but can be computed from session data in future versions.
export const dashboardKPIs = [
  { label: 'Активные станции', value: '12', change: '+3', icon: Battery },
  { label: 'Сессии сегодня', value: '26', change: '+5', icon: Clock },
  { label: 'Потребление (кВт·ч)', value: '6 530', change: '+11%', icon: Zap },
  { label: 'Доход (₽)', value: '158 240', change: '+9%', icon: DollarSign },
];