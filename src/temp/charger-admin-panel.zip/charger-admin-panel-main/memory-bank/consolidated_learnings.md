# Consolidated Learnings

This file contains distilled, actionable knowledge from the raw reflection log. It serves as a quick reference for patterns, solutions, and best practices discovered during development.

## Modal Design Patterns

### Modal Centering & Positioning
**Pattern: Flexbox Centering for Modals**
- Use `flex items-center justify-center` on parent container instead of `transform: translate(-50%, -50%)`
- **Why**: Transform centering causes repositioning when modal height changes, leading to visual jumping
- **Implementation**:
  ```tsx
  {/* Parent container */}
  <div className="fixed inset-0 flex items-center justify-center p-4">
    {/* Modal */}
    <div className="modal-responsive-container ...">
      {/* Content */}
    </div>
  </div>
  ```

**Pattern: Fixed Modal Height for Stable Layout**
- Set explicit height: `height: 80vh; max-height: 80vh; min-height: 400px`
- **Why**: Prevents modal from resizing when content changes, eliminating header/tab movement
- **Implementation**:
  ```tsx
  <div 
    className="modal-responsive-container"
    style={{ 
      height: '80vh',
      maxHeight: '80vh',
      minHeight: '400px'
    }}
  >
  ```

### Modal Responsive Width
**Pattern: Custom CSS for Responsive Modal Width**
- When Tailwind responsive classes fail, use custom CSS with media queries
- **Why**: Tailwind breakpoints may not apply due to CSS specificity issues
- **Implementation**:
  ```css
  /* In index.css */
  .modal-responsive-container {
    max-width: 90%;
    margin-left: auto;
    margin-right: auto;
  }
  
  @media (min-width: 768px) {
    .modal-responsive-container {
      max-width: 32rem; /* 512px */
    }
  }
  ```

### Modal Transparency Fix
**Pattern: Inline Styles for Modal Background**
- Use inline `style={{ backgroundColor: '#FFFFFF' }}` instead of Tailwind `bg-white` class
- **Why**: `<dialog showModal()>` creates special rendering layer that prevents normal CSS inheritance
- **Implementation**:
  ```tsx
  <div 
    className="modal-responsive-container bg-white"
    style={{ backgroundColor: '#FFFFFF' }} /* Always include */
  >
  ```

### Modal Accessibility
**Pattern: Complete Form Field Labeling**
- Always include `id`, `name`, and `htmlFor` attributes for accessibility
- **Why**: Chrome DevTools shows warnings for unlabeled form fields
- **Implementation**:
  ```tsx
  <div>
    <label htmlFor="field-name">Label</label>
    <input 
      id="field-name" 
      name="field-name" 
      type="text" 
    />
  </div>
  ```

## Mobile UX Patterns

### Mobile Tooltip Design
**Pattern: Touch Detection for Mobile Tooltips**
- Detect touch devices: `isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0`
- **Why**: Desktop should show hover tooltips, mobile should show click tooltips
- **Implementation**:
  ```tsx
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  const showTooltip = isTouchDevice ? isClicked : isHovered;
  ```

**Pattern: Fixed Positioning with Viewport Coordinates**
- Use viewport-relative coordinates for fixed positioned elements
- **Why**: `fixed` positioning uses viewport coordinates, not document coordinates
- **Implementation**:
  ```tsx
  // WRONG: Uses document scroll offsets
  const x = element.getBoundingClientRect().left + window.scrollX;
  
  // CORRECT: Uses viewport coordinates
  const x = element.getBoundingClientRect().left;
  ```

### Mobile Modal Centering
**Pattern: Remove Browser Dialog Padding**
- Override browser default dialog styles with `!important`
- **Why**: Browser adds `1em` (16px) padding to `<dialog>` elements, causing mobile centering issues
- **Implementation**:
  ```css
  dialog.charge-dialog-override {
    padding: 0 !important;
    margin: 0 !important;
    width: 100% !important;
    max-width: 100% !important;
  }
  ```

## Component Architecture Patterns

### Stable Layout with Flexbox
**Pattern: Fixed Header with Scrollable Content**
- Use `flex-shrink: 0` for fixed sections, `flex-1 overflow-y-auto` for scrollable content
- **Why**: Prevents layout shifts when content changes
- **Implementation**:
  ```tsx
  <div className="flex flex-col h-full">
    {/* Fixed header */}
    <div className="flex-shrink-0">
      Header content
    </div>
    
    {/* Scrollable content */}
    <div className="flex-1 overflow-y-auto">
      Dynamic content
    </div>
  </div>
  ```

### Event Handling with Refs
**Pattern: Use Refs in Event Listener Closures**
- Store current state in refs for event listeners
- **Why**: Event listeners capture stale state from closure
- **Implementation**:
  ```tsx
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const positionRef = useRef(position);
  
  // Update ref when state changes
  useEffect(() => {
    positionRef.current = position;
  }, [position]);
  
  // Event listener uses ref, not state
  const handleScroll = () => {
    updateTooltip(positionRef.current);
  };
  ```

## Development Workflow Patterns

### Documentation-Driven Development
**Pattern: Reference Project Documentation First**
- Check existing documentation (`MODAL_TRANSPARENCY_FIX.md`) before implementing solutions
- **Why**: Avoids re-solving known problems, ensures consistency
- **Implementation**: Always search for existing patterns in project docs before coding

### Testing with Chrome DevTools MCP
**Pattern: Automated Browser Testing**
- Use Chrome DevTools MCP for programmatic testing
- **Why**: Enables precise measurement and verification of UI behavior
- **Implementation**:
  ```javascript
  // Example: Test modal centering
  const modal = document.querySelector('.modal-responsive-container');
  const rect = modal.getBoundingClientRect();
  const isCentered = Math.abs(rect.left - expectedLeft) < 5;
  ```

**Pattern: Systematic Color Verification**
- Use `evaluate_script` to verify colors and contrast ratios
- **Why**: Ensures design system colors are properly applied and meet accessibility standards
- **Implementation**:
  ```javascript
  // Verify button colors and contrast
  const buttons = Array.from(document.querySelectorAll('button'));
  const buttonColors = buttons.map(btn => {
    const style = window.getComputedStyle(btn);
    return {
      text: btn.textContent?.trim().slice(0, 20),
      bgColor: style.backgroundColor,
      textColor: style.color,
      contrastRatio: calculateContrast(style.color, style.backgroundColor)
    };
  });
  ```

**Pattern: Color Contrast Auditing**
- Automatically check WCAG 2.1 AA compliance (minimum 4.5:1 contrast ratio)
- **Why**: Ensures accessibility for users with visual impairments
- **Implementation**:
  ```javascript
  // Calculate contrast ratio between two colors
  function calculateContrast(color1, color2) {
    const luminance1 = calculateLuminance(color1);
    const luminance2 = calculateLuminance(color2);
    return (Math.max(luminance1, luminance2) + 0.05) / 
           (Math.min(luminance1, luminance2) + 0.05);
  }
  ```

**Pattern: React Code Watcher v2 Methodology**
- Apply systematic UI debugging using React Code Watcher v2 sub-rules
- **Why**: Comprehensive verification of visual consistency, accessibility, and performance
- **Common Sub-Rules to Apply**:
  - **Color Contrast**: Verify WCAG 2.1 compliance
  - **Component Scaling**: Check touch target sizes (minimum 44px)
  - **Visual Consistency**: Ensure border radius, font weights, spacing consistency
  - **Accessibility**: Verify focus states, ARIA labels, keyboard navigation
- **Implementation**: Use Chrome DevTools MCP to execute diagnostic scripts for each sub-rule

## Bug Investigation Patterns

### Systematic Bug Analysis
**Pattern: Verify Actual vs Perceived Issues**
- When investigating reported bugs, distinguish between what users report vs actual technical issues
- **Why**: Users may misdiagnose problems (e.g., report "coloring bug" when issue is positioning)
- **Implementation**:
  1. Reproduce the reported issue
  2. Use Chrome DevTools MCP to verify actual state (colors, positioning, styles)
  3. Compare reported symptoms with actual technical issues
  4. Fix actual issues, not just perceived ones

**Pattern: Reference Existing Working Implementations**
- When fixing issues, reference similar components that work correctly
- **Why**: Ensures consistency and leverages proven patterns
- **Implementation**:
  ```tsx
  // Example: Fix modal positioning by referencing working modal
  // Working modal: StationDetailsModal uses flexbox centering
  // Broken modal: SessionDetailsModal should use same pattern
  const workingModalPattern = `
    <div className="fixed inset-0 flex items-center justify-center p-4">
      <div className="modal-responsive-container ...">
        {/* Content */}
      </div>
    </div>
  `;
  ```

## CSS & Styling Patterns

### When Tailwind Fails
**Pattern: Custom CSS Media Queries**
- Create custom CSS classes when Tailwind responsive classes don't work
- **Why**: CSS specificity or loading order issues can break Tailwind breakpoints
- **Implementation**:
  ```css
  /* Custom responsive width */
  .custom-responsive {
    width: 90%;
  }
  
  @media (min-width: 768px) {
    .custom-responsive {
      width: 512px;
    }
  }
  ```

### Design System Consistency
**Pattern: Use Design System Colors in Inline Styles**
- Reference design system colors directly in inline styles
- **Why**: Ensures consistency even when CSS classes fail
- **Implementation**:
  ```tsx
  style={{ 
    backgroundColor: '#FFFFFF',  // bg2 / bg-1
    borderColor: '#F2F4F7'       // bg-2
  }}
  ```

## Performance Patterns

### Tooltip Performance
**Pattern: Debounce Scroll Event Listeners**
- Use debouncing for scroll event listeners in tooltips
- **Why**: Prevents performance issues from frequent updates
- **Implementation**:
  ```tsx
  const debouncedUpdate = useCallback(
    debounce(() => updateTooltipPosition(), 100),
    []
  );
  
  useEffect(() => {
    window.addEventListener('scroll', debouncedUpdate);
    return () => window.removeEventListener('scroll', debouncedUpdate);
  }, [debouncedUpdate]);
  ```

## Error Prevention Patterns

### TypeScript Safety
**Pattern: Avoid `any` Types in Props**
- Always define proper TypeScript interfaces for component props
- **Why**: Catches type errors at compile time, improves code quality
- **Implementation**:
  ```tsx
  interface ButtonProps {
    variant: 'primary' | 'secondary' | 'danger';
    icon?: LucideIcon;  // Specific type, not `any`
    onClick: () => void;
  }
  ```

### State Management Safety
**Pattern: Proper useEffect Dependencies**
- Always include all dependencies in useEffect dependency arrays
- **Why**: Prevents stale closures and infinite re-renders
- **Implementation**:
  ```tsx
  // WRONG: Missing dependencies
  useEffect(() => {
    setState(value);
  }, []);
  
  // CORRECT: All dependencies included
  useEffect(() => {
    setState(value);
  }, [value, setState]);
  ```

## Project-Specific Patterns

### CHARGE_admin Modal Patterns
**Pattern: `modal-responsive-container` Usage**
- Always use this class for modals requiring responsive width
- **CSS Already Defined**:
  ```css
  .modal-responsive-container {
    max-width: 90%;
    margin-left: auto;
    margin-right: auto;
  }
  
  @media (min-width: 768px) {
    .modal-responsive-container {
      max-width: 32rem; /* 512px */
    }
  }
  ```

**Pattern: Dual-Mode Component Structure**
- Components should adapt to `mode` from `ModeContext`
- **Implementation**:
  ```tsx
  const { mode } = useMode();
  const isCommercial = mode === 'commercial';
  
  return (
    <div>
      {isCommercial ? <CommercialView /> : <PersonalView />}
    </div>
  );
  ```

## React Code Watcher v2 & CSS Specificity Patterns

### CSS Specificity Workarounds for Tailwind v4
**Pattern: Force CSS Properties with `setProperty` and `!important`**
- Use `element.style.setProperty('property', 'value', 'important')` in `useEffect`
- **Why**: Tailwind v4 utility classes can be overridden by unknown CSS rules; React style objects don't support `!important`
- **Implementation**:
  ```tsx
  const contentAreaRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (contentAreaRef.current) {
      contentAreaRef.current.style.setProperty('overflow-y', 'auto', 'important');
    }
  }, []);
  
  return (
    <div ref={contentAreaRef} className="flex-1 overflow-y-auto">
      Content
    </div>
  );
  ```

**Pattern: Debug CSS Specificity with Chrome DevTools MCP**
- Use `evaluate_script` to compare inline styles vs computed styles
- **Why**: Identify which CSS rules are overriding your intended styles
- **Implementation**:
  ```javascript
  // In Chrome DevTools MCP evaluate_script
  const element = document.querySelector('.target-element');
  const inlineStyle = element.style.cssText;
  const computedStyle = window.getComputedStyle(element).overflowY;
  return { inlineStyle, computedStyle };
  ```

### React Code Watcher v2 Methodology
**Pattern: Systematic UI Debugging with Sub-Rules**
- Apply specific sub-rules from `React_code_watcher_2.md` based on issue type
- **Why**: Targeted debugging instead of full 10-point audit when appropriate
- **Common Sub-Rules**:
  - **`box-model.md`**: Overflow, padding, margin, height issues
  - **`z-index-clipping.md`**: Hidden elements, overflow clipping
  - **`visual-obstructions.md`**: Clickable elements blocked
  - **`anti-patterns.md`**: CSS specificity, `!important` usage
  - **`component-scaling-proportions.md`**: Flexbox, sizing issues

**Pattern: MCP Tool Chain for Automated Testing**
- Chain MCP tools for comprehensive UI testing: `take_snapshot` → `evaluate_script` → `click` → `wait_for`
- **Why**: Automated verification of UI behavior and fixes
- **Implementation**:
  ```javascript
  // Test sequence for modal scrolling
  1. take_snapshot() - Capture initial state
  2. evaluate_script() - Check computed styles
  3. click() - Open modal/interact
  4. evaluate_script() - Test scrolling behavior
  5. wait_for() - Verify expected text appears
  ```

### Constrained Content Area Height
**Pattern: Calculate Content Area Height Dynamically**
- Use `calc(80vh - [header-height])` for constrained scrolling areas
- **Why**: Ensures content area fits within modal while allowing scrolling
- **Implementation**:
  ```tsx
  <div 
    className="flex-1 p-6"
    style={{ 
      maxHeight: 'calc(80vh - 169px)', // 80vh minus header + tabs height
      overflowY: 'auto'
    }}
  >
    Scrollable content
  </div>
  ```

## Visual Consistency Patterns

### Button Border Radius System
**Pattern: Consistent Border Radius Across Interactive Elements**
- Establish a consistent border radius system for all interactive elements
- **Why**: Creates visual harmony and professional appearance
- **Implementation**:
  ```css
  /* In index.css */
  button {
    border-radius: 8px; /* Default for all buttons */
  }
  
  button.rounded-lg, a.rounded-lg {
    border-radius: 12px !important; /* Larger buttons */
  }
  
  button.rounded-full, a.rounded-full {
    border-radius: 9999px !important; /* Circular buttons */
  }
  
  /* Cards */
  .bg-bg2.rounded-lg, .bg-bg-2.rounded-lg {
    border-radius: 12px !important;
  }
  ```

### Font Loading and Weight Consistency
**Pattern: Proper Font Loading with All Weights**
- Load fonts with all required weights to prevent faux-bold/italic rendering
- **Why**: Browser-synthesized bold/italic looks blurry and unprofessional
- **Implementation**:
  ```css
  @font-face {
    font-family: 'Inter';
    font-weight: 400; /* Regular */
    src: url('...');
  }
  
  @font-face {
    font-family: 'Inter';
    font-weight: 500; /* Medium */
    src: url('...');
  }
  
  @font-face {
    font-family: 'Inter';
    font-weight: 600; /* Semibold */
    src: url('...');
  }
  
  @font-face {
    font-family: 'Inter';
    font-weight: 700; /* Bold */
    src: url('...');
  }
  
  /* Use semibold for headings instead of bold */
  h1, h2, h3, h4, h5, h6 {
    font-weight: 600;
  }
  ```

### Visual Audit Methodology
**Pattern: High-Fidelity Visual Audit with Chrome DevTools**
- Use Chrome DevTools MCP for comprehensive visual audits
- **Why**: Automated detection of visual inconsistencies across all pages
- **Implementation**:
  ```javascript
  // Check button border radius consistency
  const buttons = document.querySelectorAll('button');
  buttons.forEach(btn => {
    const style = getComputedStyle(btn);
    if (style.borderRadius === '0px') {
      console.log('Button with zero border radius:', btn.textContent);
    }
  });
  
  // Check font weight consistency
  const headings = document.querySelectorAll('h1, h2, h3');
  headings.forEach(h => {
    const style = getComputedStyle(h);
    if (style.fontWeight === '700') {
      console.log('Heading using font-weight 700:', h.textContent);
    }
  });
  ```

### Mobile Modal Scrolling Patterns

**Pattern: Responsive Modal Height for Mobile**
- Use different heights for mobile vs desktop: `90vh` on mobile, `70vh` on desktop
- **Why**: Mobile screens have less vertical space; need taller modals to show more content
- **Implementation**:
  ```tsx
  useEffect(() => {
    const updateModalSizes = () => {
      const isMobile = window.innerWidth < 768;
      const modalMaxHeight = isMobile ? '90vh' : '70vh';
      const contentMaxHeight = `calc(${modalMaxHeight} - 140px)`;
      
      // Update modal max-height
      const modal = document.querySelector('.modal-responsive-container');
      if (modal && modal instanceof HTMLElement) {
        modal.style.maxHeight = modalMaxHeight;
      }
      
      // Update content area
      if (contentAreaRef.current) {
        contentAreaRef.current.style.setProperty('overflow-y', 'auto', 'important');
        contentAreaRef.current.style.setProperty('max-height', contentMaxHeight, 'important');
      }
    };
    
    updateModalSizes();
    window.addEventListener('resize', updateModalSizes);
    return () => window.removeEventListener('resize', updateModalSizes);
  }, [isOpen]); // Run when modal opens and on resize
  ```

**Pattern: Modal Container Overflow Control**
- Add `overflow-hidden` to modal container to prevent content escaping bounds
- **Why**: Without `overflow: hidden`, content can visually overflow outside modal container
- **Implementation**:
  ```tsx
  <div className="modal-responsive-container overflow-hidden ...">
    {/* Modal content */}
  </div>
  ```

**Pattern: Content Area Height Calculation**
- Calculate content area height as: `calc(modalHeight - headerHeight)`
- **Why**: Ensures content area fits within modal while allowing scrolling
- **Common header heights**: 
  - `169px`: Header with tabs (p-6 + border + tabs)
  - `140px`: Header without tabs (p-6 + border)
- **Implementation**:
  ```tsx
  style={{ 
    maxHeight: 'calc(70vh - 140px)', // Desktop
    overflowY: 'auto'
  }}
  ```

**Pattern: Mobile Scrolling Debugging with MCP**
- Use Chrome DevTools MCP to diagnose mobile scrolling issues
- **Why**: Programmatic testing reveals computed styles vs intended styles
- **Implementation**:
  ```javascript
  // Check if content overflows modal
  const modal = document.querySelector('.modal-responsive-container');
  const contentArea = modal.querySelector('.flex-1.p-6.overflow-y-auto');
  
  const modalRect = modal.getBoundingClientRect();
  const contentRect = contentArea.getBoundingClientRect();
  const contentOverflows = contentRect.bottom > modalRect.bottom;
  
  // Check computed styles
  const modalStyle = window.getComputedStyle(modal);
  const contentStyle = window.getComputedStyle(contentArea);
  
  return {
    modalOverflow: modalStyle.overflow,
    contentOverflowY: contentStyle.overflowY,
    contentOverflows,
    modalHeight: modalRect.height,
    contentHeight: contentRect.height
  };
  ```

### Overflow Clipping Prevention
**Pattern: Prevent Overflow Clipping in Flex Containers**
- Ensure `.flex-1` containers don't clip child elements
- **Why**: `overflow: hidden` can clip shadows, outlines, and other visual effects
- **Implementation**:
  ```css
  .flex-1 {
    overflow: visible !important;
  }
  ```

## Responsive Design Patterns

### Fluid Icon Sizing for Mobile
**Pattern: Fluid Icon Sizing with `clamp()` for Mobile Responsive Design**
- Use CSS `clamp()` function for proportional scaling with min/max constraints
- **Why**: Provides smooth scaling between minimum and maximum sizes based on viewport width
- **Implementation**:
  ```css
  /* Width: scales from 16px (320px viewport) to 24px (640px viewport) */
  width: clamp(16px, 4vw, 24px) !important;
  /* Height: maintains aspect ratio (3:2) - scales from 12px to 16px */
  height: clamp(12px, 3vw, 16px) !important;
  /* Ensure minimum and maximum constraints */
  min-width: 16px !important;
  min-height: 12px !important;
  max-width: 24px !important;
  max-height: 16px !important;
  ```

**Pattern: Viewport-Based Scaling Using `vw` Units**
- Use viewport width units (`vw`) for proportional resizing
- **Why**: Elements scale smoothly with viewport width changes
- **Formula**: `4vw` means 4% of viewport width for width, `3vw` for height
- **Scaling Range**: 
  - 320px viewport: 4% = 12.8px → clamped to 16px (minimum)
  - 500px viewport: 4% = 20px → actual size
  - 640px viewport: 4% = 25.6px → clamped to 24px (maximum)

**Pattern: Min/Max Constraints for Mobile Elements**
- Set minimum and maximum sizes to prevent elements from becoming too small or too large
- **Why**: Ensures usability on very small screens and prevents oversized elements on large screens
- **Implementation**: Use `min-width`, `max-width`, `min-height`, `max-height` with `clamp()`

**Pattern: Maintain Aspect Ratio When Scaling Icons**
- Keep consistent aspect ratio when scaling icons proportionally
- **Why**: Prevents distortion and maintains visual consistency
- **Example**: 3:2 aspect ratio (wider than tall) for header icons

**Pattern: Programmatic Testing of CSS `clamp()` Functions**
- Test fluid sizing mathematically since browser resizing may be restricted
- **Why**: Can't always resize browser window due to "Restore window to normal state" error
- **Implementation**:
  ```javascript
  // Calculate expected size based on clamp formula
  const calculateExpectedSize = (viewport) => {
    const vw = viewport / 100;
    const widthVw = 4 * vw; // 4% of viewport
    const expectedWidth = Math.max(16, Math.min(widthVw, 24));
    const heightVw = 3 * vw; // 3% of viewport
    const expectedHeight = Math.max(12, Math.min(heightVw, 16));
    return { expectedWidth, expectedHeight };
  };
  ```

**Pattern: Desktop/Mobile Responsive Behavior for Icons**
- **Mobile**: Show icons, hide text (icons scale fluidly with viewport)
- **Desktop**: Show text, hide icons (fixed layout)
- **Implementation**: Use responsive classes: `sm:hidden` for mobile icons, `hidden sm:inline` for desktop text

### Mobile Button Text Alignment
**Pattern: Responsive Padding Adjustment for Very Small Screens**
- Reduce padding on very small screens (< 450px) to maintain visual centering
- **Why**: Fixed padding causes text to appear right-shifted as buttons narrow
- **Implementation**:
  ```css
  /* In tempStyles or component CSS */
  @media (max-width: 449px) {
    div.flex.gap-0\\.5 button {
      padding-left: 8px !important;
      padding-right: 8px !important;
    }
  }
  ```

**Pattern: Fixed Padding Causes Visual Alignment Issues**
- Fixed padding (e.g., `px-4` = 16px) remains constant as element width decreases
- **Why**: On narrow elements, fixed left padding makes text appear right-shifted relative to center
- **Solution**: Reduce padding proportionally as element width decreases
- **Verification**: Use Chrome DevTools MCP to test at exact breakpoints users mention

**Pattern: Desktop vs Mobile Button Behavior**
- **Desktop**: Text left-aligned, restrained width (`sm:w-auto`), no flex-grow (`sm:flex-grow-0`)
- **Mobile**: Text centered, full width (`flex-grow: 1`), responsive padding
- **Implementation**:
  ```tsx
  <button
    className={`px-4 py-3 rounded-md text-base sm:text-sm font-medium 
                min-h-[44px] flex-grow flex-shrink whitespace-nowrap border
                sm:flex-grow-0 sm:w-auto sm:text-left
                ${selected ? 'bg-brand text-white' : 'bg-bg-2 text-ink'}`}
  >
    Button Text
  </button>
  ```

### Bug Investigation Patterns

**Pattern: Test at Exact Screen Sizes Users Mention**
- When users report visual issues at specific screen sizes, test at those exact dimensions
- **Why**: Issues may only appear at specific breakpoints (< 450px, < 640px, etc.)
- **Implementation**: Use Chrome DevTools MCP `evaluate_script` to test at specific viewport widths

**Pattern: Distinguish Perceived vs Actual Issues**
- Users may misdiagnose problems (e.g., report "coloring bug" when issue is positioning)
- **Why**: Visual perception can be misleading; need technical verification
- **Implementation**:
  1. Reproduce reported issue
  2. Use Chrome DevTools MCP to verify actual state (colors, positioning, styles)
  3. Compare reported symptoms with actual technical issues
  4. Fix actual issues, not just perceived ones

## CSS Specificity with Tailwind Responsive Classes

### Tailwind Responsive Class Matching
**Pattern: Use Attribute Selector `[class*="sm:inline"]` for Responsive Classes**
- Match Tailwind responsive classes using attribute selector when CSS specificity fails
- **Why**: Tailwind responsive classes like `sm:inline` may not apply due to CSS specificity issues
- **Implementation**:
  ```css
  /* Match elements with class containing "sm:inline" */
  span[class*="sm:inline"] {
    display: inline !important;
  }
  
  /* More specific selectors for different contexts */
  table tbody tr td:first-child span span[class*="sm:inline"] {
    display: inline !important;
  }
  
  .bg-bg2.border .inline-flex.items-center span[class*="sm:inline"] {
    display: inline !important;
  }
  ```

**Pattern: Global Style Tags Outside Conditional Rendering**
- Place global style tags outside conditional rendering blocks
- **Why**: Style tags inside conditional blocks only apply when that block renders
- **Implementation**:
  ```tsx
  // WRONG: Style only applies in commercial mode
  {mode === 'commercial' && (
    <>
      <style dangerouslySetInnerHTML={{ __html: `...` }} />
      {/* Commercial content */}
    </>
  )}
  
  // CORRECT: Style applies to both modes
  <style dangerouslySetInnerHTML={{ __html: `...` }} />
  {mode === 'commercial' ? <CommercialView /> : <PersonalView />}
  ```

### Mobile-First Responsive Design for Status Badges
**Pattern: Icon-Only on Mobile, Icon+Text on Desktop**
- Use `hidden sm:inline` for text that should only show on desktop
- **Why**: Mobile screens have limited space; show icons only to save space
- **Implementation**:
  ```tsx
  <div className="inline-flex items-center gap-1.5">
    <Icon className="w-4 h-4" />
    <span className="hidden sm:inline text-sm font-medium">
      Status Text
    </span>
  </div>
  ```

**Pattern: Dual-Mode Component Testing**
- Test components in both commercial and personal modes
- **Why**: Dual-mode applications may have different rendering contexts
- **Implementation**: Use Chrome DevTools MCP to verify both modes work correctly

### Fluid Icon Sizing Improvements
**Pattern: Adjust Aspect Ratio for Better Icon Visibility**
- Use 5:4 aspect ratio instead of 3:2 for square icons
- **Why**: Square icons appear distorted when scaled with extreme aspect ratios
- **Implementation**:
  ```css
  /* Improved: 5:4 aspect ratio (closer to square) */
  width: clamp(20px, 5vw, 28px) !important;
  height: clamp(16px, 4vw, 20px) !important;
  aspect-ratio: 5/4 !important;
  ```

**Pattern: Increase Minimum Size for Mobile Visibility**
- Set larger minimum sizes for mobile elements
- **Why**: Very small icons (16×12px) are hard to see on mobile
- **Implementation**: Increase minimum from 16×12px to 20×16px

**Pattern: Ensure Header Cells Have Sufficient Height**
- Add `min-height: 28px` to header cells
- **Why**: Provides adequate vertical space for icons
- **Implementation**:
  ```css
  th {
    min-height: 28px !important;
  }
  ```

## Tailwind v4 Color Configuration Issues

### Tailwind v4 Custom Color Generation Issues
**Pattern: Manual CSS Overrides for Custom Colors in Tailwind v4**
- When Tailwind v4 fails to generate custom color utilities, create manual CSS overrides
- **Why**: Tailwind v4's new engine (Oxide) has known bugs with nested color definitions and mixed-case keys
- **Common Symptoms**: 
  - Custom color classes like `bg-personal-primary-500` render as transparent
  - Border colors default to Tailwind's fallback colors (e.g., `blue-500` for `primary-500`)
  - Hover states don't work for custom colors
  - **Silent Failures**: No build errors shown, but CSS utilities are not generated

**Key Issues in Tailwind v4 (2026)**:
1. **Mixed-Case Parent Key Bug**: Nested color objects with mixed-case parent keys (e.g., `personalPrimary`) fail to generate utility classes. The Oxide engine reportedly only generates utilities reliably for lowercase-only parent keys (e.g., `personalprimary` or `personal-primary`).
2. **Silent Failures**: These bugs often fail "silently"—no build errors are shown, but the resulting CSS utilities (like `bg-personal-primary-500`) are not generated, even if they appear in your HTML.
3. **Specificity & Reset Conflicts**: In v4, reset styles cannot always be overridden by standard utility classes, leading to the manual use of `!important` as a workaround.
4. **@apply Limitations**: Issues with `@apply` failing to resolve nested or newly defined utility classes correctly in certain blocks have forced developers to use manual CSS overrides.

**Recommended Workarounds**:
1. **Rename to Lowercase**: Ensure all parent keys in your `tailwind.config.ts` or theme configuration use only lowercase letters to avoid the Oxide engine's parsing limitations.
2. **Manual CSS Variables**: Define the colors as CSS variables directly in your `@theme` block and reference them manually if the utility generation fails.
3. **Use `!important` sparingly**: While using `!important` works, it is often a fallback for when the engine fails to generate high-specificity classes for nested utilities.
4. **Manual CSS Overrides**: Create explicit CSS rules for critical color utilities that fail to generate.

**Implementation**:
```css
/* In index.css - Manual overrides for Tailwind v4 color issues */
.border-l-personal-primary-500 { border-left-color: #8B5CF6 !important; }
.border-l-commercial-primary-500 { border-left-color: #4F46E5 !important; }
.bg-personal-primary-500 { background-color: #8B5CF6 !important; }
.bg-commercial-primary-500 { background-color: #4F46E5 !important; }
.text-personal-primary-500 { color: #8B5CF6 !important; }
.text-commercial-primary-500 { color: #4F46E5 !important; }
.hover\\:bg-personal-primary-600:hover { background-color: #7C3AED !important; }
.hover\\:bg-commercial-primary-600:hover { background-color: #4338CA !important; }
```

**Debugging Steps**:
1. **Verify Color Generation**: Use Chrome DevTools MCP to test if custom color classes work:
   ```javascript
   // Test if bg-commercial-primary-500 renders correctly
   const testDiv = document.createElement('div');
   testDiv.className = 'bg-commercial-primary-500 p-4';
   document.body.appendChild(testDiv);
   const bgColor = getComputedStyle(testDiv).backgroundColor;
   console.log('Background color:', bgColor);
   ```

2. **Check for Hardcoded Overrides**: Search for existing CSS overrides that might be wrong:
   ```bash
   grep -r "border-l-personal-primary-500" src/
   grep -r "border-l-commercial-primary-500" src/
   ```

3. **Test Both Modes**: Verify colors work in both personal and commercial modes:
   ```javascript
   // Switch modes and test
   const modeButton = document.querySelector('button:contains("Коммерческий")');
   modeButton.click();
   setTimeout(() => {
     // Test colors in new mode
   }, 500);
   ```

4. **Check Tailwind Config**: Verify color definitions use lowercase keys:
   ```javascript
   // WRONG: Mixed-case keys may fail
   colors: {
     personalPrimary: { 500: '#8B5CF6' }
   }
   
   // CORRECT: Lowercase keys work better
   colors: {
     'personal-primary': { 500: '#8B5CF6' }
   }
   ```

**Root Cause Analysis**:
- **Mixed-Case Key Bug**: Tailwind v4's Oxide engine has parsing issues with mixed-case parent keys
- **Silent Failures**: Build process completes without errors but utilities are missing
- **CSS Specificity**: Reset styles in v4 have higher specificity, requiring `!important` overrides
- **@apply Limitations**: Cannot resolve newly defined utilities in certain contexts

**Prevention**:
1. **Use Lowercase Keys**: Always use lowercase or kebab-case keys in Tailwind configuration
2. **Test Color Generation**: Always test custom color utilities after configuration changes
3. **Use CSS Variables**: Define colors as CSS custom properties for better compatibility
4. **Verify Contrast Ratios**: Ensure colors meet WCAG 2.1 AA standards (4.5:1 minimum)
5. **Document Workarounds**: Keep manual CSS overrides documented for future maintenance

### Design System Color Verification
**Pattern: Automated Color Testing with Chrome DevTools MCP**
- Use programmatic testing to verify design system colors are correctly applied
- **Why**: Manual testing is error-prone; automated tests catch regressions
- **Implementation**:
  ```javascript
  // Test all border colors in the current mode
  const borderElements = Array.from(document.querySelectorAll('*')).filter(el => {
    const classes = Array.from(el.classList);
    return classes.some(c => c.startsWith('border-l-'));
  });
  
  const borderInfo = borderElements.map(el => ({
    classes: Array.from(el.classList).filter(c => c.startsWith('border-l-')),
    hexColor: rgbToHex(getComputedStyle(el).borderLeftColor),
  }));
  
  // Verify all borders have the same color in the current mode
  const allSameColor = new Set(borderInfo.map(b => b.hexColor)).size === 1;
  ```

## Project Maintenance Patterns

### Codebase Cleanup
**Pattern: Regular Cleanup of Backup and Temporary Files**
- Periodically search for and remove backup files (`.bak`, `.backup`, `.old`) and temporary directories
- **Why**: Keeps codebase clean, reduces confusion, and prevents accidental use of outdated files
- **Implementation**:
  ```bash
  # Find backup files
  find . -name "*.bak" -o -name "*.backup" -o -name "*.old"
  
  # Find temporary directories
  find . -type d -name "~" -o -name "tmp" -o -name "temp"
  ```

**Pattern: Verify Current Files Before Removing Backups**
- Always verify that current files are complete and functional before removing backups
- **Why**: Ensures you don't lose important functionality or data
- **Implementation**:
  1. Check if current file exists and has content
  2. Verify file compiles/works correctly
  3. Compare backup with current file to ensure no critical differences
  4. Only remove backup if current file is verified functional

**Pattern: Leave System/Tool Directories Unless Certain They're Unused**
- Don't delete directories created by development tools (Chrome debug, IDE temp files) unless certain they're unused
- **Why**: Development tools may rely on these directories; deleting them can break workflows
- **Implementation**:
  1. Check if processes are using the directory (e.g., `lsof | grep directory_name`)
  2. Look for recent file modifications
  3. If uncertain, leave directory intact or move to backup location

**Pattern: Document Cleanup Decisions in Memory Bank**
- Record cleanup decisions and reasoning in memory bank for future reference
- **Why**: Provides context for future developers and helps avoid repeating mistakes
- **Implementation**: Add entries to `raw_reflection_log.md` and update `activeContext.md` with cleanup details

### Memory Bank Maintenance
**Pattern: Update Memory Bank After Significant Changes**
- Always update memory bank files after completing significant work or cleanup
- **Why**: Ensures project documentation stays current and accurate
- **Implementation**:
  1. Update `raw_reflection_log.md` with detailed learnings
  2. Update `activeContext.md` with recent accomplishments
  3. Update `consolidated_learnings.md` with new patterns
  4. Update `progress.md` if applicable

**Pattern: Prune Raw Reflection Log After Consolidation**
- Remove processed entries from `raw_reflection_log.md` after transferring insights to `consolidated_learnings.md`
- **Why**: Keeps raw log focused on recent, unprocessed reflections
- **Implementation**: Periodically review raw log, extract patterns to consolidated learnings, then remove processed entries

## CSS Specificity & Validation Patterns

### When CSS `!important` Fails
**Pattern: JavaScript `setProperty` with `!important` as Workaround**
- Use `element.style.setProperty('property', 'value', 'important')` when CSS `!important` fails
- **Why**: CSS cascade order and specificity battles can prevent `!important` in stylesheets from winning
- **Implementation**:
  ```javascript
  // In useEffect or event handler
  useEffect(() => {
    const buttons = document.querySelectorAll('.action-button');
    buttons.forEach(btn => {
      btn.style.setProperty('height', '46px', 'important');
      btn.style.setProperty('min-height', '46px', 'important');
      btn.style.setProperty('max-height', '46px', 'important');
    });
  }, []);
  ```

**Pattern: Inline Styles as Last Resort for Critical Properties**
- Apply inline styles via JavaScript for properties that must win specificity battles
- **Why**: Inline styles have highest specificity (1,0,0,0) and can override all other styles
- **Implementation**:
  ```javascript
  // Apply inline styles to override conflicting CSS
  element.style.height = '46px';
  element.style.minHeight = '46px';
  element.style.maxHeight = '46px';
  ```

### Chrome DevTools MCP Validation Patterns
**Pattern: Comprehensive UI Validation with Programmatic Measurements**
- Use Chrome DevTools MCP `evaluate_script` for precise pixel-perfect validation
- **Why**: Manual inspection is error-prone; programmatic validation ensures accuracy
- **Implementation**:
  ```javascript
  // Validate mobile action button requirements
  const validateActionButtons = () => {
    const cell = document.querySelector('.actions-cell');
    const container = cell?.querySelector('.actions-container');
    const button = cell?.querySelector('.action-button');
    
    return {
      // 1. Reduced padding to 0
      cellPadding: getComputedStyle(cell).padding,
      buttonPadding: getComputedStyle(button).padding,
      
      // 2. Button dimensions
      buttonWidth: button?.clientWidth,
      buttonHeight: button?.clientHeight,
      
      // 3. 2px gap between buttons
      containerGap: getComputedStyle(container).gap,
      
      // 4. Cell height adjusted
      cellHeight: cell?.clientHeight,
      
      // 5. Icon fills button
      svg: button?.querySelector('svg'),
      svgObjectFit: getComputedStyle(button?.querySelector('svg')).objectFit,
      
      // 6. Actions-container fills whole cell
      containerWidth: container?.clientWidth,
      containerHeight: container?.clientHeight,
      
      // 7. Text hidden
      textSpan: button?.querySelector('span.hidden'),
      textDisplay: getComputedStyle(button?.querySelector('span.hidden')).display,
      
      // 8. Mobile media query active
      mediaQueryMatch: window.matchMedia('(max-width: 639px)').matches
    };
  };
  ```

**Pattern: Mobile Action Button Specifications**
- **Button Dimensions**: 50px × 46px (matches column width with reduced height)
- **Gap**: 2px vertical between buttons
- **Cell Height**: 94px total (46px × 2 buttons + 2px gap)
- **Icon Filling**: SVG 50px × 46px with `object-fit: contain`
- **Container Filling**: Actions-container fills whole cell (50px × 94px)
- **Text Hidden**: Only icons visible on mobile (`display: none`, `visibility: hidden`)
- **Padding**: 0px throughout (cell, container, button)

**Implementation**:
```css
/* CSS that should work (but may need JavaScript override) */
@media (max-width: 639px) {
  .stations-table-container td.actions-cell.px-4.py-3 {
    padding: 0px !important;
    height: 94px !important;
  }
  
  .stations-table-container .actions-container {
    gap: 2px !important;
    padding: 0px !important;
    height: 100% !important;
  }
  
  .stations-table-container .action-button {
    width: 100% !important;
    height: 46px !important;
    min-height: 46px !important;
    max-height: 46px !important;
    padding: 0px !important;
  }
  
  .stations-table-container .action-button svg {
    width: 100% !important;
    height: 100% !important;
    object-fit: contain !important;
  }
}
```

### Design System Colour Implementation
**Pattern: Apply UIShowcase Design Patterns Across Pages**
- Use consistent colour schemes from UIShowcase across all application pages
- **Personal Mode**: Vibrant purple (#8B5CF6) with playful gradient backgrounds
- **Commercial Mode**: Professional indigo (#4F46E5) with clean white backgrounds
- **Why**: Creates cohesive user experience and reinforces mode identity
- **Implementation**: Reference UIShowcase component implementations when styling other pages

**Pattern: Systematic Requirement Validation**
- Create validation functions that check all requirements programmatically
- **Why**: Ensures all specifications are met and provides documentation of compliance
- **Implementation**:
  ```javascript
  // Example validation function
  const validateAllRequirements = () => {
    const requirements = [
      { name: 'Padding 0px', check: () => getComputedStyle(cell).padding === '0px' },
      { name: 'Button 50×46px', check: () => button?.clientWidth === 50 && button?.clientHeight === 46 },
      { name: '2px gap', check: () => getComputedStyle(container).gap === '2px' },
      { name: 'Cell 94px height', check: () => cell?.clientHeight === 94 },
      { name: 'Icon fills button', check: () => svg?.clientWidth === 50 && svg?.clientHeight === 46 },
      { name: 'Container fills cell', check: () => container?.clientWidth === 50 && container?.clientHeight === 94 },
      { name: 'Text hidden', check: () => getComputedStyle(textSpan).display === 'none' },
      { name: 'Mobile media query', check: () => window.matchMedia('(max-width: 639px)').matches }
    ];
    
    return requirements.map(req => ({
      requirement: req.name,
      passed: req.check(),
      details: req.details?.() || ''
    }));
  };
  ```

## Quick Reference Cheatsheet

### Modal Implementation
```tsx
{/* Standard Modal Template */}
<div className="fixed inset-0 flex items-center justify-center p-4">
  <div 
    className="modal-responsive-container flex flex-col bg-white rounded-lg shadow-xl"
    style={{ 
      height: '80vh',
      maxHeight: '80vh',
      minHeight: '400px',
      backgroundColor: '#FFFFFF'
    }}
  >
    {/* Fixed header */}
    <div className="flex-shrink-0 p-6 border-b">
      Header
    </div>
    
    {/* Scrollable content */}
    <div className="flex-1 overflow-y-auto p-6">
      Content
    </div>
  </div>
</div>
```

### Mobile Tooltip Implementation
```tsx
{/* Mobile-Friendly Tooltip */}
const [showTooltip, setShowTooltip] = useState(false);
const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

const handleInteraction = () => {
  if (isTouchDevice) {
    // Mobile: Show on click, auto-dismiss
    setShowTooltip(true);
    setTimeout(() => setShowTooltip(false), 1000);
  } else {
    // Desktop: Show on hover
    setShowTooltip(true);
  }
};
```

### Form Validation & Error Messages

### Floating Error Messages Pattern
**Pattern: Tooltip-Style Error Messages for Form Validation**
- Use `relative` parent container with `absolute` positioned error tooltips
- **Why**: Provides clear, visually prominent error feedback positioned near the problematic field
- **Implementation**:
  ```tsx
  <div className="relative">
    <label htmlFor="field-name" className="block text-sm font-medium">
      Field Label *
    </label>
    <input
      id="field-name"
      name="field-name"
      type="text"
      className={`w-full border ${errors.field ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2`}
      value={value}
      onChange={handleChange}
    />
    {errors.field && (
      <div className="absolute z-50 -top-2 left-0 transform -translate-y-full">
        <div className="bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap">
          <AlertCircle size={14} className="flex-shrink-0" />
          <span>{errors.field}</span>
          <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger"></div>
        </div>
      </div>
    )}
  </div>
  ```

**Key Components**:
1. **Parent Container**: `relative` for absolute positioning context
2. **Error Tooltip Container**: `absolute z-50 -top-2 left-0 transform -translate-y-full`
   - `z-50`: Ensures tooltip appears above other elements
   - `-top-2`: Positions tooltip slightly above the input
   - `-translate-y-full`: Moves tooltip completely above the input
3. **Tooltip Content**: `bg-danger text-white text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap`
   - `bg-danger`: Red background for error indication
   - `text-white`: High contrast text
   - `shadow-lg`: Visual prominence
4. **Pointer Triangle**: `absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-danger`
   - Creates visual connection between tooltip and input field

**Accessibility Note**: Screen readers interpret tooltips as static text in the accessibility tree (expected behavior)

**Testing with Chrome DevTools MCP**:
```javascript
// Verify tooltip rendering and positioning
const errorDivs = document.querySelectorAll('div.absolute.z-50');
errorDivs.forEach(div => {
  const style = getComputedStyle(div);
  console.log({
    position: style.position,
    zIndex: style.zIndex,
    translate: style.translate,
    top: style.top
  });
});
```

## Form Accessibility
```tsx
{/* Accessible Form Field */}
<div>
  <label htmlFor="unique-field-id" className="block text-sm font-medium">
    Field Label
  </label>
  <input
    id="unique-field-id"
    name="unique-field-id"
    type="text"
    className="w-full p-2 border rounded"
    required
  />
</div>
```

---

## Last Updated: 2026-01-21
**Sources**: Raw reflection log entries from:
- 2026-01-21: Implement colour scheme UI for stations page and validate with Chrome MCP
- 2026-01-20: Clean up unused backup files and temporary directories
- 2026-01-20: Fix StationsTable responsive header issues (desktop icons visible, tablet column width)
- 2026-01-20: Fix StationsTable responsive header icon issues (mobile dual icons, tablet centering)
- 2026-01-16: Commercial mode border color fix (Tailwind v4 color generation issues)
- 2026-01-16: Test element investigation and cleanup
- 2026-01-15: ESLint error resolution and project analysis
- 2026-01-15: Create UI Design System Showcase page
- 2026-01-14: Fix status text display on desktop for both commercial and personal modes in Dashboard
- 2026-01-13: Fix header icon sizing issue - icons too small in narrow header cells
