import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AlertCircle } from 'lucide-react';
import type { TariffRule } from '../../types/tariff';
import { WEEK_DAYS } from '../../types/tariff';

interface TariffRuleVisualizerProps {
  rules: TariffRule[];
  basePricePerKwh: number;
}

// Color palette for rules (categorical colors - good contrast)
const RULE_COLORS = [
  '#1f77b4', // blue
  '#ff7f0e', // orange
  '#2ca02c', // green
  '#d62728', // red
  '#9467bd', // purple
  '#8c564b', // brown
  '#e377c2', // pink
  '#7f7f7f', // gray
  '#bcbd22', // olive
  '#17becf', // cyan
];

// Base tariff color (sky-500 from Tailwind)
const BASE_COLOR = '#0ea5e9'; // sky-500
const OVERLAP_COLOR = '#FF0000'; // pure red for overlaps

export const TariffRuleVisualizer: React.FC<TariffRuleVisualizerProps> = ({
  rules,
  basePricePerKwh,
}) => {
  const [hoveredCell, setHoveredCell] = useState<{ day: number; hour: number } | null>(null);
  const [clickedCell, setClickedCell] = useState<{ day: number; hour: number } | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const cellRefs = useRef<Array<Array<HTMLDivElement | null>>>([]);
  const tooltipTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const clickedCellRef = useRef<{ day: number; hour: number } | null>(null);

  // Initialize refs array
  useEffect(() => {
    cellRefs.current = Array(7).fill(null).map(() => Array(24).fill(null));
  }, []);

  // Update clickedCellRef when clickedCell changes
  useEffect(() => {
    clickedCellRef.current = clickedCell;
  }, [clickedCell]);

  // Auto-dismiss tooltip after 3 seconds and update position on scroll
  useEffect(() => {
    if (tooltipVisible && clickedCell) {
      if (tooltipTimeoutRef.current) {
        clearTimeout(tooltipTimeoutRef.current);
      }
      
      tooltipTimeoutRef.current = setTimeout(() => {
        setTooltipVisible(false);
        setClickedCell(null);
        setTooltipPosition(null);
      }, 3000);

      // Update tooltip position on scroll
      const updateTooltipPosition = () => {
        const currentClickedCell = clickedCellRef.current;
        if (!currentClickedCell) return;
        
        const cell = cellRefs.current[currentClickedCell.day]?.[currentClickedCell.hour];
        if (!cell) return;

        const rect = cell.getBoundingClientRect();
        // For fixed positioning, use viewport-relative coordinates (don't add scrollTop/scrollLeft)
        const x = rect.left + rect.width / 2;
        const y = rect.top - 15; // 15px above the cell

        setTooltipPosition({ x, y });
      };

      // Add scroll listener
      window.addEventListener('scroll', updateTooltipPosition, { passive: true });

      return () => {
        window.removeEventListener('scroll', updateTooltipPosition);
        if (tooltipTimeoutRef.current) {
          clearTimeout(tooltipTimeoutRef.current);
        }
      };
    }

    return () => {
      if (tooltipTimeoutRef.current) {
        clearTimeout(tooltipTimeoutRef.current);
      }
    };
  }, [tooltipVisible, clickedCell]);

  // Handle cell click for mobile tooltip
  const handleCellClick = (day: number, hour: number) => {
    const cell = cellRefs.current[day]?.[hour];
    if (!cell) return;

    // Get cell position for tooltip placement
    const rect = cell.getBoundingClientRect();
    // For fixed positioning, use viewport-relative coordinates (don't add scrollTop/scrollLeft)
    const x = rect.left + rect.width / 2;
    const y = rect.top - 15; // 15px above the cell

    setClickedCell({ day, hour });
    setTooltipPosition({ x, y });
    setTooltipVisible(true);

    // Clear any existing timeout
    if (tooltipTimeoutRef.current) {
      clearTimeout(tooltipTimeoutRef.current);
    }
  };

  // Check if device supports touch (mobile) - compute directly instead of using state
  const isTouchDevice = useMemo(() => {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  }, []);

  // Handle hover for desktop tooltip
  const handleMouseEnter = (day: number, hour: number) => {
    setHoveredCell({ day, hour });
    
    if (!isTouchDevice) {
      const cell = cellRefs.current[day]?.[hour];
      if (cell) {
        const rect = cell.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top - 15;
        setTooltipPosition({ x, y });
        setTooltipVisible(true);
      }
    }
  };

  const handleMouseLeave = () => {
    setHoveredCell(null);
    if (!isTouchDevice) {
      setTooltipVisible(false);
    }
  };

  // Transform rules to grid data
  const { gridData } = useMemo(() => {
    // Assign colors to rules
    const ruleColorMap = new Map<string, string>();
    rules.forEach((rule, index) => {
      ruleColorMap.set(rule.id, RULE_COLORS[index % RULE_COLORS.length]);
    });

    // Create 7x24 grid (days x hours)
    const grid: Array<Array<{
      ruleId: string | null;
      rulePrice: number | null;
      color: string;
      hasOverlap: boolean;
    }>> = [];

    // Initialize grid with base tariff
    for (let day = 0; day < 7; day++) {
      const row: Array<{
        ruleId: string | null;
        rulePrice: number | null;
        color: string;
        hasOverlap: boolean;
      }> = [];
      for (let hour = 0; hour < 24; hour++) {
        row.push({
          ruleId: null,
          rulePrice: null,
          color: BASE_COLOR,
          hasOverlap: false,
        });
      }
      grid.push(row);
    }

    // Apply rules to grid
    const overlapCells = new Set<string>();
    
    rules.forEach((rule) => {
      const ruleColor = ruleColorMap.get(rule.id);
      if (!ruleColor) {
        console.warn(`No color assigned for rule ${rule.id}`);
        return; // Skip this rule
      }
      
      // Parse start and end hours with validation
      const startHourMatch = rule.startTime.match(/^(\d{1,2}):/);
      const endHourMatch = rule.endTime.match(/^(\d{1,2}):/);
      
      if (!startHourMatch || !endHourMatch) {
        console.warn(`Invalid time format in rule ${rule.id}: startTime=${rule.startTime}, endTime=${rule.endTime}`);
        return; // Skip this rule
      }
      
      const startHour = parseInt(startHourMatch[1]);
      const endHour = parseInt(endHourMatch[1]);
      
      // Validate hour ranges
      if (startHour < 0 || startHour > 23 || endHour < 0 || endHour > 23) {
        console.warn(`Invalid hour range in rule ${rule.id}: startHour=${startHour}, endHour=${endHour}`);
        return; // Skip this rule
      }
      
      // Determine which days this rule applies to
      const daysToApply = rule.days === 'all' 
        ? [0, 1, 2, 3, 4, 5, 6] // All days (0=Monday, 6=Sunday)
        : rule.days.map(dayId => {
            // Data already uses 0-6 (Monday=0, Sunday=6)
            // Ensure day is within valid range
            return dayId >= 0 && dayId <= 6 ? dayId : null;
          }).filter((dayIndex): dayIndex is number => dayIndex !== null);
      
      // Apply rule to each applicable day and hour
      daysToApply.forEach(dayIndex => {
        // Handle the case where endHour might be 0 (midnight)
        // If endHour is 0, we want to apply until 23:59, so loop until 23
        const effectiveEndHour = endHour === 0 ? 24 : endHour;
        
        for (let hour = startHour; hour < effectiveEndHour; hour++) {
          const cellHour = hour % 24; // Wrap around if hour >= 24
          const cell = grid[dayIndex][cellHour];
          
          // Check for overlap
          if (cell.ruleId !== null && cell.ruleId !== rule.id) {
            cell.hasOverlap = true;
            cell.color = OVERLAP_COLOR;
            overlapCells.add(`${dayIndex}-${cellHour}`);
          } else if (!cell.hasOverlap) {
            cell.ruleId = rule.id;
            cell.rulePrice = rule.pricePerKwh;
            cell.color = ruleColor;
          }
        }
      });
    });

    // Mark all overlap cells as red
    overlapCells.forEach(cellKey => {
      const [day, hour] = cellKey.split('-').map(Number);
      grid[day][hour].color = OVERLAP_COLOR;
      grid[day][hour].hasOverlap = true;
    });

    return {
      gridData: grid,
    };
  }, [rules]);

  // Get hover tooltip content
  const getTooltipContent = (day: number, hour: number) => {
    const cell = gridData[day][hour];
    
    if (cell.hasOverlap) {
      return 'Пересечение правил';
    }
    
    if (cell.rulePrice !== null) {
      return `${cell.rulePrice}₽/кВч`;
    }
    
    return `${basePricePerKwh}₽/кВч`;
  };

  // Note: formatHour function removed as it's not currently used
  // const _formatHour = (hour: number) => {
  //   return `${hour.toString().padStart(2, '0')}:00`;
  // };

  // Get day label
  const getDayLabel = (dayIndex: number) => {
    return WEEK_DAYS[dayIndex].label;
  };

  return (
    <div className="space-y-4 relative">
      {/* Tooltip (Mobile & Desktop) */}
      {tooltipVisible && tooltipPosition && (clickedCell || hoveredCell) && (
        <div
          className="fixed z-50 pointer-events-none"
          style={{
            left: `${tooltipPosition.x}px`,
            top: `${tooltipPosition.y}px`,
            transform: 'translate(-50%, -100%)',
          }}
        >
          <div 
            className="text-sm font-bold px-3 py-2 rounded-lg shadow-lg whitespace-nowrap"
            style={{
              backgroundColor: '#101828', // ink color as fallback
              color: '#ffffff', // white text as fallback
            }}
          >
            {getTooltipContent(
              (clickedCell || hoveredCell)!.day, 
              (clickedCell || hoveredCell)!.hour
            )}
            {/* Tooltip arrow */}
            <div 
              className="absolute left-1/2 top-full -translate-x-1/2"
              style={{
                width: 0,
                height: 0,
                borderLeft: '6px solid transparent',
                borderRight: '6px solid transparent',
                borderTop: '6px solid #101828',
              }}
            />
          </div>
        </div>
      )}

      {/* Schedule Grid */}
      <div className="bg-bg-2 rounded-lg p-4">

        {/* Grid Container */}
        <div className="overflow-x-auto relative">
          <div className="min-w-[600px]">
            {/* Grid Rows (Days) */}
            <div className="flex flex-col">
              {gridData.map((dayRow, dayIndex) => (
                <div 
                  key={dayIndex} 
                  className={`flex bg-white ${dayIndex < 6 ? 'border-b-2 border-bg-2' : ''}`}
                  style={{ height: '44px' }}
                >
                  {/* Day Label - Sticky for horizontal scrolling */}
                  <div 
                    className="min-w-[4rem] min-h-11 flex-shrink-0 flex items-center justify-center sticky z-20"
                    style={{ left: 0, backgroundColor: '#ffffff' }}
                  >
                    <span className="text-xs font-bold text-ink text-center">
                      {getDayLabel(dayIndex)}
                    </span>
                  </div>

                  {/* Grid Cells */}
                  <div 
                    className="flex-1 grid gap-px bg-white"
                    style={{ gridTemplateColumns: 'repeat(24, minmax(0, 1fr))' }}
                  >
                    {dayRow.map((cell, hour) => (
                      <div
                        key={hour}
                        ref={(el) => {
                          if (cellRefs.current[dayIndex]) {
                            cellRefs.current[dayIndex][hour] = el;
                          }
                        }}
                        className={`
                          relative h-11 min-w-0 transition-all duration-150 cursor-pointer
                          ${hoveredCell?.day === dayIndex && hoveredCell?.hour === hour 
                            ? 'ring-2 ring-red-500 ring-inset z-10' 
                            : 'hover:ring-1 hover:ring-red-500/50 hover:ring-inset'
                          }
                          ${clickedCell?.day === dayIndex && clickedCell?.hour === hour
                            ? 'ring-2 ring-red-500 ring-inset z-10'
                            : ''
                          }
                          ${cell.hasOverlap ? 'border border-red-500' : ''}
                        `}
                        style={{ 
                          backgroundColor: cell.color,
                          // Add inline styles for red border when clicked - 4px thick (was 2px)
                          ...(clickedCell?.day === dayIndex && clickedCell?.hour === hour ? {
                            boxShadow: '0 0 0 4px #ef4444 inset'
                          } : {}),
                          // Add inline styles for red border when hovered - 4px thick (was 2px)
                          ...(hoveredCell?.day === dayIndex && hoveredCell?.hour === hour ? {
                            boxShadow: '0 0 0 4px #ef4444 inset'
                          } : {})
                        }}
                        onMouseEnter={() => handleMouseEnter(dayIndex, hour)}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => {
                          // Only show mobile tooltip on touch devices
                          if (isTouchDevice) {
                            handleCellClick(dayIndex, hour);
                          }
                        }}
                      >
                        {/* Overlap warning icon */}
                        {cell.hasOverlap && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <AlertCircle size={12} className="text-white" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Hour Labels at Bottom */}
            <div className="flex mt-4">
              <div 
                className="min-w-[4rem] min-h-11 flex-shrink-0 sticky z-20"
                style={{ left: 0, backgroundColor: '#ffffff' }}
              ></div>
              <div 
                className="flex-1 grid gap-px bg-white"
                style={{ gridTemplateColumns: 'repeat(24, minmax(0, 1fr))' }}
              >
                {Array.from({ length: 24 }, (_, hour) => (
                  <div 
                    key={hour}
                    className="min-w-0 flex items-center justify-center"
                  >
                    <span className="text-xs text-muted text-center truncate w-full">
                      {hour}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Rule Legend (Horizontal) - Separate container, stays put */}
        {rules.length > 0 && (
          <div className="mt-6 bg-bg-2 rounded-lg p-4">
            <div className="flex flex-wrap gap-8">
              {rules.map((rule, index) => (
                <div 
                  key={rule.id}
                  className="flex items-center space-x-2 text-sm border-2 rounded-md px-3 py-2 shadow-md bg-white"
                  style={{ borderColor: RULE_COLORS[index % RULE_COLORS.length] }}
                >
                  <div 
                    className="w-[1em] h-[1em] rounded-sm"
                    style={{ backgroundColor: RULE_COLORS[index % RULE_COLORS.length] }}
                  />
                  <span className="text-ink font-medium">
                    {rule.pricePerKwh}₽/кВч
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Empty State */}
      {rules.length === 0 && (
        <div className="bg-bg-2 rounded-lg p-6 text-center">
          <div className="flex flex-col items-center">
            <div 
              className="w-12 h-12 rounded-lg mb-3 flex items-center justify-center"
              style={{ backgroundColor: BASE_COLOR }}
            />
            <p className="text-muted">Правила не настроены</p>
            <p className="text-sm text-muted mt-1">
              {basePricePerKwh}₽/кВч
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
