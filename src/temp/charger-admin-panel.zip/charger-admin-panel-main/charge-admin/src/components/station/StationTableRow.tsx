import React, { memo } from 'react';
import { StationStatusBadge } from '../ui/StatusBadge';
import { Button } from '../ui/Button';
import { Eye, Edit, Trash2 } from 'lucide-react';
import type { Station } from '../../data/stations';
import { StationDetailView } from './StationDetailView';

interface StationTableRowProps {
  station: Station;
  /** Flag indicating whether this station's details are currently expanded */
  isViewing: boolean;
  /** Called to toggle viewing on; parent maintains which station is expanded */
  onView: (station: Station) => void;
  /** Called to collapse the detail view */
  onCloseView: () => void;
  /** Called when the user chooses to edit this station */
  onEdit: (station: Station) => void;
  /** Called when the user chooses to delete this station */
  onDelete: (id: string) => void;
  /** Disable edit button (e.g., when another station is being edited/added) */
  isEditDisabled?: boolean;
  /** Disable delete button (e.g., when any operation is in progress) */
  isDeleteDisabled?: boolean;
  /** Disable view button (e.g., when any operation is in progress) */
  isViewDisabled?: boolean;
}

export const StationTableRow: React.FC<StationTableRowProps> = memo(({
  station,
  isViewing,
  onView,
  onCloseView,
  onEdit,
  onDelete,
  isEditDisabled = false,
  isDeleteDisabled = false,
  isViewDisabled = false,
}) => {
  return (
    <>
      {/* Main table row */}
      <tr className="border-b border-bg-2 hover:bg-bg-1">
        {/* Status column */}
        <td className="py-3 px-4">
          <StationStatusBadge status={station.status} />
        </td>
        
        {/* Name column */}
        <td className="py-3 px-4">
          <div>
            <p className="font-medium text-ink">{station.name}</p>
          </div>
        </td>
        
        {/* Power column */}
        <td className="py-3 px-4">
          <span className="font-medium text-ink">{station.power} кВт</span>
        </td>
        
        {/* Ports column */}
        <td className="py-3 px-4">
          <span className="text-ink">{station.ports}</span>
        </td>
        
        {/* Tariff column */}
        <td className="py-3 px-4">
          <span className="text-sm text-ink">{station.tariffName || 'Не назначен'}</span>
        </td>
        
        {/* Actions column */}
        <td className="py-3 px-4">
          <div className="flex items-center space-x-2">
            {/* View button */}
            <Button
              variant="ghost"
              size="sm"
              icon={Eye}
              disabled={isViewDisabled}
              onClick={() => {
                if (isViewing) {
                  onCloseView();
                } else {
                  onView(station);
                }
              }}
            >
              {isViewing ? 'Скрыть' : 'Просмотр'}
            </Button>
            
            {/* Edit button - hide when this station is being edited (showing edit form) */}
            {!isEditDisabled && (
              <Button 
                variant="icon" 
                size="sm" 
                onClick={() => onEdit(station)}
                disabled={isEditDisabled}
              >
                <Edit size={16} />
              </Button>
            )}
            
            {/* Delete button */}
            <Button 
              variant="icon" 
              size="sm" 
              onClick={() => onDelete(station.id)}
              disabled={isDeleteDisabled}
            >
              <Trash2 size={16} />
            </Button>
          </div>
        </td>
      </tr>
      
      {/* Expanded detail view row */}
      {isViewing && (
        <tr>
          <td colSpan={6} className="p-0">
            <div className="px-4 py-3">
              <StationDetailView station={station} onClose={onCloseView} />
            </div>
          </td>
        </tr>
      )}
    </>
  );
});

StationTableRow.displayName = 'StationTableRow';
