import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent, CardFooter } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { EnergyChart } from '../components/ui/EnergyChart';
import { SmartGrid } from '../components/ui/SmartGrid';
import { useMode } from '../contexts/useMode';
import { 
  Battery, 
  Zap, 
  Clock, 
  DollarSign, 
  Plus, 
  Play, 
  StopCircle,
  Info,
  AlertTriangle,
  Building,
  CreditCard,
  MapPin,
  MoreVertical
} from 'lucide-react';

// Import mock data from /data folder
import { mockStations } from '../data/dashboard-stations';
import { mockEnergyData } from '../data/energy';

export const Dashboard: React.FC = () => {
  const { mode } = useMode();
  const navigate = useNavigate();
  const [personalStations, setPersonalStations] = useState(mockStations.slice(0, 3));
  const [commercialStations, setCommercialStations] = useState(mockStations);

  const handleAddStation = () => {
    navigate('/stations', { state: { openAddModal: true } });
  };

  // Toggle station status for personal mode
  const toggleStationStatus = (id: string) => {
    setPersonalStations(prev => prev.map(station => 
      station.id === id 
        ? { 
            ...station, 
            status: station.status === 'charging' ? 'ready' : 'charging' 
          }
        : station
    ));
    console.log(`Toggled personal station ${id}`);
  };

  // Toggle station status for commercial mode
  const toggleCommercialStationStatus = (id: string) => {
    setCommercialStations(prev => prev.map(station => 
      station.id === id 
        ? { 
            ...station, 
            status: station.status === 'charging' ? 'ready' : 'charging' 
          }
        : station
    ));
    console.log(`Toggled commercial station ${id}`);
  };

  // Status mapping function from UIShowcase pattern
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'ready': return 'success';
      case 'charging': return 'info';
      case 'pending': return 'warning';
      case 'fault': return 'danger';
      case 'offline': return 'offline';
      default: return 'info';
    }
  };

  // Showcase-specific design tokens from UIShowcase
  const showcaseTokens = {
    personal: {
      primary: 'bg-personal-primary-500',
      secondary: 'bg-personal-secondary-500',
      accent: 'bg-personal-accent-500',
      background: 'bg-personal-background-DEFAULT',
      surface: 'bg-personal-surface-DEFAULT',
      textPrimary: 'text-personal-text-primary',
      textSecondary: 'text-personal-text-secondary',
      border: 'border-personal-primary-200',
      hover: 'hover:bg-personal-primary-100',
      focus: 'focus:ring-personal-primary-300',
    },
    commercial: {
      primary: 'bg-commercial-primary-500',
      secondary: 'bg-commercial-secondary-500',
      accent: 'bg-commercial-accent-500',
      background: 'bg-commercial-background-DEFAULT',
      surface: 'bg-commercial-surface-DEFAULT',
      textPrimary: 'text-commercial-text-primary',
      textSecondary: 'text-commercial-text-secondary',
      border: 'border-commercial-primary-300',
      hover: 'hover:bg-commercial-primary-100',
      focus: 'focus:ring-commercial-primary-300',
    }
  };

  const tokens = showcaseTokens[mode];
  const hoverClass = mode === 'personal' ? 'hover:bg-personal-primary-600' : 'hover:bg-commercial-primary-600';
  const secondaryHoverClass = mode === 'personal' ? 'hover:bg-personal-secondary-600' : 'hover:bg-commercial-secondary-600';
  const leftBorderClass = mode === 'personal' ? 'border-l-personal-primary-500' : 'border-l-commercial-primary-500';

  // Temporary inline styles for mobile table headers
  const tempStyles = `
    @media (max-width: 639px) {
      /* Make mobile header icons 150% larger with current size as minimum */
      th svg.w-6.h-4 {
        /* Current size (24px) as minimum at 320px, scales to ~150% larger */
        /* Width: scales from 24px (320px) to 42px (430px) */
        width: clamp(24px, 10vw, 42px) !important;
        /* Height: scales from 16px (320px) to 28px (430px) - maintains 3:2 aspect ratio */
        height: clamp(16px, 6.67vw, 28px) !important;
        /* Ensure minimum and maximum constraints */
        min-width: 24px !important;
        min-height: 16px !important;
        max-width: 42px !important;
        max-height: 28px !important;
        /* Maintain 3:2 aspect ratio (same as current) */
        aspect-ratio: 3/2 !important;
      }
      
      /* Increase header cell height to accommodate larger icons */
      th {
        min-height: 40px !important;
        height: auto !important;
      }
      
      /* Ensure header cell content is properly centered */
      th div.flex.items-center.justify-center {
        min-height: 36px !important;
        align-items: center !important;
      }
      
      /* Center align mobile header icons */
      th div.flex.items-center.justify-center {
        justify-content: center !important;
        text-align: center !important;
      }
    }
    
    @media (min-width: 640px) {
      /* Make sure desktop header text is visible and icons are hidden */
      th span.sm\\:hidden {
        display: none !important;
      }
      th span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Reset icon sizes on desktop */
      th svg.w-6.h-4 {
        width: auto !important;
        height: auto !important;
      }
    }
  `;

  return (
    <div 
      data-mode={mode}
      className={`min-h-screen ${tokens.background} p-4 md:p-8 xl:p-12`}
    >
      {/* Temporary style tag for mobile table headers */}
      <style dangerouslySetInnerHTML={{ __html: tempStyles }} />
      
      {/* Sticky Navigation Header - UIShowcase pattern */}
      <div className={`sticky top-0 z-40 mb-8 ${tokens.surface}/80 backdrop-blur-sm border-b ${tokens.border} -mx-4 md:-mx-8 xl:-mx-12 px-4 md:px-8 xl:px-12 py-3 xl:py-4`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between" style={{ gap: '16px' }}>
          <div>
            <h1 className={`text-display-sm md:text-display-md xl:text-display-lg font-bold ${tokens.textPrimary}`}>
              Панель управления
            </h1>
            <p className={`mt-1 text-body-sm md:text-body-md xl:text-body-lg ${tokens.textSecondary}`}>
              {mode === 'commercial' 
                ? 'Обзор ваших зарядных станций и активности' 
                : 'Мои зарядные станции'}
            </p>
          </div>
          
          <div className="flex items-center gap-4 xl:gap-6">
            <Button 
              icon={Plus} 
              onClick={handleAddStation}
              variant="primary"
              size="md"
              className={`inline-flex truncate min-w-fit text-sm md:text-base ${tokens.primary} ${hoverClass}`}
            >
              {mode === 'commercial' ? 'Добавить станцию' : 'Добавить Станцию'}
            </Button>
          </div>
        </div>
      </div>

      {/* Mode Info Banner - UIShowcase pattern */}
      <div className={`mb-8 p-4 border ${tokens.border} rounded-lg bg-gradient-to-r from-brand/5 to-transparent`}>
        <div className="flex items-center gap-3">
          <Info size={20} className="text-brand flex-shrink-0" />
          <div>
            <p className={`text-sm font-medium ${tokens.textPrimary}`}>
              Текущий режим: <span className="font-semibold">{mode === 'personal' ? 'Персональный' : 'Коммерческий'}</span>
            </p>
            <p className={`text-xs ${tokens.textSecondary} mt-1`}>
              {mode === 'personal' 
                ? 'Управление личными зарядными станциями и статистика' 
                : 'Расширенная аналитика и управление коммерческими станциями'}
            </p>
          </div>
        </div>
      </div>

      {mode === 'commercial' ? (
        <>
          {/* Commercial mode: KPI Dashboard with UIShowcase metric card pattern */}
          <section className="mb-12">
            <h2 className={`text-heading-md xl:text-heading-lg font-semibold ${tokens.textPrimary} mb-6 xl:mb-8`}>
              Ключевые метрики
            </h2>
            <SmartGrid minColumnWidth={140} maxColumns={5} gap={4} matchHeights={true} mobileOptimization={true} hoverMargin={0} margin={4}>
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <Battery className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Активные станции</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>Всего станций в сети</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>8</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>из 12</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <Clock className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Сессии сегодня</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>Всего сессий за день</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>24</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>сессии</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <Zap className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Энергия</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>кВт·ч за неделю</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>1,248</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>кВт·ч</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <DollarSign className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Доход</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>Общая выручка</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>45,620</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>руб</span>
                    </div>
                  </div>
                </div>
              </div>
            </SmartGrid>
          </section>

          {/* Energy Chart Section */}
          <section className="mb-12">
            <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
              Потребление энергии
            </h2>
            <Card variant="filled">
              <CardContent className="p-6">
                <EnergyChart 
                  data={mockEnergyData}
                  title="Потребление энергии за неделю"
                  height={250}
                />
              </CardContent>
            </Card>
          </section>

          {/* Stations Table Section - UIShowcase pattern */}
          <section className="mb-12">
            <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
              Станции в сети
            </h2>
            <Card variant="filled">
              <CardHeader 
                title="Обзор всех станций" 
                description="Управление зарядными станциями и мониторинг статуса"
              />
              <CardContent className="xl:p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-bg-2">
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted">
                          <div className="flex items-center justify-center sm:justify-start">
                            <span className="sm:hidden">
                              <AlertTriangle className="w-6 h-4 text-muted" />
                            </span>
                            <span className="hidden sm:inline">Статус</span>
                          </div>
                        </th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted">
                          <div className="flex items-center justify-center sm:justify-start">
                            <span className="sm:hidden">
                              <Building className="w-6 h-4 text-muted" />
                            </span>
                            <span className="hidden sm:inline">Устройство</span>
                          </div>
                        </th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted">
                          <div className="flex items-center justify-center sm:justify-start">
                            <span className="sm:hidden">
                              <CreditCard className="w-6 h-4 text-muted" />
                            </span>
                            <span className="hidden sm:inline">Тариф</span>
                          </div>
                        </th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted hidden sm:table-cell">Мощность</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted hidden sm:table-cell">Сессии</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted">
                          <div className="flex items-center justify-center sm:justify-start">
                            <span className="sm:hidden">
                              <MapPin className="w-6 h-4 text-muted" />
                            </span>
                            <span className="hidden sm:inline">Локация</span>
                          </div>
                        </th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted">
                          <div className="flex items-center justify-center sm:justify-start">
                            <span className="sm:hidden">
                              <MoreVertical className="w-6 h-4 text-muted" />
                            </span>
                            <span className="hidden sm:inline">Действия</span>
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {commercialStations.map((station) => (
                        <tr key={station.id} className="border-b border-bg-1 hover:bg-bg-2">
                          <td className="py-3 px-4">
                            <StatusBadge
                              status={getStatusBadgeVariant(station.status)}
                              label={station.status === 'ready' ? 'Готова' : 
                                     station.status === 'charging' ? 'Заряжает' :
                                     station.status === 'pending' ? 'Ожидание' :
                                     station.status === 'fault' ? 'Неисправность' : 'Оффлайн'}
                            />
                          </td>
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium text-ink">{station.name}</p>
                              <p className="text-sm text-muted font-mono hidden sm:block">{station.id}</p>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-sm text-ink">Базовый</span>
                          </td>
                          <td className="py-3 px-4 hidden sm:table-cell">
                            <span className="font-medium text-ink">{station.power} кВт</span>
                          </td>
                          <td className="py-3 px-4 hidden sm:table-cell">
                            <span className="text-ink">{station.sessionsToday}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-sm text-ink">{station.location}</span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex" style={{ gap: '8px' }}>
                              <Button 
                                variant={station.status === 'charging' ? 'secondary' : 'primary'}
                                size="sm" 
                                icon={station.status === 'charging' ? StopCircle : Play}
                                data-station-id={station.id}
                                tabIndex={-1}
                                onClick={() => {
                                  toggleCommercialStationStatus(station.id);
                                  
                                  // Function to ensure the entire table is visible
                                  const ensureTableVisible = () => {
                                    // Get the table element
                                    const table = document.querySelector('table');
                                    if (!table) return;
                                    
                                    // Get the bottom navigation bar height
                                    const nav = document.querySelector('nav');
                                    const navHeight = nav ? nav.getBoundingClientRect().height : 0;
                                    
                                    const rect = table.getBoundingClientRect();
                                    const windowHeight = window.innerHeight;
                                    const availableHeight = windowHeight - navHeight;
                                    
                                    // Calculate the scroll position needed to make the entire table visible
                                    // We want the table to be fully within the available viewport (above navigation bar)
                                    const tableTop = rect.top + window.scrollY;
                                    const tableBottom = rect.bottom + window.scrollY;
                                    
                                    // If table bottom is below available viewport, scroll up to show it
                                    if (tableBottom > window.scrollY + availableHeight) {
                                      const scrollToPosition = tableBottom - availableHeight;
                                      window.scrollTo(0, scrollToPosition);
                                    }
                                    // If table top is above viewport, scroll down to show it
                                    else if (tableTop < window.scrollY) {
                                      window.scrollTo(0, tableTop);
                                    }
                                    // Otherwise, table is already fully visible
                                  };
                                  
                                  // Try multiple times with different delays
                                  // The browser might scroll multiple times, so we need to be persistent
                                  ensureTableVisible();
                                  setTimeout(ensureTableVisible, 10);
                                  setTimeout(ensureTableVisible, 50);
                                  setTimeout(ensureTableVisible, 100);
                                  setTimeout(ensureTableVisible, 200);
                                  setTimeout(ensureTableVisible, 500);
                                  
                                  // Also try on animation frames
                                  requestAnimationFrame(ensureTableVisible);
                                  requestAnimationFrame(() => {
                                    requestAnimationFrame(ensureTableVisible);
                                  });
                                  requestAnimationFrame(() => {
                                    setTimeout(() => {
                                      requestAnimationFrame(ensureTableVisible);
                                    }, 100);
                                  });
                                }}
                                aria-label={station.status === 'charging' ? 'Остановить станцию' : 'Запустить станцию'}
                                className={`${station.status === 'charging' ? tokens.secondary : tokens.primary} ${station.status === 'charging' ? secondaryHoverClass : hoverClass} w-full sm:w-auto sm:min-w-[100px]`}
                              >
                                <span className="hidden sm:inline">
                                  {station.status === 'charging' ? 'Остановить' : 'Запустить'}
                                </span>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
              <CardFooter align="center">
                <Button variant="ghost">Загрузить больше</Button>
              </CardFooter>
            </Card>
          </section>
        </>
      ) : (
        <>
          {/* Personal mode: My Stations Section - UIShowcase pattern */}
          <section className="mb-12 scroll-mt-20">
            <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
              Мои станции
            </h2>
            <SmartGrid minColumnWidth={280} maxColumns={3} gap="lg" matchHeights={true} mobileOptimization={true} hoverMargin={0} margin={16}>
              {personalStations.map((station) => (
                <Card 
                  key={station.id} 
                  variant="elevated" 
                  hover 
                  shadow="sm"
                  animation="fade-in"
                  className="h-full overflow-hidden"
                >
                  <CardContent className="p-6 pb-[6px] flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <StatusBadge
                          status={getStatusBadgeVariant(station.status)}
                          label={station.status === 'ready' ? 'Готова' : 
                                 station.status === 'charging' ? 'Заряжает' :
                                 station.status === 'pending' ? 'Ожидание' :
                                 station.status === 'fault' ? 'Неисправность' : 'Оффлайн'}
                        />
                        <div>
                          <h3 className="text-heading-sm font-semibold text-ink">{station.name}</h3>
                          <p className="text-body-sm text-muted font-mono">{station.id}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3 mb-4">
                      <div className="flex justify-between items-center">
                        <span className="text-body-sm text-muted">Мощность:</span>
                        <span className="text-body-sm font-medium text-ink">{station.power} кВт</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-body-sm text-muted">Сегодня:</span>
                        <span className="text-body-sm font-medium text-ink">{station.sessionsToday} сессий</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-body-sm text-muted">Локация:</span>
                        <span className="text-body-sm font-medium text-ink truncate" title={station.location}>{station.location}</span>
                      </div>
                    </div>
                    
                    <div className="overflow-hidden flex justify-center mt-auto" style={{ maxWidth: '100%', paddingTop: '0px' }}>
                      <Button
                        variant={station.status === 'charging' ? 'secondary' : 'primary'}
                        size="lg"
                        className={`inline-flex items-center justify-center ${station.status === 'charging' ? showcaseTokens.personal.secondary : showcaseTokens.personal.primary} ${station.status === 'charging' ? 'hover:bg-personal-secondary-600' : 'hover:bg-personal-primary-600'}`}
                        style={{ 
                          minWidth: '144px', // 120px + 20%
                          maxWidth: '100%', 
                          boxSizing: 'border-box',
                          fontSize: '20px', // 16px + 20% ≈ 19.2px, rounded to 20px
                          height: '53px', // 44px + 20% ≈ 52.8px, rounded to 53px
                          padding: '0px 20px' // Increased padding for larger button
                        }}
                        onClick={() => toggleStationStatus(station.id)}
                        aria-label={station.status === 'charging' ? 'Остановить станцию' : 'Запустить станцию'}
                      >
                        <span className="flex items-center gap-2">
                          {station.status === 'charging' ? (
                            <StopCircle size={28} style={{ minWidth: '28px', minHeight: '28px' }} /> // 24px + 20% ≈ 28.8px
                          ) : (
                            <Play size={28} style={{ minWidth: '28px', minHeight: '28px' }} /> // 24px + 20% ≈ 28.8px
                          )}
                          {station.status === 'charging' ? 'Остановить' : 'Запустить'}
                        </span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </SmartGrid>
          </section>

          {/* Personal mode: Quick Stats Section - Updated to match commercial mode KPI cards */}
          <section className="mb-12 scroll-mt-20">
            <h2 className={`text-heading-md xl:text-heading-lg font-semibold ${tokens.textPrimary} mb-6 xl:mb-8`}>
              Моя статистика
            </h2>
            <SmartGrid minColumnWidth={140} maxColumns={5} gap={4} matchHeights={true} mobileOptimization={true} hoverMargin={0} margin={4}>
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <Zap className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Сегодняшняя зарядка</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>Потребление энергии за день</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>42</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>кВт·ч</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className={`${tokens.surface} border ${tokens.border} rounded-xl border-l-4 ${leftBorderClass} transition-all duration-200 md:hover:shadow-md md:hover:scale-[1.02] md:hover:border-mode-border box-border`} style={{ padding: '10px' }}>
                <div className="flex flex-col h-full" style={{ gap: '1px' }}>
                  {/* Icon in top-left corner */}
                  <div style={{ marginBottom: '0px' }}>
                    <div className="p-1.5 rounded-lg bg-brand/10 inline-flex">
                      <Clock className="h-5 w-5 text-brand" />
                    </div>
                  </div>
                  
                  {/* All text under icon, left-aligned */}
                  <div style={{ marginBottom: '1px' }}>
                    <h3 className={`font-semibold ${tokens.textPrimary}`} style={{ fontSize: '18px', lineHeight: '1', margin: '0', padding: '0' }}>Время зарядки</h3>
                    <p className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', marginTop: '0px', padding: '0' }}>Средняя длительность сессии</p>
                  </div>
                  
                  {/* Value at bottom, no green arrow - reduced spacing from text above */}
                  <div className="mt-auto" style={{ paddingTop: '2px', marginTop: 'auto' }}>
                    <div className="flex items-baseline" style={{ gap: '1px' }}>
                      <span className={`font-bold ${tokens.textPrimary}`} style={{ fontSize: '23px', lineHeight: '1', margin: '0', padding: '0' }}>3 ч 42 мин</span>
                      <span className={`${tokens.textSecondary}`} style={{ fontSize: '15px', lineHeight: '1', margin: '0', padding: '0' }}>сегодня</span>
                    </div>
                  </div>
                </div>
              </div>
            </SmartGrid>
          </section>

          {/* Personal mode: Energy Chart Section */}
          <section className="mb-12 scroll-mt-20">
            <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
              Мое потребление энергии
            </h2>
            <Card variant="filled">
              <CardContent className="p-6">
                <EnergyChart 
                  data={mockEnergyData}
                  title="Потребление энергии за неделю"
                  height={250}
                />
              </CardContent>
            </Card>
          </section>
        </>
      )}

    </div>
  );
};
