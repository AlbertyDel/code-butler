import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
// Import modal components
import { StationModal } from '../components/station/StationModal';
import { StationDetailsModal } from '../components/station/StationDetailsModal';
// Import table component
import { StationsTable } from '../components/station/StationsTable';
import {
  Plus,
} from 'lucide-react';

// Import the default station data and persistent storage hook
import type { Station } from '../data/stations';
import { defaultStations, generateStationTechnicalParameters } from '../data/stations';
import { usePersistentData } from '../hooks/usePersistentData';
import { useMode } from '../contexts/useMode';
import { useTariff } from '../contexts/useTariff';

// Mode-specific design tokens for Stations page
const stationTokens = {
  personal: {
    primary: 'bg-personal-primary-500',
    primaryHover: 'hover:bg-personal-primary-600',
    border: 'border-l-personal-primary-500',
    text: 'text-personal-text-primary',
    textSecondary: 'text-personal-text-secondary',
    cardBorder: 'border-l-personal-primary-500',
    buttonPrimary: 'bg-personal-primary-500 hover:bg-personal-primary-600',
    focus: 'focus:ring-personal-primary-300',
    surface: 'bg-personal-surface-DEFAULT',
    background: 'bg-personal-background-DEFAULT',
  },
  commercial: {
    primary: 'bg-commercial-primary-500',
    primaryHover: 'hover:bg-commercial-primary-600',
    border: 'border-l-commercial-primary-500',
    text: 'text-commercial-text-primary',
    textSecondary: 'text-commercial-text-secondary',
    cardBorder: 'border-l-commercial-primary-500',
    buttonPrimary: 'bg-commercial-primary-500 hover:bg-commercial-primary-600',
    focus: 'focus:ring-commercial-primary-300',
    surface: 'bg-commercial-surface-DEFAULT',
    background: 'bg-commercial-background-DEFAULT',
  }
};

// Функция для нормализации данных станций (исправление некорректных значений)
const normalizeStations = (stations: Station[]): Station[] => {
  return stations.map(station => {
    const normalizedStation = {
      ...station,
      // Мощность должна быть одной из допустимых значений (7, 11, 22)
      power: [7, 11, 22].includes(station.power) ? station.power : 11,
      // Портов может быть только 1 или 2
      ports: station.ports === 1 || station.ports === 2 ? station.ports : 2,
    };
    // Добавляем tariffName если его нет
    if (!normalizedStation.tariffName) {
      normalizedStation.tariffName = 'Базовый';
    }
    return normalizedStation;
  });
};


export const Stations: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Use the persistent data hook to load stations from localStorage or use the default stations on first run
  const [stations, setStations] = usePersistentData<Station[]>(
    'stations',
    normalizeStations(defaultStations as Station[])
  );
  
  // State for modals
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [editingStation, setEditingStation] = useState<Station | null>(null);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  
  // Get current mode
  const { mode: appMode } = useMode();
  useTariff(); // Keep for context but don't use tariffs directly

  // Get mode-specific tokens
  const tokens = stationTokens[appMode];

  // Sort stations by name ascending
  const sortedStations = [...stations].sort((a, b) => a.name.localeCompare(b.name));
  
  // Temporary inline styles because Tailwind CSS isn't loading
  const tempStyles = `
    @media (min-width: 640px) {
      /* Show all table columns on desktop */
      table th.hidden.sm\\:table-cell,
      table td.hidden.sm\\:table-cell {
        display: table-cell !important;
      }
      
      /* Show Device ID in name column on desktop */
      table td p.text-sm.text-muted.font-mono.hidden.sm\\:block {
        display: block !important;
      }
      
      /* Show button text on desktop */
      button span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Show desktop header text, hide mobile header text */
      th span.sm\\:hidden {
        display: none !important;
      }
      th span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Horizontal button layout on desktop */
      div.flex-col.sm\\:flex-row {
        flex-direction: row !important;
      }
      div.space-y-2.sm\\:space-y-0 {
        row-gap: 0 !important;
      }
      div.sm\\:space-x-2 {
        column-gap: 0.5rem !important;
      }
      button.w-full.sm\\:w-auto {
        width: auto !important;
      }
    }
    
    @media (max-width: 639px) {
      /* Hide table columns on mobile */
      table th.hidden.sm\\:table-cell,
      table td.hidden.sm\\:table-cell {
        display: none !important;
      }
      
      /* Hide Device ID in name column on mobile */
      table td p.text-sm.text-muted.font-mono.hidden.sm\\:block {
        display: none !important;
      }
      
      /* Hide button text on mobile */
      button span.hidden.sm\\:inline {
        display: none !important;
      }
      
      /* Show mobile header icons, hide desktop header text */
      th span.sm\\:hidden {
        display: inline !important;
      }
      th span.hidden.sm\\:inline {
        display: none !important;
      }
      
      /* Make mobile header icons 150% larger with current size as minimum */
      th svg.w-6.h-4 {
        /* Current size (24px) as minimum at 320px, scales to ~150% larger */
        /* Width: scales from 24px (320px) to 42px (430px) */
        width: clamp(24px, 10vw, 42px) !important;
        /* Height: scales from 16px (320px) to 28px (430px) - maintains 3:2 aspect ratio */
        height: clamp(16px, 6.67vw, 28px) !important;
        /* Ensure minimum and maximum constraints */
        min-width: 24px !important;
        min-height: 16px !important;
        max-width: 42px !important;
        max-height: 28px !important;
        /* Maintain 3:2 aspect ratio (same as current) */
        aspect-ratio: 3/2 !important;
      }
      
      /* Increase header cell height to accommodate larger icons */
      th {
        min-height: 40px !important;
        height: auto !important;
      }
      
      /* Ensure header cell content is properly centered */
      th div.flex.items-center.justify-center {
        min-height: 36px !important;
        align-items: center !important;
      }
      
      /* Center align mobile header icons */
      th div.flex.items-center.justify-center {
        justify-content: center !important;
        text-align: center !important;
      }
      
      /* Vertical button layout on mobile */
      div.flex-col.sm\\:flex-row {
        flex-direction: column !important;
      }
      div.space-y-2.sm\\:space-y-0 {
        row-gap: 0.5rem !important;
      }
      button.w-full.sm\\:w-auto {
        width: 100% !important;
      }
    }
    
    @media (min-width: 640px) {
      /* Make sure desktop header text is visible and icons are hidden */
      th span.sm\\:hidden {
        display: none !important;
      }
      th span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Reset icon sizes on desktop */
      th svg.w-6.h-4 {
        width: auto !important;
        height: auto !important;
      }
    }
    
    /* Mobile view: optimize for square buttons */
    @media (max-width: 639px) {
      /* Force table layout and column widths */
      table {
        table-layout: fixed !important;
        width: auto !important; /* Let table size based on column widths */
      }
      
      /* Set ALL column widths explicitly */
      col:nth-child(1) {
        width: 75px !important;
        min-width: 75px !important;
        max-width: 75px !important;
      }
      
      col:nth-child(2) {
        width: 102px !important;
        min-width: 102px !important;
        max-width: 102px !important;
      }
      
      col:nth-child(3) {
        width: 0px !important;
        min-width: 0px !important;
        max-width: 0px !important;
      }
      
      col:nth-child(4) {
        width: 0px !important;
        min-width: 0px !important;
        max-width: 0px !important;
      }
      
      col:nth-child(5) {
        width: 74px !important;
        min-width: 74px !important;
        max-width: 74px !important;
      }
      
      col:nth-child(6) {
        width: 75px !important;
        min-width: 75px !important;
        max-width: 75px !important;
      }
      
      /* Remove all cell padding for maximum space utilization */
      table td {
        padding-left: 0 !important;
        padding-right: 0 !important;
        padding-top: 0 !important;
        padding-bottom: 0 !important;
      }
      
      table th {
        padding-left: 0 !important;
        padding-right: 0 !important;
        padding-top: 2px !important;
        padding-bottom: 2px !important;
      }
      
      /* Status column - square button with large centered icon - FORCE 75px width */
      table th:nth-child(1),
      table td:nth-child(1) {
        padding: 0 !important;
        margin: 0 !important;
        width: 75px !important;
        min-width: 75px !important;
        max-width: 75px !important;
      }
      
      table td:nth-child(1) button {
        width: 75px !important;
        height: 75px !important;
        min-width: 75px !important;
        min-height: 75px !important;
        max-width: 75px !important;
        max-height: 75px !important;
        padding: 0 !important;
        margin: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        border-radius: 4px !important;
      }
      
      /* Make status badge graphic at least 70px and centered - HIDE TEXT ON MOBILE */
      table td:nth-child(1) button > span {
        width: 70px !important;
        height: 70px !important;
        min-width: 70px !important;
        min-height: 70px !important;
        max-width: 70px !important;
        max-height: 70px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 0 !important;
        margin: 0 !important;
        font-size: 24px !important;
        font-weight: bold !important;
        border-radius: 35px !important; /* Make it circular */
      }
      
      /* Hide all text inside status badge on mobile - graphics only */
      table td:nth-child(1) button > span > span:not(.sr-only) {
        display: none !important;
      }
      
      /* Ensure icon is visible and centered */
      table td:nth-child(1) button > span svg {
        width: 40px !important;
        height: 40px !important;
        display: block !important;
      }
      
      /* Ensure station name text wraps and fills cell height */
      table td:nth-child(2) > div {
        height: 100% !important;
        max-height: 100% !important;
        min-height: 100% !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
      }
      
      table td:nth-child(2) p.font-medium.text-ink {
        overflow: visible !important;
        text-overflow: clip !important;
        white-space: normal !important;
        word-break: break-all !important;
        overflow-wrap: anywhere !important;
        display: block !important;
        padding: 4px 2px !important;
        height: auto !important;
        max-height: none !important;
        min-height: 0 !important;
        line-height: 1.2 !important;
        flex: 1 !important;
      }
      
      /* Ensure tariff text wraps and fills cell height */
      table td:nth-child(5) span {
        overflow: visible !important;
        text-overflow: clip !important;
        white-space: normal !important;
        word-break: break-all !important;
        overflow-wrap: anywhere !important;
        display: block !important;
        padding: 4px 2px !important;
        height: 100% !important;
        max-height: 100% !important;
        min-height: 100% !important;
        line-height: 1.2 !important;
      }
      
      /* Address column - wrap and fill cell height */
      /* For commercial mode (address is 6th column) */
      table td:nth-child(6) span {
        display: block !important;
        overflow: visible !important;
        text-overflow: clip !important;
        white-space: normal !important;
        word-break: break-all !important;
        overflow-wrap: anywhere !important;
        line-height: 1.2 !important;
        height: 100% !important;
        max-height: 100% !important;
        min-height: 100% !important;
        padding: 4px 2px !important;
      }
      
      /* For non-commercial mode (address is 5th column) */
      table td:nth-child(5):not(:has(span:contains('Базовый'))) span {
        display: block !important;
        overflow: visible !important;
        text-overflow: clip !important;
        white-space: normal !important;
        word-break: break-all !important;
        overflow-wrap: anywhere !important;
        line-height: 1.2 !important;
        height: 100% !important;
        max-height: 100% !important;
        min-height: 100% !important;
        padding: 4px 2px !important;
      }
      
      /* Actions column - each button square - FORCE 75px width */
      table th:last-child,
      table td:last-child {
        padding: 0 !important;
        margin: 0 !important;
        width: 75px !important;
        min-width: 75px !important;
        max-width: 75px !important;
      }
      
      table td:last-child {
        height: 150px !important; /* 75px × 2 buttons */
      }
      
      table td:last-child div {
        gap: 0 !important;
        padding: 0 !important;
        margin: 0 !important;
        height: 150px !important; /* 75px × 2 buttons */
        width: 75px !important;
        min-width: 75px !important;
        max-width: 75px !important;
      }
      
      /* Make each action button square (75×75px) */
      table td:last-child button {
        width: 75px !important;
        height: 75px !important;
        min-width: 75px !important;
        min-height: 75px !important;
        max-width: 75px !important;
        max-height: 75px !important;
        padding: 0 !important;
        margin: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        border-radius: 0 !important;
        font-size: 10px !important;
      }
      
      /* First button top corners rounded */
      table td:last-child button:first-child {
        border-top-left-radius: 4px !important;
        border-top-right-radius: 4px !important;
      }
      
      /* Second button bottom corners rounded */
      table td:last-child button:last-child {
        border-bottom-left-radius: 4px !important;
        border-bottom-right-radius: 4px !important;
      }
      
      /* Ensure button icons are properly sized */
      table td:last-child button svg {
        width: 16px !important;
        height: 16px !important;
      }
      
      /* Remove button text on mobile */
      table td:last-child button span {
        display: none !important;
      }
      
      /* Remove all gaps between cells */
      table {
        border-spacing: 0 !important;
        border-collapse: collapse !important;
      }
      
      table td, table th {
        border-width: 0.5px !important;
      }
      
      /* Add minimal vertical padding to table cells for readability */
      table td:not(:first-child):not(:last-child) {
        padding-top: 4px !important;
        padding-bottom: 4px !important;
      }
    }
  `;

  // Modal handlers
  const handleOpenEditModal = (station?: Station) => {
    setEditingStation(station || null);
    setIsEditModalOpen(true);
  };

  // Check for navigation state to open modal
  useEffect(() => {
    if (location.state?.openAddModal) {
      // Use setTimeout to avoid calling setState synchronously within effect
      setTimeout(() => {
        handleOpenEditModal();
      }, 0);
      // Clear the state to prevent reopening on refresh
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, navigate, location.pathname]);

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setEditingStation(null);
  };

  const handleOpenDetailsModal = (station: Station) => {
    setSelectedStation(station);
    setIsDetailsModalOpen(true);
  };

  const handleCloseDetailsModal = () => {
    setIsDetailsModalOpen(false);
    setSelectedStation(null);
  };

  const handleSaveStation = (stationData: Station) => {
    // Generate technical parameters for new stations
    let stationToSave = stationData;
    if (!editingStation) {
      // For new stations, generate technical parameters
      const technicalParams = generateStationTechnicalParameters();
      stationToSave = {
        ...stationData,
        ...technicalParams,
      };
    } else {
      // For existing stations, preserve existing technical parameters
      const existingStation = stations.find(s => s.id === stationData.id);
      if (existingStation) {
        // Preserve all technical parameters from existing station
        const {
          voltagePhase1,
          voltagePhase2,
          voltagePhase3,
          inputContactTemp,
          outputPort0Temp,
          outputPort1Temp,
          internalTemp,
          phaseIndicator,
          portRelayStatus,
          connectorType,
          portType,
          maxCurrentLimit,
          totalSessions,
          totalOperatingMinutes,
          totalEnergyDelivered,
        } = existingStation;
        
        stationToSave = {
          ...stationData,
          voltagePhase1,
          voltagePhase2,
          voltagePhase3,
          inputContactTemp,
          outputPort0Temp,
          outputPort1Temp,
          internalTemp,
          phaseIndicator,
          portRelayStatus,
          connectorType,
          portType,
          maxCurrentLimit,
          totalSessions,
          totalOperatingMinutes,
          totalEnergyDelivered,
        };
      }
    }
    
    if (editingStation) {
      // Edit existing station
      setStations(stations.map(s => s.id === stationToSave.id ? stationToSave : s));
    } else {
      // Add new station
      setStations([...stations, stationToSave]);
    }
    handleCloseEditModal();
  };

  const handleDeleteStation = (id: string) => {
    if (window.confirm('Вы уверены, что хотите удалить эту станцию?')) {
      setStations(stations.filter(s => s.id !== id));
    }
  };

  const handleEditStation = (station: Station) => {
    handleOpenEditModal(station);
  };

  const handleAddStation = () => {
    handleOpenEditModal();
  };

  const handleStatusClick = (station: Station) => {
    handleOpenDetailsModal(station);
  };

  return (
    <>
      <div className="space-y-6 max-w-7xl mx-auto w-full">
        {/* Temporary style tag because Tailwind CSS isn't loading */}
        <style dangerouslySetInnerHTML={{ __html: tempStyles }} />
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-3xl font-bold ${tokens.text}`}>Станции</h2>
            <p className={tokens.textSecondary}>Управление зарядными станциями и мониторинг</p>
          </div>
          <div className="flex items-center space-x-4">
          <Button 
            variant="primary" 
            icon={Plus} 
            onClick={handleAddStation}
          >
            Добавить станцию
          </Button>
          </div>
        </div>

        {/* Stations table */}
        <Card className={`border-l-4 ${tokens.cardBorder} ${tokens.surface}`}>
          <CardContent className="p-6">
            <StationsTable
              stations={sortedStations}
              onEdit={handleEditStation}
              onDelete={handleDeleteStation}
              onStatusClick={handleStatusClick}
              isCommercialMode={appMode === 'commercial'}
            />
          </CardContent>
        </Card>
      </div>

      {/* Station Edit Modal */}
      <StationModal
        isOpen={isEditModalOpen}
        onClose={handleCloseEditModal}
        onSubmit={handleSaveStation}
        initialData={editingStation}
      />

      {/* Station Details Modal */}
      {selectedStation && (
        <StationDetailsModal
          isOpen={isDetailsModalOpen}
          onClose={handleCloseDetailsModal}
          station={selectedStation}
        />
      )}
    </>
  );
};
