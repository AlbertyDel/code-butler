/**
 * Utility function to clear demo data from localStorage and reload the page.
 * This restores the application to its default state using the seeded mock data.
 */
export const resetDemoData = () => {
  ['stations', 'tariffs', 'user'].forEach((key) => localStorage.removeItem(key));
  // Reload the page to re‑initialize mock data
  window.location.reload();
};