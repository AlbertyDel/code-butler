import { useContext } from 'react';
import { ModeContext } from './ModeContext';
import type { ModeContextType } from './ModeContext';

export const useMode = (): ModeContextType => {
  const context = useContext(ModeContext);
  if (context === undefined) {
    throw new Error('useMode must be used within a ModeProvider');
  }
  return context;
};
