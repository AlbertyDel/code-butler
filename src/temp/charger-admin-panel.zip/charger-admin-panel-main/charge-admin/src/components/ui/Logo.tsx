import React from 'react';
import { cn } from '../../utils/cn';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className }) => {
  return (
    <div className={cn("flex items-center font-bold tracking-tight select-none", className)}>
      <span className="text-brand mr-1">+</span>
      <span className="text-ink">CHARGE</span>
    </div>
  );
};
