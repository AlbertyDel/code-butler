import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';

export interface EnergyDataPoint {
  date: string;
  kwh: number;
}

export interface EnergyChartProps {
  data: EnergyDataPoint[];
  title?: string;
  height?: number;
}

export const EnergyChart: React.FC<EnergyChartProps> = ({ 
  data, 
  title = 'Energy Consumption (kWh)',
  height = 200 
}) => {
  return (
    <div className="bg-bg2 border border-bg-2 rounded-lg p-4 shadow-sm">
      <h3 className="text-ink font-medium mb-2 max-w-prose">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart
          data={data}
          margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 12, fill: '#667085' }}
            axisLine={{ stroke: '#e5e7eb' }}
            tickLine={{ stroke: '#e5e7eb' }}
          />
          <YAxis 
            tick={{ fontSize: 12, fill: '#667085' }}
            axisLine={{ stroke: '#e5e7eb' }}
            tickLine={{ stroke: '#e5e7eb' }}
          />
          <Tooltip 
            contentStyle={{ 
              fontSize: '0.875rem', 
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '0.375rem',
              boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
            }}
            formatter={(value: number | undefined) => [`${value || 0} kWh`, 'Energy']}
            labelFormatter={(label) => `Date: ${label}`}
          />
          <Line 
            type="monotone" 
            dataKey="kwh" 
            stroke="#12B76A" 
            strokeWidth={2}
            dot={{ fill: '#12B76A', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: '#12B76A', strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
