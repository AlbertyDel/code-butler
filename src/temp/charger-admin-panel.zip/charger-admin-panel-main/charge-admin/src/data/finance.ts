import { fakerRU as faker } from '@faker-js/faker';

// Seed the faker instance to ensure reproducible finance data on each session
faker.seed(2026);

export interface FinanceOperation {
  id: string;
  type: 'Поступление' | 'Вывод';
  amount: string; // formatted with currency symbol
  date: string;
  status: 'Успешно' | 'В процессе' | 'Ошибка';
}

export interface FinanceMock {
  balance: number;
  pending: number;
  operations: FinanceOperation[];
}

// Generate a new finance mock each session (this data is not persisted)
export const financeMock: FinanceMock = {
  balance: faker.number.int({ min: 80000, max: 150000 }),
  pending: faker.number.int({ min: 1000, max: 5000 }),
  operations: Array.from({ length: 10 }).map((_, i) => ({
    id: `OP-${1000 + i}`,
    type: faker.helpers.arrayElement(['Поступление', 'Вывод']) as FinanceOperation['type'],
    amount: faker.finance.amount({ min: 1000, max: 10000, dec: 2, symbol: '₽ ' }),
    date: faker.date.recent({ days: 30 }).toLocaleDateString('ru-RU'),
    status: faker.helpers.arrayElement(['Успешно', 'В процессе', 'Ошибка']) as FinanceOperation['status'],
  })),
};