import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { useMode } from '../contexts/useMode';
import { useUser } from '../contexts/useUser';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Shield,
  Save,
  Edit,
  Key,
  Building,
  FileText,
  Briefcase,
  UserCheck,
  Users,
} from 'lucide-react';

export const Profile: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const { mode, setMode } = useMode();
  const { userData, updateUserData } = useUser();

  const [formData, setFormData] = useState(() => ({
    name: userData.name,
    email: userData.email,
    phone: userData.phone,
    company: userData.company,
    location: userData.location,
    // Коммерческие данные
    organizationType: userData.organizationType || '',
    inn: userData.inn || '',
    ogrn: userData.ogrn || '',
    bankAccount: userData.bankAccount || '',
    // Контактные лица
    responsiblePerson: userData.responsiblePerson || {
      name: '',
      position: '',
      phone: '',
      email: '',
    },
    technicalPerson: userData.technicalPerson || {
      name: '',
      position: '',
      phone: '',
      email: '',
    },
    useSameAsResponsible: userData.useSameAsResponsible || false,
  }));

  // Функция для проверки изменений
  const checkForChanges = useCallback((newFormData: typeof formData) => {
    const currentData = {
      name: userData.name,
      email: userData.email,
      phone: userData.phone,
      company: userData.company,
      location: userData.location,
      organizationType: userData.organizationType || '',
      inn: userData.inn || '',
      ogrn: userData.ogrn || '',
      bankAccount: userData.bankAccount || '',
      responsiblePerson: userData.responsiblePerson || {
        name: '',
        position: '',
        phone: '',
        email: '',
      },
      technicalPerson: userData.technicalPerson || {
        name: '',
        position: '',
        phone: '',
        email: '',
      },
      useSameAsResponsible: userData.useSameAsResponsible || false,
    };
    
    const hasChanges = JSON.stringify(newFormData) !== JSON.stringify(currentData);
    setHasChanges(hasChanges);
  }, [userData]);

  // Обновляем проверку изменений при изменении formData
  useEffect(() => {
    // Use setTimeout to avoid synchronous setState in effect
    const timer = setTimeout(() => {
      checkForChanges(formData);
    }, 0);
    
    return () => clearTimeout(timer);
  }, [formData, checkForChanges]);

  const handleEditToggle = () => {
    setIsEditing(!isEditing);
  };

  const handleSave = () => {
    // Update user data in context and localStorage
    updateUserData(formData);
    console.log('Saving profile:', formData);
    setIsEditing(false);
    // После сохранения сбрасываем флаг изменений
    setHasChanges(false);
  };

  const handleUseSameAsResponsibleChange = (checked: boolean) => {
    if (checked) {
      // Копируем данные ответственного лица в технического специалиста
      setFormData({
        ...formData,
        useSameAsResponsible: true,
        technicalPerson: {
          ...formData.responsiblePerson
        }
      });
    } else {
      // Сбрасываем чекбокс, но сохраняем текущие данные технического специалиста
      setFormData({
        ...formData,
        useSameAsResponsible: false
      });
    }
  };

  const handleResponsiblePersonChange = (field: string, value: string) => {
    const newResponsiblePerson = {
      ...formData.responsiblePerson,
      [field]: value
    };
    
    setFormData({
      ...formData,
      responsiblePerson: newResponsiblePerson,
      // Если чекбокс активен, обновляем и технического специалиста
      ...(formData.useSameAsResponsible && {
        technicalPerson: newResponsiblePerson
      })
    });
  };

  // Active tab for profile sections. Default to account view.
  const [activeTab, setActiveTab] = useState<'account' | 'company' | 'contacts' | 'security'>('account');

  // Define tabs for vertical navigation. Only include company and contacts tabs when in commercial mode
  const allTabs = [
    { key: 'account', label: 'Личная', icon: User },
    { key: 'company', label: 'Компания', icon: Building },
    { key: 'contacts', label: 'Контакты', icon: Users },
    { key: 'security', label: 'Безопасность', icon: Shield },
  ];
  const availableTabs = allTabs.filter((tab) =>
    tab.key === 'company' || tab.key === 'contacts' ? mode === 'commercial' : true
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full" data-mode={mode}>
      {/* Header - Modern design */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-ink">Профиль</h2>
          <p className="text-muted mt-1">Управление учетной записью и настройками</p>
        </div>
        <div className="flex items-center justify-end gap-3">
          <Button 
            variant="secondary" 
            icon={Edit} 
            onClick={handleEditToggle}
            className="px-4"
          >
            {isEditing ? 'Отменить' : 'Редактировать'}
          </Button>
          <Button 
            variant="primary" 
            icon={Save} 
            onClick={handleSave}
            disabled={!hasChanges}
            className={`px-4 ${!hasChanges ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            Сохранить
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Vertical navigation */}
        <div className="w-full md:w-64 flex-shrink-0">
          <nav className="flex flex-wrap md:flex-col gap-2">
            {availableTabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as 'account' | 'company' | 'contacts' | 'security')}
                  className={
                    'flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 min-h-[44px] w-[calc(50%-4px)] md:w-full ' +
                    (activeTab === tab.key
                      ? 'bg-brand text-white shadow-md ring-1 ring-brand'
                      : 'text-muted hover:text-ink hover:bg-bg-2')
                  }
                >
                  <IconComponent className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
        {/* Tab content */}
        <div className="flex-1 space-y-6 min-w-0">
          {activeTab === 'account' && (
            <Card>
              <CardHeader
                title="Личная информация"
                description="Основные данные вашего профиля"
              />
              <CardContent>
                <div className="flex flex-col lg:flex-row gap-8">
                  {/* Left column - Compact avatar and mode switcher */}
                  <div className="lg:w-80 flex-shrink-0">
                    <div className="flex flex-col items-center lg:items-start space-y-6">
                      <div className="relative">
                        {/* Avatar with fixed sizing for SVG */}
                        <div className="h-32 w-32 rounded-full border-4 border-bg-2 overflow-hidden bg-bg-2 flex items-center justify-center">
                          <img
                            src={userData.avatar}
                            alt="Аватар"
                            className="h-full w-full object-cover"
                            onError={(e) => {
                              // Fallback if image fails to load
                              e.currentTarget.style.display = 'none';
                              const parent = e.currentTarget.parentElement;
                              if (parent) {
                                parent.innerHTML = '<div class="h-full w-full flex items-center justify-center"><span class="text-2xl font-bold text-muted">AI</span></div>';
                              }
                            }}
                          />
                        </div>
                      </div>
                      
                      {/* Mode switcher - Substantially larger, prominent buttons with inline styles */}
                      <div className="w-full max-w-[380px]">
                        <label className="block text-sm font-medium text-muted mb-4 text-center lg:text-left">
                          Режим работы
                        </label>
                        <div className="flex flex-row gap-4">
                          <button
                            onClick={() => setMode('personal')}
                            style={{
                              minWidth: '170px',
                              height: '56px',
                              padding: '16px 24px',
                              borderRadius: '12px',
                              fontSize: '18px',
                              fontWeight: 600,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '12px',
                              transition: 'all 0.2s'
                            }}
                            className={
                              mode === 'personal' 
                                ? 'bg-success text-white shadow-lg hover:shadow-xl border-2 border-success transform scale-[1.02]' 
                                : 'bg-bg-2 text-ink hover:text-ink hover:bg-bg-1 border-2 border-bg-1 hover:border-bg-3 hover:shadow-md'
                            }
                          >
                            <div style={{ flexShrink: 0, width: '24px', height: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <svg 
                                width="24" 
                                height="24" 
                                viewBox="0 0 24 24" 
                                fill="none" 
                                stroke="currentColor" 
                                strokeWidth="2.5" 
                                strokeLinecap="round" 
                                strokeLinejoin="round"
                                style={{ width: '100%', height: '100%' }}
                              >
                                <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                              </svg>
                            </div>
                            Личный
                          </button>
                          <button
                            onClick={() => setMode('commercial')}
                            style={{
                              minWidth: '170px',
                              height: '56px',
                              padding: '16px 24px',
                              borderRadius: '12px',
                              fontSize: '18px',
                              fontWeight: 600,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '12px',
                              transition: 'all 0.2s'
                            }}
                            className={
                              mode === 'commercial' 
                                ? 'bg-brand text-white shadow-lg hover:shadow-xl border-2 border-brand transform scale-[1.02]' 
                                : 'bg-bg-2 text-ink hover:text-ink hover:bg-bg-1 border-2 border-bg-1 hover:border-bg-3 hover:shadow-md'
                            }
                          >
                            <div style={{ flexShrink: 0, width: '24px', height: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <svg 
                                width="24" 
                                height="24" 
                                viewBox="0 0 24 24" 
                                fill="none" 
                                stroke="currentColor" 
                                strokeWidth="2.5" 
                                strokeLinecap="round" 
                                strokeLinejoin="round"
                                style={{ width: '100%', height: '100%' }}
                              >
                                <path d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                              </svg>
                            </div>
                            Коммерческий
                          </button>
                        </div>
                        <p className="text-sm text-muted mt-4 text-center lg:text-left">
                          {mode === 'personal'
                            ? 'Режим для личного использования станций'
                            : 'Режим для коммерческого управления сетью'}
                        </p>
                      </div>
                    </div>
                  </div>
                  {/* Right column - User info */}
                  <div className="flex-1 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Name */}
                      <div>
                        <label className="block text-sm font-medium text-muted mb-2">
                          <User className="inline h-4 w-4 mr-1" />
                          Имя
                        </label>
                        {isEditing ? (
                          <input
                            type="text"
                            className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          />
                        ) : (
                          <p className="text-lg font-medium text-ink">{userData.name}</p>
                        )}
                      </div>
                      {/* Email */}
                      <div>
                        <label className="block text-sm font-medium text-muted mb-2">
                          <Mail className="inline h-4 w-4 mr-1" />
                          Email
                        </label>
                        {isEditing ? (
                          <input
                            type="email"
                            className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          />
                        ) : (
                          <p className="text-lg font-medium text-ink">{userData.email}</p>
                        )}
                      </div>
                      {/* Phone */}
                      <div>
                        <label className="block text-sm font-medium text-muted mb-2">
                          <Phone className="inline h-4 w-4 mr-1" />
                          Телефон
                        </label>
                        {isEditing ? (
                          <input
                            type="tel"
                            className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          />
                        ) : (
                          <p className="text-lg font-medium text-ink">{userData.phone}</p>
                        )}
                      </div>
                      {/* Location */}
                      <div>
                        <label className="block text-sm font-medium text-muted mb-2">
                          <MapPin className="inline h-4 w-4 mr-1" />
                          Локация
                        </label>
                        {isEditing ? (
                          <input
                            type="text"
                            className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                            value={formData.location}
                            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                          />
                        ) : (
                          <p className="text-lg font-medium text-ink">{userData.location}</p>
                        )}
                      </div>
                    </div>
                    <div className="pt-4 border-t border-bg-2">
                      <p className="text-sm text-muted">
                        <Calendar className="inline h-4 w-4 mr-1" />
                        В системе с: {userData.joinDate}
                      </p>
                    </div>
                  </div>
                </div>
                {/* Mobile Edit/Save buttons - bottom left */}
                <div className="md:hidden flex items-center gap-3 mt-6 pt-4 border-t border-bg-2">
                  <Button 
                    variant="secondary" 
                    icon={Edit} 
                    onClick={handleEditToggle}
                    className="px-4"
                  >
                    {isEditing ? 'Отменить' : 'Редактировать'}
                  </Button>
                  <Button 
                    variant="primary" 
                    icon={Save} 
                    onClick={handleSave}
                    disabled={!hasChanges}
                    className={`px-4 ${!hasChanges ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    Сохранить
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'company' && mode === 'commercial' && (
            <Card>
              <CardHeader
                title="Коммерческие данные"
                description="Реквизиты и информация об организации"
              />
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted mb-2">
                      <Building className="inline h-4 w-4 mr-1" />
                      Компания
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      />
                    ) : (
                      <p className="text-lg font-medium text-ink">
                        {formData.company || 'Не указано'}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted mb-2">
                      <Building className="inline h-4 w-4 mr-1" />
                      Тип организации
                    </label>
                    {isEditing ? (
                      <select
                        className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                        value={formData.organizationType}
                        onChange={(e) => setFormData({ ...formData, organizationType: e.target.value })}
                      >
                        <option value="">Выберите тип</option>
                        <option value="ИП">Индивидуальный предприниматель (ИП)</option>
                        <option value="ООО">Общество с ограниченной ответственностью (ООО)</option>
                        <option value="АО">Акционерное общество (АО)</option>
                      </select>
                    ) : (
                      <p className="text-lg font-medium text-ink">
                        {formData.organizationType || 'Не указано'}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted mb-2">
                      <FileText className="inline h-4 w-4 mr-1" />
                      ИНН
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                        value={formData.inn}
                        onChange={(e) => setFormData({ ...formData, inn: e.target.value })}
                      />
                    ) : (
                      <p className="text-lg font-medium text-ink">
                        {formData.inn || 'Не указано'}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted mb-2">
                      <FileText className="inline h-4 w-4 mr-1" />
                      ОГРН
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                        value={formData.ogrn}
                        onChange={(e) => setFormData({ ...formData, ogrn: e.target.value })}
                      />
                    ) : (
                      <p className="text-lg font-medium text-ink">
                        {formData.ogrn || 'Не указано'}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted mb-2">
                      <Briefcase className="inline h-4 w-4 mr-1" />
                      Расчетный счет
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                        value={formData.bankAccount}
                        onChange={(e) => setFormData({ ...formData, bankAccount: e.target.value })}
                      />
                    ) : (
                      <p className="text-lg font-medium text-ink">
                        {formData.bankAccount || 'Не указано'}
                      </p>
                    )}
                  </div>
                </div>
                {/* Mobile Edit/Save buttons - bottom left */}
                <div className="md:hidden flex items-center gap-3 mt-6 pt-4 border-t border-bg-2">
                  <Button 
                    variant="secondary" 
                    icon={Edit} 
                    onClick={handleEditToggle}
                    className="px-4"
                  >
                    {isEditing ? 'Отменить' : 'Редактировать'}
                  </Button>
                  <Button 
                    variant="primary" 
                    icon={Save} 
                    onClick={handleSave}
                    disabled={!hasChanges}
                    className={`px-4 ${!hasChanges ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    Сохранить
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'contacts' && mode === 'commercial' && (
            <Card>
              <CardHeader
                title="Контактные лица"
                description="Ответственные лица организации"
              />
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-ink flex items-center">
                    <UserCheck className="h-5 w-5 mr-2" />
                    Ответственное лицо
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        ФИО
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                          value={formData.responsiblePerson.name}
                          onChange={(e) => handleResponsiblePersonChange('name', e.target.value)}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.responsiblePerson.name || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Должность
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                          value={formData.responsiblePerson.position}
                          onChange={(e) => handleResponsiblePersonChange('position', e.target.value)}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.responsiblePerson.position || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Телефон
                      </label>
                      {isEditing ? (
                        <input
                          type="tel"
                          className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                          value={formData.responsiblePerson.phone}
                          onChange={(e) => handleResponsiblePersonChange('phone', e.target.value)}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.responsiblePerson.phone || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Email
                      </label>
                      {isEditing ? (
                        <input
                          type="email"
                          className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                          value={formData.responsiblePerson.email}
                          onChange={(e) => handleResponsiblePersonChange('email', e.target.value)}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.responsiblePerson.email || 'Не указано'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-ink flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      Технический специалист
                    </h3>
                    {isEditing && (
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="useSameAsResponsible"
                          checked={formData.useSameAsResponsible}
                          onChange={(e) => handleUseSameAsResponsibleChange(e.target.checked)}
                          className="rounded border-bg-1"
                        />
                        <label htmlFor="useSameAsResponsible" className="text-sm text-muted">
                          Использовать данные ответственного лица
                        </label>
                      </div>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        ФИО
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand ${formData.useSameAsResponsible ? 'opacity-50 cursor-not-allowed' : ''}`}
                          value={formData.technicalPerson.name}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              technicalPerson: { ...formData.technicalPerson, name: e.target.value },
                            })
                          }
                          disabled={formData.useSameAsResponsible}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.technicalPerson.name || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Должность
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand ${formData.useSameAsResponsible ? 'opacity-50 cursor-not-allowed' : ''}`}
                          value={formData.technicalPerson.position}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              technicalPerson: { ...formData.technicalPerson, position: e.target.value },
                            })
                          }
                          disabled={formData.useSameAsResponsible}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.technicalPerson.position || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Телефон
                      </label>
                      {isEditing ? (
                        <input
                          type="tel"
                          className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand ${formData.useSameAsResponsible ? 'opacity-50 cursor-not-allowed' : ''}`}
                          value={formData.technicalPerson.phone}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              technicalPerson: { ...formData.technicalPerson, phone: e.target.value },
                            })
                          }
                          disabled={formData.useSameAsResponsible}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.technicalPerson.phone || 'Не указано'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted mb-2">
                        Email
                      </label>
                      {isEditing ? (
                        <input
                          type="email"
                          className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand ${formData.useSameAsResponsible ? 'opacity-50 cursor-not-allowed' : ''}`}
                          value={formData.technicalPerson.email}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              technicalPerson: { ...formData.technicalPerson, email: e.target.value },
                            })
                          }
                          disabled={formData.useSameAsResponsible}
                        />
                      ) : (
                        <p className="text-lg font-medium text-ink">
                          {formData.technicalPerson.email || 'Не указано'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                {/* Mobile Edit/Save buttons - bottom left */}
                <div className="md:hidden flex items-center gap-3 mt-6 pt-4 border-t border-bg-2">
                  <Button 
                    variant="secondary" 
                    icon={Edit} 
                    onClick={handleEditToggle}
                    className="px-4"
                  >
                    {isEditing ? 'Отменить' : 'Редактировать'}
                  </Button>
                  <Button 
                    variant="primary" 
                    icon={Save} 
                    onClick={handleSave}
                    disabled={!hasChanges}
                    className={`px-4 ${!hasChanges ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    Сохранить
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'security' && (
            <Card>
              <CardHeader
                title="Безопасность"
                description="Управление доступом и защитой аккаунта"
              />
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-bg-2 rounded-lg">
                  <div>
                    <p className="font-medium text-ink">Пароль</p>
                    <p className="text-sm text-muted">Последнее изменение: 2 недели назад</p>
                  </div>
                  <Button variant="secondary" icon={Key}>
                    Изменить пароль
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 bg-bg-2 rounded-lg">
                  <div>
                    <p className="font-medium text-ink">Двухфакторная аутентификация</p>
                    <p className="text-sm text-muted">Дополнительная защита вашего аккаунта</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <StatusBadge status="warning" label="Не активно" />
                    <Button variant="secondary" icon={Shield}>
                      Включить
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-bg-2 rounded-lg">
                  <div>
                    <p className="font-medium text-ink">Активные сессии</p>
                    <p className="text-sm text-muted">1 активная сессия (это устройство)</p>
                  </div>
                  <Button variant="ghost">Просмотреть все</Button>
                </div>
                {/* Mobile Edit/Save buttons - bottom left */}
                <div className="md:hidden flex items-center gap-3 mt-6 pt-4 border-t border-bg-2">
                  <Button 
                    variant="secondary" 
                    icon={Edit} 
                    onClick={handleEditToggle}
                    className="px-4"
                  >
                    {isEditing ? 'Отменить' : 'Редактировать'}
                  </Button>
                  <Button 
                    variant="primary" 
                    icon={Save} 
                    onClick={handleSave}
                    disabled={!hasChanges}
                    className={`px-4 ${!hasChanges ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    Сохранить
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};
