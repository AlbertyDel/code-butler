import { useContext } from 'react';
import { TariffContext } from './TariffContext';
import type { TariffContextType } from './TariffContext';

export const useTariff = (): TariffContextType => {
  const context = useContext(TariffContext);
  if (context === undefined) {
    throw new Error('useTariff must be used within a TariffProvider');
  }
  return context;
};
