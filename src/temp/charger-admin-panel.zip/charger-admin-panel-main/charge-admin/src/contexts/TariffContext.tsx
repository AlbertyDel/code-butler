/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { Tariff, TariffFormData } from '../types/tariff';
import { mockTariffs } from '../data/mock-tariffs';

export interface TariffContextType {
  tariffs: Tariff[];
  defaultBasePrice: number;
  addTariff: (tariffData: TariffFormData) => void;
  updateTariff: (oldName: string, tariffData: TariffFormData) => void;
  deleteTariff: (name: string) => void;
  setDefaultBasePrice: (price: number) => void;
  getTariffByName: (name: string) => Tariff | undefined;
}

export const TariffContext = createContext<TariffContextType | undefined>(undefined);

const STORAGE_KEY = 'charge_admin_tariffs';
const DEFAULT_PRICE_KEY = 'charge_admin_default_price';

export const TariffProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Synchronous initialization like usePersistentData hook
  const [tariffs, setTariffs] = useState<Tariff[]>(() => {
    const savedTariffs = localStorage.getItem(STORAGE_KEY);
    if (savedTariffs) {
      try {
        const parsedTariffs = JSON.parse(savedTariffs);
        // Если в localStorage есть данные - используем их
        if (Array.isArray(parsedTariffs)) {
          // If array is empty, load mock tariffs for better user experience
          if (parsedTariffs.length === 0) {
            return mockTariffs;
          }
          return parsedTariffs;
        }
      } catch (error) {
        console.error('Error parsing saved tariffs:', error);
      }
    }
    // No localStorage data or parsing error - load mock tariffs
    return mockTariffs;
  });

  const [defaultBasePrice, setDefaultBasePriceState] = useState<number>(() => {
    const savedDefaultPrice = localStorage.getItem(DEFAULT_PRICE_KEY);
    if (savedDefaultPrice) {
      try {
        const price = parseFloat(savedDefaultPrice);
        if (!isNaN(price)) {
          return price;
        }
      } catch (error) {
        console.error('Error parsing saved default price:', error);
      }
    }
    return 30;
  });

  // One-time initialization: ensure mock tariffs are loaded when array is empty
  // This is handled in the useState initializer above

  // Сохранение тарифов в localStorage при изменении
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tariffs));
  }, [tariffs]);

  // Сохранение базовой стоимости по умолчанию
  useEffect(() => {
    localStorage.setItem(DEFAULT_PRICE_KEY, defaultBasePrice.toString());
  }, [defaultBasePrice]);

  const addTariff = (tariffData: TariffFormData) => {
    const now = new Date().toISOString().split('T')[0];
    const newTariff: Tariff = {
      ...tariffData,
      createdAt: now,
      updatedAt: now,
      isActive: true,
    };
    setTariffs(prev => [...prev, newTariff]);
  };

  const updateTariff = (oldName: string, tariffData: TariffFormData) => {
    const now = new Date().toISOString().split('T')[0];
    setTariffs(prev => prev.map(tariff => 
      tariff.name === oldName 
        ? { 
            ...tariffData, 
            createdAt: tariff.createdAt,
            updatedAt: now,
            isActive: tariff.isActive !== undefined ? tariff.isActive : true,
          }
        : tariff
    ));
  };

  const deleteTariff = (name: string) => {
    setTariffs(prev => prev.filter(tariff => tariff.name !== name));
  };

  const setDefaultBasePrice = (price: number) => {
    setDefaultBasePriceState(price);
  };

  const getTariffByName = (name: string): Tariff | undefined => {
    return tariffs.find(tariff => tariff.name === name);
  };

  return (
    <TariffContext.Provider
      value={{
        tariffs,
        defaultBasePrice,
        addTariff,
        updateTariff,
        deleteTariff,
        setDefaultBasePrice,
        getTariffByName,
      }}
    >
      {children}
    </TariffContext.Provider>
  );
};
