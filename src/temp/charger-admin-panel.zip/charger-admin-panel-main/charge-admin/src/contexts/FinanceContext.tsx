/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type {
  FinanceData,
  FinancialOperation,
  WithdrawalRequest,
  SubscriptionPlan,
} from '../types/finance';
import {
  mockOperations,
  mockWithdrawalRequests,
  mockSubscriptionPlans,
  generateOperationId,
  generateWithdrawalId
} from '../types/finance';

export interface FinanceContextType {
  // Данные
  balance: number;
  operations: FinancialOperation[];
  withdrawalRequests: WithdrawalRequest[];
  currentSubscription: SubscriptionPlan;
  availablePlans: SubscriptionPlan[];
  
  // Методы
  updateBalance: (amount: number) => void;
  addOperation: (operation: Omit<FinancialOperation, 'id'>) => void;
  addWithdrawalRequest: (amount: number, method: 'банковская карта' | 'расчетный счет', details: string) => void;
  updateSubscription: (planId: string) => void;
  updateWithdrawalStatus: (id: string, status: 'pending' | 'processing' | 'completed' | 'rejected') => void;
}

export const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

const STORAGE_KEY = 'charge_admin_finance';

// Начальные данные
const initialData: FinanceData = {
  balance: 15680,
  operations: mockOperations,
  withdrawalRequests: mockWithdrawalRequests,
  currentSubscription: mockSubscriptionPlans[0], // Базовый план
  availablePlans: mockSubscriptionPlans,
};

export const FinanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [financeData, setFinanceData] = useState<FinanceData>(() => {
    // Загрузка из localStorage
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : initialData;
  });

  // Сохранение в localStorage при изменении
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(financeData));
  }, [financeData]);

  const updateBalance = (amount: number) => {
    setFinanceData(prev => ({
      ...prev,
      balance: prev.balance + amount
    }));
  };

  const addOperation = (operationData: Omit<FinancialOperation, 'id'>) => {
    const newOperation: FinancialOperation = {
      ...operationData,
      id: generateOperationId(),
    };
    
    setFinanceData(prev => ({
      ...prev,
      operations: [newOperation, ...prev.operations],
      balance: prev.balance + operationData.amount
    }));
  };

  const addWithdrawalRequest = (amount: number, method: 'банковская карта' | 'расчетный счет', details: string) => {
    if (amount > financeData.balance) {
      throw new Error('Запрашиваемая сумма превышает доступный баланс');
    }

    const newRequest: WithdrawalRequest = {
      id: generateWithdrawalId(),
      amount: -amount,
      method,
      details,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
    };

    // Сначала добавляем операцию вывода
    addOperation({
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'Вывод средств',
      amount: -amount,
      status: 'pending',
      details: `Заявка на вывод ${method}: ${details}`,
    });

    // Затем добавляем заявку на вывод
    setFinanceData(prev => ({
      ...prev,
      withdrawalRequests: [newRequest, ...prev.withdrawalRequests],
    }));
  };

  const updateSubscription = (planId: string) => {
    const newPlan = financeData.availablePlans.find(plan => plan.id === planId);
    if (!newPlan) return;

    const now = new Date();
    const nextChargeDate = new Date(now);
    nextChargeDate.setMonth(now.getMonth() + 1);
    
    const updatedPlan = {
      ...newPlan,
      nextChargeDate: nextChargeDate.toISOString().split('T')[0]
    };

    // Добавляем операцию оплаты подписки
    addOperation({
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'Подписка',
      amount: -newPlan.price,
      status: 'completed',
      details: `Оплата подписки "${newPlan.name}"`,
    });

    setFinanceData(prev => ({
      ...prev,
      currentSubscription: updatedPlan,
    }));
  };

  const updateWithdrawalStatus = (id: string, status: 'pending' | 'processing' | 'completed' | 'rejected') => {
    setFinanceData(prev => {
      const updatedRequests = prev.withdrawalRequests.map(request =>
        request.id === id ? {
          ...request,
          status,
          ...(status === 'completed' && !request.completedAt ? { completedAt: new Date().toISOString().split('T')[0] } : {})
        } : request
      );

      // Обновляем соответствующую операцию
      const updatedOperations = prev.operations.map(operation => {
        if (operation.details.includes(id) || (operation.type === 'Вывод средств' && operation.status === 'pending')) {
          const newStatus: 'completed' | 'pending' | 'failed' = status === 'completed' ? 'completed' : status === 'rejected' ? 'failed' : 'pending';
          return {
            ...operation,
            status: newStatus
          };
        }
        return operation;
      });

      return {
        ...prev,
        withdrawalRequests: updatedRequests,
        operations: updatedOperations,
      };
    });
  };

  const value: FinanceContextType = {
    balance: financeData.balance,
    operations: financeData.operations,
    withdrawalRequests: financeData.withdrawalRequests,
    currentSubscription: financeData.currentSubscription,
    availablePlans: financeData.availablePlans,
    updateBalance,
    addOperation,
    addWithdrawalRequest,
    updateSubscription,
    updateWithdrawalStatus,
  };

  return (
    <FinanceContext.Provider value={value}>
      {children}
    </FinanceContext.Provider>
  );
};
