import React from 'react';
import { cn } from '../../utils/cn';

/**
 * Enhanced skeleton component with multiple variants and animations.
 * Based on Bukan/pluspower-modern design patterns.
 */
export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  width?: string | number;
  height?: string | number;
  variant?: 'text' | 'circular' | 'rectangular' | 'card' | 'avatar' | 'button' | 'input';
  animation?: 'pulse' | 'wave' | 'shimmer' | 'none';
  rounded?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
  count?: number;
  spacing?: 'none' | 'sm' | 'md' | 'lg';
}

export const Skeleton: React.FC<SkeletonProps> = ({
  width,
  height,
  variant = 'text',
  animation = 'pulse',
  rounded = 'md',
  count = 1,
  spacing = 'md',
  className,
  style,
  ...props
}) => {
  // Determine rounded class based on variant and rounded prop
  const roundedClasses = {
    none: '',
    sm: 'rounded-sm',
    md: 'rounded-md',
    lg: 'rounded-lg',
    xl: 'rounded-xl',
    full: 'rounded-full',
  };

  const variantDefaults = {
    text: { width: '100%', height: '1rem', rounded: 'md' as const },
    circular: { width: '3rem', height: '3rem', rounded: 'full' as const },
    rectangular: { width: '100%', height: '200px', rounded: 'md' as const },
    card: { width: '100%', height: 'auto', rounded: 'lg' as const },
    avatar: { width: '2.5rem', height: '2.5rem', rounded: 'full' as const },
    button: { width: '6rem', height: '2.5rem', rounded: 'md' as const },
    input: { width: '100%', height: '2.5rem', rounded: 'md' as const },
  };

  const animationClasses = {
    pulse: 'animate-pulse-slow',
    wave: 'animate-shimmer bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-800 dark:via-gray-700 dark:to-gray-800 bg-[length:200%_100%]',
    shimmer: 'relative overflow-hidden before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_2s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent',
    none: '',
  };

  const spacingClasses = {
    none: '',
    sm: 'gap-2',
    md: 'gap-3',
    lg: 'gap-4',
  };

  const defaultVariant = variantDefaults[variant];
  const finalWidth = width ?? defaultVariant.width;
  const finalHeight = height ?? defaultVariant.height;
  const finalRounded = roundedClasses[rounded] || roundedClasses[defaultVariant.rounded];

  const skeletonElement = (
    <div
      className={cn(
        'bg-gray-200 dark:bg-gray-800',
        animationClasses[animation],
        finalRounded,
        className
      )}
      style={{
        width: typeof finalWidth === 'number' ? `${finalWidth}px` : finalWidth,
        height: typeof finalHeight === 'number' ? `${finalHeight}px` : finalHeight,
        ...style,
      }}
      {...props}
    />
  );

  if (count === 1) {
    return skeletonElement;
  }

  return (
    <div className={cn('flex flex-col', spacingClasses[spacing])}>
      {Array.from({ length: count }).map((_, index) => (
        <React.Fragment key={index}>
          {skeletonElement}
        </React.Fragment>
      ))}
    </div>
  );
};

/**
 * Enhanced compound skeleton components for common patterns
 */
export const MetricCardSkeleton: React.FC<{ variant?: 'default' | 'compact' | 'detailed' }> = ({ variant = 'default' }) => {
  if (variant === 'compact') {
    return (
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <Skeleton variant="circular" width="2.5rem" height="2.5rem" animation="wave" />
          <div className="flex-1 space-y-2">
            <Skeleton width="40%" height="0.75rem" animation="wave" />
            <Skeleton width="60%" height="1.25rem" animation="wave" />
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'detailed') {
    return (
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-4 mb-4">
          <Skeleton variant="circular" width="3rem" height="3rem" animation="wave" />
          <div className="flex-1 space-y-2">
            <Skeleton width="50%" height="1rem" animation="wave" />
            <Skeleton width="30%" height="0.75rem" animation="wave" />
          </div>
        </div>
        <div className="space-y-3">
          <Skeleton width="100%" height="1.5rem" animation="wave" />
          <Skeleton width="80%" height="1rem" animation="wave" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-5 shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <Skeleton variant="circular" width="3rem" height="3rem" animation="wave" />
        <div className="flex-1">
          <Skeleton width="40%" height="0.875rem" animation="wave" className="mb-2" />
          <Skeleton width="60%" height="1.5rem" animation="wave" />
        </div>
      </div>
      <div className="flex items-center gap-1">
        <Skeleton width="30%" height="0.75rem" animation="wave" />
      </div>
    </div>
  );
};

export const ChartSkeleton: React.FC<{ height?: number; variant?: 'line' | 'bar' | 'pie' }> = ({ 
  height = 200, 
  variant = 'line' 
}) => {
  const chartContent = variant === 'bar' ? (
    <div className="flex items-end justify-between h-full gap-2">
      {Array.from({ length: 7 }).map((_, i) => (
        <Skeleton 
          key={i} 
          variant="rectangular" 
          width="12%" 
          height={`${Math.random() * 80 + 20}%`} 
          animation="wave"
        />
      ))}
    </div>
  ) : variant === 'pie' ? (
    <div className="flex items-center justify-center h-full">
      <Skeleton variant="circular" width="120px" height="120px" animation="wave" />
    </div>
  ) : (
    <div className="relative h-full">
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gray-200 dark:bg-gray-800" />
      <div className="absolute left-0 top-0 bottom-0 w-px bg-gray-200 dark:bg-gray-800" />
      <div className="absolute inset-0 flex items-end">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="flex-1 h-full flex items-end"
            style={{ height: '100%' }}
          >
            <Skeleton
              variant="rectangular"
              width="100%"
              height={`${Math.random() * 80 + 20}%`}
              animation="wave"
              className="mx-0.5"
            />
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="space-y-2">
          <Skeleton width="40%" height="1rem" animation="wave" />
          <Skeleton width="60%" height="0.75rem" animation="wave" />
        </div>
        <Skeleton variant="button" width="6rem" animation="wave" />
      </div>
      <div style={{ height: `${height}px` }}>
        {chartContent}
      </div>
    </div>
  );
};

export const TableSkeleton: React.FC<{ 
  rows?: number; 
  columns?: number;
  variant?: 'default' | 'compact' | 'detailed';
}> = ({ 
  rows = 5, 
  columns = 6,
  variant = 'default'
}) => {
  const rowHeight = variant === 'compact' ? '2.5rem' : variant === 'detailed' ? '4rem' : '3.5rem';
  const headerHeight = variant === 'compact' ? '2rem' : '2.5rem';

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-sm overflow-hidden">
      {/* Table header */}
      <div className="bg-gray-50 dark:bg-gray-800 px-6 py-4 grid gap-4" 
           style={{ 
             gridTemplateColumns: `repeat(${columns}, 1fr)`,
             height: headerHeight 
           }}>
        {Array.from({ length: columns }).map((_, i) => (
          <Skeleton 
            key={`header-${i}`} 
            width={i === 0 ? '60%' : '80%'} 
            height="0.875rem" 
            animation="wave"
          />
        ))}
      </div>
      
      {/* Table rows */}
      <div className="divide-y divide-gray-200 dark:divide-gray-800">
        {Array.from({ length: rows }).map((_, rowIndex) => (
          <div 
            key={rowIndex} 
            className="px-6 py-4 grid gap-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            style={{ 
              gridTemplateColumns: `repeat(${columns}, 1fr)`,
              height: rowHeight 
            }}
          >
            {Array.from({ length: columns }).map((_, colIndex) => (
              <div key={`cell-${rowIndex}-${colIndex}`} className="flex items-center">
                {colIndex === 0 && variant === 'detailed' ? (
                  <div className="flex items-center gap-3">
                    <Skeleton variant="avatar" animation="wave" />
                    <div className="space-y-1">
                      <Skeleton width="6rem" height="0.875rem" animation="wave" />
                      <Skeleton width="4rem" height="0.75rem" animation="wave" />
                    </div>
                  </div>
                ) : colIndex === columns - 1 ? (
                  <div className="flex gap-2">
                    <Skeleton variant="button" width="2.5rem" animation="wave" />
                    <Skeleton variant="button" width="2.5rem" animation="wave" />
                  </div>
                ) : (
                  <Skeleton 
                    width={colIndex === 0 ? '70%' : '90%'} 
                    height="0.875rem" 
                    animation="wave"
                  />
                )}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export const CardSkeleton: React.FC<{ variant?: 'default' | 'elevated' | 'outline' }> = ({ variant = 'default' }) => {
  const cardClasses = {
    default: 'bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800',
    elevated: 'bg-white dark:bg-gray-900 shadow-md border-0',
    outline: 'bg-transparent border-2 border-gray-200 dark:border-gray-800',
  };

  return (
    <div className={cn('rounded-xl p-6 space-y-4', cardClasses[variant])}>
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton width="40%" height="1rem" animation="wave" />
          <Skeleton width="60%" height="0.75rem" animation="wave" />
        </div>
        <Skeleton variant="circular" width="2rem" height="2rem" animation="wave" />
      </div>
      <div className="space-y-3">
        <Skeleton width="100%" height="1rem" animation="wave" />
        <Skeleton width="80%" height="1rem" animation="wave" />
      </div>
      <div className="pt-4 border-t border-gray-200 dark:border-gray-800 flex justify-end gap-2">
        <Skeleton variant="button" width="5rem" animation="wave" />
        <Skeleton variant="button" width="5rem" animation="wave" />
      </div>
    </div>
  );
};
