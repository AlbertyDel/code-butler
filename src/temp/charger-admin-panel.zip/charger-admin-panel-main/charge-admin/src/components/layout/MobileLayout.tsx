import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Battery, 
  Clock, 
  CreditCard, 
  DollarSign, 
  User,
  LogOut
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Logo } from '../ui/Logo';
import { cn } from '../../utils/cn';
import { useMode } from '../../contexts/useMode';

const mainNavigationItems = [
  { name: 'Главная', icon: Home, path: '/' },
  { name: 'Станции', icon: Battery, path: '/stations' },
  { name: 'Сессии', icon: Clock, path: '/sessions' },
  { name: 'Тарифы', icon: CreditCard, path: '/tariffs' },
  { name: 'Финансы', icon: DollarSign, path: '/finance' },
  { name: 'Профиль', icon: User, path: '/profile' },
];

export const MobileLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { mode, setMode } = useMode();

  // Filter navigation items based on mode
  const filteredMainItems = mainNavigationItems.filter(item => {
    if (mode === 'personal') {
      // Hide Finance and Tariffs in personal mode
      return item.name !== 'Финансы' && item.name !== 'Тарифы';
    }
    return true;
  });

  // Showcase-specific design tokens from UIShowcase
  const showcaseTokens = {
    personal: {
      primary: 'bg-personal-primary-500',
      secondary: 'bg-personal-secondary-500',
      accent: 'bg-personal-accent-500',
      background: 'bg-personal-background-DEFAULT',
      surface: 'bg-personal-surface-DEFAULT',
      textPrimary: 'text-personal-text-primary',
      textSecondary: 'text-personal-text-secondary',
      border: 'border-personal-primary-200',
      hover: 'hover:bg-personal-primary-100',
      focus: 'focus:ring-personal-primary-300',
    },
    commercial: {
      primary: 'bg-commercial-primary-500',
      secondary: 'bg-commercial-secondary-500',
      accent: 'bg-commercial-accent-500',
      background: 'bg-commercial-background-DEFAULT',
      surface: 'bg-commercial-surface-DEFAULT',
      textPrimary: 'text-commercial-text-primary',
      textSecondary: 'text-commercial-text-secondary',
      border: 'border-commercial-primary-300',
      hover: 'hover:bg-commercial-primary-100',
      focus: 'focus:ring-commercial-primary-300',
    }
  };

  const tokens = showcaseTokens[mode];

  return (
    <div className={`flex flex-col min-h-screen ${tokens.background} ${tokens.textPrimary}`} data-mode={mode}>
      {/* Simplified header - removed menu button */}
      <header className="border-b border-bg-2 bg-bg2 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto w-full px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Logo className="text-xl mr-4" />
            </div>

            {/* Compact Mode Switcher */}
            <div className="bg-bg1 rounded-lg p-1 flex items-center border border-bg-2 mr-auto">
              <button
                onClick={() => setMode('personal')}
                className={cn(
                  "h-11 min-w-[44px] px-3 text-sm font-medium rounded-md transition-all duration-200 flex items-center justify-center",
                  mode === 'personal'
                    ? "bg-success text-white shadow-sm"
                    : "text-muted hover:text-ink hover:bg-bg-2"
                )}
                aria-label="Личный режим"
              >
                Л
              </button>
              <button
                onClick={() => setMode('commercial')}
                className={cn(
                  "h-11 min-w-[44px] px-3 text-sm font-medium rounded-md transition-all duration-200 flex items-center justify-center",
                  mode === 'commercial'
                    ? "bg-brand text-white shadow-sm"
                    : "text-muted hover:text-ink hover:bg-bg-2"
                )}
                aria-label="Коммерческий режим"
              >
                Б
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button 
                variant="icon"
                onClick={() => {
                  console.log('Выход из системы (мобильная версия)');
                  // В реальном приложении здесь была бы логика выхода
                }}
                title="Выйти из системы"
                aria-label="Выйти из системы"
              >
                <LogOut size={20} />
              </Button>
              <div className="h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center">
                <User size={16} className="text-brand" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Page content - Fixed padding with safe area support */}
      <main className="flex-[1_1_0%] overflow-auto pt-4 px-4 space-y-4 safe-area-padding-bottom">
        <div className="max-w-7xl mx-auto w-full">
          {children}
        </div>
      </main>

      {/* Bottom navigation - Mode-specific colors with solid background */}
      <nav 
        className="fixed bottom-0 inset-x-0 h-20 bg-mode-surface border-t border-bg-2 flex z-20 force-bottom-nav"
        style={{ 
          boxShadow: '0 -1px 3px rgba(0,0,0,0.1)'
        }}
      >
        {filteredMainItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center justify-end text-xs transition-colors duration-200 flex-1',
                isActive 
                  ? `${mode === 'personal' ? 'text-personal-primary-500' : 'text-commercial-primary-500'} font-medium ${mode === 'personal' ? 'bg-personal-primary-50' : 'bg-commercial-primary-50'}` 
                  : 'text-muted bg-mode-surface'
              )
            }
            style={{ 
              WebkitTapHighlightColor: 'transparent',
              paddingBottom: '4px',
              paddingTop: '8px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'space-between',
              minWidth: '0', // Allow shrinking
              overflow: 'hidden'
            }}
          >
            <>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flex: '1',
                minHeight: '32px',
                maxHeight: '40px',
                width: '100%'
              }}>
                <item.icon 
                  style={{
                    stroke: 'currentColor',
                    strokeWidth: '2px',
                    fill: 'none',
                    width: '32px', // Increased by 15% (from 28px)
                    height: '32px',
                    flexShrink: 0
                  }}
                />
              </div>
              <span className="xs:text-[10px] leading-none" style={{
                lineHeight: '1',
                paddingTop: '2px',
                height: '14px',
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'center'
              }}>{item.name}</span>
            </>
          </NavLink>
        ))}
      </nav>

    </div>
  );
};
