import type { StatusType } from '../components/ui/StatusBadge';

export type OperationType = 'Оплата сессии' | 'Вывод средств' | 'Комиссия' | 'Подписка';
export type OperationStatus = 'completed' | 'pending' | 'failed';
export type WithdrawalMethod = 'банковская карта' | 'расчетный счет';
export type WithdrawalStatus = 'pending' | 'processing' | 'completed' | 'rejected';

export interface FinancialOperation {
  id: string;
  date: string;
  type: OperationType;
  amount: number;
  status: OperationStatus;
  details: string;
  sessionId?: string;
}

export interface WithdrawalRequest {
  id: string;
  amount: number;
  method: WithdrawalMethod;
  details: string;
  status: WithdrawalStatus;
  createdAt: string;
  completedAt?: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  features: string[];
  description: string;
  nextChargeDate: string;
}

export interface FinanceData {
  balance: number;
  operations: FinancialOperation[];
  withdrawalRequests: WithdrawalRequest[];
  currentSubscription: SubscriptionPlan;
  availablePlans: SubscriptionPlan[];
}

// Моковые данные для начальной загрузки
export const mockSubscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'basic',
    name: 'Базовый',
    price: 990,
    features: [
      'До 5 станций',
      'Базовая аналитика',
      'Email поддержка',
      'История операций за 30 дней'
    ],
    description: 'Для начинающих операторов',
    nextChargeDate: '2025-02-01'
  },
  {
    id: 'professional',
    name: 'Профессиональный',
    price: 2990,
    features: [
      'До 20 станций',
      'Расширенная аналитика',
      'Приоритетная поддержка',
      'История операций за 90 дней',
      'API доступ'
    ],
    description: 'Для растущего бизнеса',
    nextChargeDate: '2025-02-01'
  },
  {
    id: 'enterprise',
    name: 'Корпоративный',
    price: 7990,
    features: [
      'Неограниченное количество станций',
      'Полная аналитика и отчеты',
      '24/7 поддержка',
      'История операций за 1 год',
      'Интеграция с ERP',
      'Кастомные тарифы'
    ],
    description: 'Для крупных операторов',
    nextChargeDate: '2025-02-01'
  }
];

export const mockOperations: FinancialOperation[] = [
  {
    id: 'op1',
    date: '2025-01-15 14:30',
    type: 'Оплата сессии',
    amount: 450,
    status: 'completed',
    details: 'Сессия #CHG-0012-001',
    sessionId: 'CHG-0012-001'
  },
  {
    id: 'op2',
    date: '2025-01-14 11:15',
    type: 'Комиссия',
    amount: -45,
    status: 'completed',
    details: 'Комиссия за обработку платежа'
  },
  {
    id: 'op3',
    date: '2025-01-13 09:45',
    type: 'Оплата сессии',
    amount: 320,
    status: 'completed',
    details: 'Сессия #CHG-0013-002',
    sessionId: 'CHG-0013-002'
  },
  {
    id: 'op4',
    date: '2025-01-12 16:20',
    type: 'Вывод средств',
    amount: -1000,
    status: 'completed',
    details: 'Вывод на карту **** 1234'
  },
  {
    id: 'op5',
    date: '2025-01-11 10:00',
    type: 'Подписка',
    amount: -990,
    status: 'completed',
    details: 'Оплата подписки "Базовый"'
  },
  {
    id: 'op6',
    date: '2025-01-10 15:30',
    type: 'Оплата сессии',
    amount: 280,
    status: 'pending',
    details: 'Сессия #CHG-0014-003',
    sessionId: 'CHG-0014-003'
  }
];

export const mockWithdrawalRequests: WithdrawalRequest[] = [
  {
    id: 'wd1',
    amount: 1000,
    method: 'банковская карта',
    details: 'Карта **** 1234',
    status: 'completed',
    createdAt: '2025-01-12'
  },
  {
    id: 'wd2',
    amount: 500,
    method: 'расчетный счет',
    details: 'Р/с 40702810******1234',
    status: 'processing',
    createdAt: '2025-01-18'
  }
];

// Утилитные функции
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export const getStatusBadgeVariant = (status: OperationStatus | WithdrawalStatus): StatusType => {
  switch (status) {
    case 'completed':
      return 'success';
    case 'pending':
      return 'warning';
    case 'processing':
      return 'info';
    case 'failed':
    case 'rejected':
      return 'danger';
    default:
      return 'offline';
  }
};

export const generateOperationId = (): string => {
  return `op_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const generateWithdrawalId = (): string => {
  return `wd_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};
