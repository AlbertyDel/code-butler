# CHARGE_admin Product Context

## Why This Project Exists

CHARGE_admin addresses the growing need for efficient electric vehicle charging infrastructure management by providing a modern, intuitive dashboard for both individual station owners and commercial operators. As EV adoption accelerates, the complexity of managing charging stations increases, requiring specialized tools that balance simplicity for personal users with advanced capabilities for business operations.

## Problems It Solves

### For Personal Users
- **Complexity Overload**: Individual EV owners need simple tools to manage their personal charging stations without being overwhelmed by commercial features
- **Lack of Unified View**: Home users struggle to monitor charging activity, energy consumption, and station status across multiple interfaces
- **Limited Insight**: Basic EVSE controllers provide minimal data visualization and historical analysis
- **Mobile Accessibility**: Many existing solutions are desktop-only, lacking responsive mobile interfaces

### For Commercial Operators
- **Fragmented Management**: Commercial operators juggle multiple systems for station control, pricing, billing, and reporting
- **Pricing Complexity**: Dynamic pricing strategies require sophisticated time-based rules that are difficult to implement and visualize
- **Financial Tracking**: Lack of integrated financial operations complicates revenue tracking and withdrawal management
- **Scale Challenges**: Managing dozens or hundreds of stations requires efficient interfaces with bulk operation support
- **Mode Switching**: Organizations need tools that can adapt to different operational contexts (personal vs. commercial use cases)

## How It Should Work

### Core User Journeys

#### Personal Mode Journey
1. **Initial Setup**: User sets mode to "personal" and views simplified dashboard with their 1-3 stations
2. **Daily Monitoring**: Check station status, today's energy consumption, and charging sessions
3. **Station Control**: Start/stop charging sessions with one-click actions
4. **History Review**: View session history with energy usage and duration
5. **Profile Management**: Update personal information and preferences

#### Commercial Mode Journey
1. **Business Overview**: Operator views comprehensive dashboard with KPIs for active stations, sessions, energy, revenue
2. **Station Fleet Management**: Add, edit, or remove stations with detailed configuration (power, ports, location, tariff)
3. **Pricing Strategy**: Create complex tariff rules with time-based pricing and visual validation
4. **Financial Operations**: Monitor balance, process withdrawals, manage subscriptions
5. **Session Analytics**: Analyze charging sessions with detailed metrics and filtering
6. **Team Coordination**: Manage organizational details and contact persons

### Key Interactions
- **Mode Switching**: Seamless transition between personal and commercial modes with appropriate feature sets
- **Data Persistence**: All user data persists locally with automatic synchronization to localStorage
- **Real-time Feedback**: Immediate visual feedback for all actions (toasts, status updates, loading states)
- **Progressive Disclosure**: Complex features revealed only when needed (e.g., tariff rules expand on demand)
- **Error Prevention**: Validation prevents invalid configurations (e.g., overlapping tariff rules, impossible power values)

## User Experience Goals

### Accessibility and Inclusivity
- **WCAG Compliance**: Meet AA standards for color contrast, keyboard navigation, and screen reader support
- **Language Support**: Russian interface with Cyrillic text and appropriate formatting for local context
- **Device Coverage**: Fully responsive design from 320px mobile screens to 3840px desktop displays
- **Touch Optimization**: Minimum 44px touch targets for mobile interactions

### Cognitive Load Management
- **Dual-Mode Simplicity**: Personal users see only relevant features; commercial users access full capabilities
- **Consistent Patterns**: Reusable UI components with predictable behavior across the application
- **Visual Hierarchy**: Clear information architecture with prioritized content based on user mode
- **Progressive Learning**: Complex features introduced gradually with visual cues and tooltips

### Performance Expectations
- **Fast Initial Load**: Application loads within 3 seconds on average connections
- **Responsive Interactions**: UI responds to user actions within 100ms for perceived immediacy
- **Smooth Transitions**: Layout changes and mode switches occur without jarring visual disruptions
- **Data Integrity**: User data is automatically saved and protected against corruption

### Trust and Reliability
- **Data Protection**: LocalStorage persistence ensures user data remains on their device
- **Error Recovery**: Graceful handling of edge cases with helpful error messages
- **Transparent State**: Clear indicators for loading, saving, and connection status
- **Predictable Behavior**: Consistent application of business rules and validation

## Success Metrics

### User Adoption Metrics
- **Mode Utilization**: Balanced usage between personal and commercial modes
- **Feature Engagement**: High usage rates for core features (station management, tariff creation, session viewing)
- **Session Duration**: Average session length indicating depth of engagement
- **Return Frequency**: Regular usage patterns suggesting integration into daily workflows

### Technical Performance Metrics
- **Page Load Time**: Consistent <3s load times across devices and connections
- **Error Rates**: <1% unhandled exceptions in production
- **Bundle Size**: Initial load under 500KB gzipped
- **Memory Usage**: Stable memory footprint without leaks during extended use

### Business Impact Metrics
- **Station Management Efficiency**: Reduced time to add/edit stations compared to legacy systems
- **Pricing Strategy Effectiveness**: Increased tariff rule creation and modification frequency
- **Data Accuracy**: High rate of valid station configurations and tariff rules
- **User Satisfaction**: Positive feedback on mode-switching experience and feature appropriateness

## User Personas

### Personal User: Alexei Petrov
- **Age**: 38
- **Occupation**: Software Engineer
- **EV Experience**: Tesla Model 3 owner for 2 years
- **Charging Setup**: Home wall connector (11kW) and portable charger (7kW)
- **Goals**: Monitor home charging costs, track energy usage, ensure station availability
- **Frustrations**: Complicated commercial tools, lack of mobile access, poor data visualization
- **Success Criteria**: Simple dashboard showing both stations, easy start/stop, clear energy reports

### Commercial Operator: Maria Ivanova
- **Age**: 42
- **Occupation**: Charging Network Manager
- **EV Experience**: Manages 50+ stations across 3 cities
- **Charging Setup**: Mixed fleet of 22kW, 11kW, and 7kW stations
- **Goals**: Optimize station utilization, implement dynamic pricing, track revenue, manage team access
- **Frustrations**: Multiple disconnected systems, complex pricing configuration, limited financial integration
- **Success Criteria**: Single dashboard for all operations, visual tariff management, integrated finance tracking

## Competitive Landscape

### Alternative Solutions
- **EVSE Manufacturer Portals**: Brand-specific tools with limited cross-platform support
- **Generic IoT Dashboards**: Overly technical interfaces requiring customization
- **Spreadsheet-Based Tracking**: Manual processes prone to errors and version issues
- **Enterprise Fleet Management**: Over-featured solutions with high complexity and cost

### CHARGE_admin Differentiators
- **Dual-Mode Architecture**: Single application serving both personal and commercial needs
- **Visual Tariff Management**: Intuitive rule visualization with overlap detection
- **Local-First Design**: Privacy-focused data storage with optional cloud synchronization
- **Responsive Excellence**: Truly mobile-optimized interface with touch-first design
- **Open Technology Stack**: Modern React/TypeScript foundation for extensibility

## Evolution Strategy

### Phase 1: Foundation (Current)
- Core dual-mode architecture with six main pages
- LocalStorage persistence with mock data
- Basic CRUD operations for stations and tariffs
- Responsive design system

### Phase 2: Enhancement
- Backend API integration for multi-device synchronization
- Real-time WebSocket connections for live status updates
- Advanced analytics and reporting dashboards
- Multi-user collaboration features

### Phase 3: Expansion
- Mobile app via React Native or PWA
- Payment processing integration
- Third-party service integrations (maps, weather, calendars)
- Public API for developer ecosystem

This product context defines the user-centric vision for CHARGE_admin, ensuring all technical decisions align with solving real problems for both personal and commercial EV charging station operators.
