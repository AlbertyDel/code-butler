import React from 'react';
import { Button } from '../ui/Button';
import { Edit, Trash2, Building, CreditCard, MapPin, MoreVertical, AlertTriangle, Zap, Cpu } from 'lucide-react';
import type { Station } from '../../data/stations';
import { StationStatusBadge } from '../ui/StatusBadge';
import { HeaderCell } from './HeaderCell';
import './StationsTable.css';

interface StationsTableProps {
  stations: Station[];
  onEdit: (station: Station) => void;
  onDelete: (id: string) => void;
  isCommercialMode: boolean;
  onStatusClick?: (station: Station) => void;
}

export const StationsTable: React.FC<StationsTableProps> = ({
  stations,
  onEdit,
  onDelete,
  isCommercialMode,
  onStatusClick,
}) => {
  if (stations.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted">Станции не найдены</p>
        <p className="text-sm text-muted mt-2">Попробуйте изменить параметры поиска или фильтры</p>
      </div>
    );
  }

  const handleStatusClick = (station: Station) => {
    if (onStatusClick) {
      onStatusClick(station);
    }
  };

  // Function to apply word count classes
  const applyWordCountClasses = () => {
    // This runs after render to apply word count classes
    setTimeout(() => {
      const table = document.querySelector('table');
      if (!table) return;
      
      // Find all text elements in name, tariff, and address columns
      const textElements = table.querySelectorAll(`
        td.px-4:nth-child(2) > div > p.font-medium.text-ink,
        td.px-4.tariff-cell > span.text-ink,
        td.px-4.address-cell > span.text-ink
      `);
      
      textElements.forEach(element => {
        const text = element.textContent || '';
        const isMultiWord = text.trim().includes(' ');
        element.classList.toggle('is-multiword', isMultiWord);
        element.classList.toggle('is-singleword', !isMultiWord);
      });
    }, 0);
  };

  // Apply word count classes after initial render and on updates
  React.useEffect(() => {
    applyWordCountClasses();
  }, [stations, isCommercialMode]);

  // Mode-specific design tokens
  const modeTokens = isCommercialMode ? {
    primary: 'bg-commercial-primary-500',
    primaryHover: 'hover:bg-commercial-primary-600',
    textPrimary: 'text-commercial-text-primary',
    textSecondary: 'text-commercial-text-secondary',
    border: 'border-commercial-primary-300',
    focus: 'focus:ring-commercial-primary-300',
    cardBorder: 'border-l-commercial-primary-500',
    surface: 'bg-commercial-surface-DEFAULT',
    background: 'bg-commercial-background-DEFAULT',
    backgroundDark: 'bg-commercial-background-dark',
  } : {
    primary: 'bg-personal-primary-500',
    primaryHover: 'hover:bg-personal-primary-600',
    textPrimary: 'text-personal-text-primary',
    textSecondary: 'text-personal-text-secondary',
    border: 'border-personal-primary-200',
    focus: 'focus:ring-personal-primary-300',
    cardBorder: 'border-l-personal-primary-500',
    surface: 'bg-personal-surface-DEFAULT',
    background: 'bg-personal-background-DEFAULT',
    backgroundDark: 'bg-personal-background-dark',
  };

  return (
    <div className={`stations-table-container overflow-x-auto ${modeTokens.surface} border ${modeTokens.border} rounded-lg shadow-sm`}>
      <table className="min-w-full text-sm divide-y divide-bg-2" data-commercial-mode={isCommercialMode}>
        {/* Column definitions - using CSS custom properties for responsive widths */}
        <colgroup>
          {/* Status column - shrinkable */}
          <col className="status-col" />
          
          {/* Name column - elastic */}
          <col className="name-col" />
          
          {/* Power column - hidden on mobile */}
          <col className="hidden sm:table-cell power-col" />
          
          {/* Ports column - hidden on mobile */}
          <col className="hidden sm:table-cell ports-col" />
          
          {/* Tariff column - conditional, only in commercial mode, shrinkable */}
          {isCommercialMode && (
            <col className="tariff-col" />
          )}
          
          {/* Address column - elastic */}
          <col className="address-col" />
          
          {/* Actions column - fit-content */}
          <col className="actions-col" />
        </colgroup>
        <thead className={`${modeTokens.surface}`}>
          <tr>
            {/* Status column - AlertTriangle icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={AlertTriangle}
              text="Статус"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
            
            {/* Name/ID column - Building icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Building}
              text="ID/Имя"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
            
            {/* Power column - hidden on mobile, icon on tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Zap}
              text="Мощность"
              showMobileIcon={false}
              showTabletIcon={true}
              showDesktopText={true}
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="center"
              isPowerOrPortsColumn={true}
              className="hidden sm:table-cell sm:text-center lg:text-center"
            />
            
            {/* Ports column - hidden on mobile, icon on tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Cpu}
              text="Порты"
              showMobileIcon={false}
              showTabletIcon={true}
              showDesktopText={true}
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="center"
              isPowerOrPortsColumn={true}
              className="hidden sm:table-cell sm:text-center lg:text-center"
            />
            
            {/* Tariff column - CreditCard icon on mobile/tablet, text on desktop (≥1024px) (if commercial mode) */}
            {isCommercialMode && (
              <HeaderCell
                icon={CreditCard}
                text="Тариф"
                mobileAlign="center"
                tabletAlign="center"
                desktopAlign="center"
                className="sm:text-center lg:text-center"
              />
            )}
            
            {/* Location column - MapPin icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={MapPin}
              text="Локация"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
            
            {/* Actions column - MoreVertical icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={MoreVertical}
              text="Действия"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
          </tr>
        </thead>
        <tbody className={`${modeTokens.surface} divide-y divide-bg-2`}>
          {stations.map((station) => (
            <tr key={station.id} className={`hover:${modeTokens.backgroundDark} transition-colors`}>
              <td className="px-4 py-3">
                <button
                  onClick={() => handleStatusClick(station)}
                  className={`focus:outline-none focus:ring-2 ${modeTokens.focus} focus:ring-offset-2 rounded`}
                  title="Показать детали станции"
                  aria-label={`Показать детали станции ${station.name}`}
                >
                  <StationStatusBadge status={station.status} />
                </button>
              </td>
              <td className="px-4 py-3">
                <div>
                  <p className={`font-medium ${modeTokens.textPrimary}`}>{station.name}</p>
                  <p className={`text-sm ${modeTokens.textSecondary} font-mono hidden sm:block`}>ID: {station.id}</p>
                </div>
              </td>
              <td className="px-4 py-3 hidden sm:table-cell sm:text-center">
                <span className={`font-medium ${modeTokens.textPrimary}`}>{station.power} кВт</span>
              </td>
              <td className="px-4 py-3 hidden sm:table-cell sm:text-center">
                <span className={modeTokens.textPrimary}>{station.ports}</span>
              </td>
              {isCommercialMode && (
                <td className="px-4 py-3 tariff-cell sm:text-center">
                  <span className={`text-sm ${modeTokens.textPrimary}`}>{station.tariffName || 'Базовый'}</span>
                </td>
              )}
              <td className="px-4 py-3 address-cell">
                <span className={`text-sm ${modeTokens.textPrimary}`}>{station.location}</span>
              </td>
              <td className="px-4 py-3 actions-cell">
                <div className="actions-container">
                  <Button
                    variant="primary"
                    size="md"
                    icon={Edit}
                    onClick={() => onEdit(station)}
                    title="Редактировать"
                    aria-label={`Редактировать станцию ${station.name}`}
                    className="action-button"
                  >
                    <span className="hidden sm:inline">Редактировать</span>
                  </Button>
                  <Button
                    variant="danger"
                    size="md"
                    icon={Trash2}
                    onClick={() => onDelete(station.id)}
                    title="Удалить"
                    aria-label={`Удалить станцию ${station.name}`}
                    className="action-button"
                  >
                    <span className="hidden sm:inline">Удалить</span>
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
