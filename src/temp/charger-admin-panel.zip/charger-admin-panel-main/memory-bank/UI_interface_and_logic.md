# CHARGE_admin UI Interface and User Logic Documentation

## Table of Contents
1. [UI Architecture Overview](#ui-architecture-overview)
2. [Page-by-Page Analysis](#page-by-page-analysis)
3. [Component Library Documentation](#component-library-documentation)
4. [User Interaction Patterns](#user-interaction-patterns)
5. [Data Flow & State Management](#data-flow--state-management)
6. [Code Snapshots](#code-snapshots)

## UI Architecture Overview

The CHARGE_admin application is built around a sophisticated, multi-layered architecture that seamlessly adapts to both **personal** and **commercial** user scenarios while providing a consistent experience across desktop and mobile devices. This architecture is not just a technical implementation but a user-centric design that shapes every interaction.

### 🎯 Dual-Mode Design: Two Products in One

At the heart of the application lies the **ModeContext** - a simple yet powerful React context that defines whether the user is operating in "personal" or "commercial" mode. This single boolean state (`mode: 'personal' | 'commercial'`) orchestrates a cascade of UI transformations:

```typescript
// ModeContext.tsx - The architectural decision point
type Mode = 'personal' | 'commercial';
const [mode, setMode] = useState<Mode>('personal');
```

**Visual Transformation Across the Application:**

| Aspect | Personal Mode (Home User) | Commercial Mode (Business Operator) |
|--------|---------------------------|-------------------------------------|
| **Dashboard** | Card-based station view, personal energy stats | Professional KPI cards, full station table |
| **Navigation** | Simplified: Home, Stations, Sessions, Profile | Full suite: + Tariffs, Finance |
| **Data Display** | Basic session info, no cost columns | Financial columns, revenue calculations |
| **Access Control** | All basic features available | Protected routes for advanced features |

**Protected Routes Implementation:**
The application uses a `ProtectedRoute` wrapper component that checks the current mode before rendering sensitive pages. This creates an invisible boundary between personal and commercial features:

```tsx
// App.tsx - Route protection based on mode
<Route path="/tariffs" element={
  <ProtectedRoute allowedModes={['commercial']}>
    <Tariffs />
  </ProtectedRoute>
} />
```

When a personal user attempts to access `/tariffs` or `/finance`, they are seamlessly redirected to the dashboard - no error messages, no confusion, just gentle guidance back to appropriate content.

### 📱 Responsive Layout System: Adaptive Interfaces

The application employs a **mobile-first responsive design** that fundamentally changes its navigation paradigm based on screen size:

```tsx
// ResponsiveLayout.tsx - The layout switcher
const isDesktop = useMediaQuery('(min-width: 1024px)');
return isDesktop ? <DesktopLayout /> : <MobileLayout />;
```

**Desktop Experience (≥1024px):**
- **Sidebar Navigation**: Persistent left sidebar with full-height navigation
- **Ample Space**: Wide content areas for tables and detailed views
- **Header Area**: Top header with user info and logout
- **Visual Hierarchy**: Clear separation between navigation and content

**Mobile Experience (<1024px):**
- **Bottom Navigation**: Thumb-friendly bottom tabs for primary navigation
- **Hamburger Menu**: Slide-out drawer for secondary options
- **Compact Design**: Stacked content, simplified tables
- **Touch Optimization**: Larger buttons, appropriate spacing

**Navigation Filtering by Mode:**
Both layouts dynamically filter navigation items based on the current mode. In personal mode, "Тарифы" (Tariffs) and "Финансы" (Finance) disappear from navigation:

```tsx
// DesktopLayout.tsx & MobileLayout.tsx - Mode-aware filtering
const filteredNavigationItems = navigationItems.filter(item => {
  if (mode === 'personal') {
    return item.name !== 'Тарифы' && item.name !== 'Финансы';
  }
  return true;
});
```

### 🏗️ Component Hierarchy: The Structural Blueprint

The application follows a clear, hierarchical structure that ensures maintainability and scalability:

```
App.tsx (Root Component)
├── Context Providers (Global State)
│   ├── ModeContext.tsx (Personal/Commercial mode)
│   ├── UserContext.tsx (User profile data)
│   ├── TariffContext.tsx (Pricing rules)
│   └── FinanceContext.tsx (Financial operations)
├── ResponsiveLayout.tsx (Layout Switcher)
│   ├── DesktopLayout.tsx (Desktop Navigation)
│   │   ├── Sidebar with filtered navigation
│   │   ├── Header with user info
│   │   └── Main content area
│   └── MobileLayout.tsx (Mobile Navigation)
│       ├── Bottom tab navigation
│       ├── Hamburger menu drawer
│       └── Compact content area
└── Page Components (Route-based)
    ├── Dashboard.tsx (Dual-mode dashboard)
    ├── Stations.tsx (Station management)
    ├── Sessions.tsx (Session history)
    ├── Tariffs.tsx (Tariff management) *
    ├── Finance.tsx (Financial operations) *
    └── Profile.tsx (User profile)
```

*Note: Tariffs and Finance pages are only accessible in commercial mode*

**Context Provider Nesting:**
The application wraps all components in a carefully ordered context provider chain in `App.tsx`:

```tsx
<ToastProvider>
  <UserProvider>
    <ModeProvider>
      <TariffProvider>
        <FinanceProvider>
          {/* Router and Layout components */}
        </FinanceProvider>
      </TariffProvider>
    </ModeProvider>
  </UserProvider>
</ToastProvider>
```

This order ensures that:
1. Toast notifications are available everywhere
2. User data is accessible throughout
3. Mode context can be used by all downstream providers
4. Tariff and finance contexts can depend on mode

### 🔄 Routing Architecture: Seamless Navigation Flow

The routing system is designed for both performance and user experience:

**Code Splitting:** Each page is lazy-loaded to reduce initial bundle size:
```tsx
const Dashboard = lazy(() => import('./pages/Dashboard'));
```

**Loading States:** A consistent loading spinner appears during page transitions:
```tsx
const PageLoading = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-brand border-r-transparent" />
  </div>
);
```

**Route Structure:**
- `/` - Dashboard (dual-mode)
- `/stations` - Station management (both modes)
- `/sessions` - Session history (both modes, different columns)
- `/tariffs` - Tariff management (commercial only)
- `/finance` - Financial operations (commercial only)
- `/profile` - User profile (both modes, different tabs)

### 🎨 Visual Design System: Consistent UI Language

The application uses a cohesive design system built on:

**Tailwind CSS Configuration:**
- Custom color palette with semantic names (`brand`, `info`, `warning`, `success`, `error`)
- Design tokens for text (`ink`, `muted`), backgrounds (`bg1`, `bg2`)
- Consistent spacing scale and typography

**Component Variants:**
- **Buttons**: `primary`, `secondary`, `danger`, `ghost`, `icon` with consistent sizing
- **Cards**: `default` and `filled` variants for content containers
- **Status Badges**: Color-coded indicators for system states
- **Metric Cards**: Standardized KPI displays with icons

**Micro-interactions:**
- Buttons have `active:scale-95` for tactile feedback
- Transitions use `duration-200 ease-in-out` for smooth animations
- Hover states provide visual affordance

### 🔐 Security and Access Patterns

The architecture implements several security and access patterns:

1. **Mode-Based Authorization**: Simple but effective - features are shown/hidden based on mode
2. **Route Protection**: Automatic redirection for unauthorized access attempts
3. **Data Segregation**: Commercial features only load commercial data
4. **Progressive Disclosure**: Users only see what's relevant to their current mode

### 🚀 Performance Considerations

The architecture is optimized for performance:

1. **Lazy Loading**: Pages load on-demand, reducing initial bundle size
2. **Context Segmentation**: Separate contexts prevent unnecessary re-renders
3. **Responsive Images**: Icons are SVG-based and scale perfectly
4. **Efficient State Updates**: LocalStorage persistence happens without blocking UI

This architectural approach creates a foundation that is both **flexible** (supporting two distinct user types) and **consistent** (providing a unified experience across devices). The clear separation of concerns allows for easy maintenance and future expansion, whether adding new features for commercial users or enhancing the personal experience.

## Page-by-Page Analysis

### 1. Dashboard.tsx - Dual-Mode Dashboard: The Application's Command Center

**Purpose**: The Dashboard serves as the primary landing page and central hub for monitoring charging infrastructure. It dynamically adapts to provide a tailored experience for both personal users and commercial operators, showcasing the core dual-mode architecture in action.

**Architectural Foundation**:
- **Mode Context Integration**: Uses `useMode()` hook to determine current operating mode
- **Component Composition**: Built from reusable UI components (MetricCard, EnergyChart, Card, Button, StatusBadge)
- **Mock Data Strategy**: Demonstrates UI patterns with deterministic mock data from `/data` modules
- **Responsive Design**: Mobile-first layout with Tailwind CSS grid systems

#### 🏢 Commercial Mode: Professional Operations Dashboard

**Visual Layout**: 
1. **Header Section**: "Панель управления" (Control Panel) with contextual subtitle and "Add Station" button
2. **KPI Dashboard**: 4 metric cards displaying key business indicators
3. **Energy Visualization**: Weekly consumption chart using Recharts
4. **Stations Overview**: Professional table with 7 columns for fleet management
5. **Connection Status**: Real-time connectivity indicator with status badge

**Key Components & Data Flow**:

```typescript
// Commercial Mode Dashboard Structure
<Dashboard>
  <Header>
    <Title>Панель управления</Title>
    <Subtitle>Обзор ваших зарядных станций и активности</Subtitle>
    <Button icon={Plus}>Добавить станцию</Button>
  </Header>
  
  <KPI_Grid>
    <MetricCard icon={Battery} label="Активные станции" value="8" change="+2" />
    <MetricCard icon={Clock} label="Сессии сегодня" value="24" change="+5" />
    <MetricCard icon={Zap} label="Энергия (кВт·ч)" value="1,248" change="+312" />
    <MetricCard icon={DollarSign} label="Доход (руб)" value="45,620" change="+8,240" />
  </KPI_Grid>
  
  <EnergyChart data={mockEnergyData} title="Потребление энергии за неделю" />
  
  <Stations_Table>
    <TableHeader>
      <Column>Статус</Column>
      <Column>Device ID / Имя</Column>
      <Column>Тариф</Column>
      <Column>Мощность</Column>
      <Column>Сессии</Column>
      <Column>Локация</Column>
      <Column>Действия</Column>
    </TableHeader>
    <TableBody>
      {mockStations.map(station => (
        <TableRow>
          <Cell><StationStatusBadge status={station.status} /></Cell>
          <Cell>
            <DeviceName>{station.name}</DeviceName>
            <DeviceID>{station.id}</DeviceID>
          </Cell>
          <Cell>Базовый</Cell>
          <Cell>{station.power} кВт</Cell>
          <Cell>{station.sessionsToday}</Cell>
          <Cell>{station.location}</Cell>
          <Cell>
            {station.status === 'charging' ? (
              <Button variant="secondary" icon={StopCircle}>Остановить</Button>
            ) : (
              <Button variant="primary" icon={Play}>Запустить</Button>
            )}
          </Cell>
        </TableRow>
      ))}
    </TableBody>
  </Stations_Table>
</Dashboard>
```

**MetricCard Component Implementation**:
The KPI cards use a standardized `MetricCard` component that provides consistent styling and behavior:

```typescript
// MetricCard.tsx - Reusable KPI Component
export const MetricCard: React.FC<MetricCardProps> = ({ icon, label, value, change }) => {
  return (
    <div className="flex items-center p-4 bg-bg2 border border-gray-200 rounded-lg shadow-sm">
      <div className="p-3 rounded-full bg-brand/light text-brand">{icon}</div>
      <div className="ml-4 flex flex-col gap-1">
        <span className="text-muted text-sm">{label}</span>
        <div className="flex items-baseline gap-2">
          <span className="text-ink text-2xl font-semibold">{value}</span>
          {change && (
            <span className={cn(
              "text-xs font-medium px-1.5 py-0.5 rounded",
              change.startsWith('+') ? "bg-success/10 text-success" : "bg-error/10 text-error"
            )}>
              {change}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
```

**Mock Data Structure**:
The dashboard uses deterministic mock data from `dashboard-stations.ts`:

```typescript
// dashboard-stations.ts - Mock data for demonstration
export interface DashboardStation {
  id: string;           // CHG-0012
  name: string;         // Станция А
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;        // 7, 11, or 22 kW
  location: string;     // Москва
  sessionsToday: number;
}

export const mockStations: DashboardStation[] = [
  { id: 'CHG-0012', name: 'Станция А', status: 'charging', power: 22, location: 'Москва', sessionsToday: 3 },
  { id: 'CHG-0013', name: 'Станция Б', status: 'ready', power: 11, location: 'Санкт-Петербург', sessionsToday: 1 },
  // ... more stations
];
```

#### 🏡 Personal Mode: Home User Dashboard

**Visual Layout**:
1. **Header Section**: "Панель управления" with subtitle "Мои зарядные станции"
2. **My Stations Grid**: Card-based display of up to 3 stations with detailed information
3. **Quick Stats**: Two metric cards for personal charging metrics
4. **Personal Energy Chart**: Customized energy consumption visualization
5. **Connection Status**: Same real-time indicator as commercial mode

**Component Structure**:

```typescript
// Personal Mode Dashboard Structure
<Dashboard>
  <Header>
    <Title>Панель управления</Title>
    <Subtitle>Мои зарядные станции</Subtitle>
    {/* No "Add Station" button in personal mode */}
  </Header>
  
  <MyStations_Grid>
    {mockStations.slice(0, 3).map(station => (
      <Station_Card>
        <CardHeader>
          <StationStatusBadge status={station.status} />
          <StationInfo>
            <Name>{station.name}</Name>
            <ID>{station.id}</ID>
          </StationInfo>
        </CardHeader>
        <CardBody>
          <Detail label="Мощность" value={`${station.power} кВт`} />
          <Detail label="Сегодня" value={`${station.sessionsToday} сессий`} />
          <Detail label="Локация" value={station.location} />
        </CardBody>
        <CardFooter>
          <Button variant="primary" icon={Play}>Запустить</Button>
          <Button variant="secondary" icon={StopCircle}>Остановить</Button>
        </CardFooter>
      </Station_Card>
    ))}
  </MyStations_Grid>
  
  <QuickStats_Grid>
    <MetricCard icon={Zap} label="Сегодняшняя зарядка" value="42 кВт·ч" />
    <MetricCard icon={Clock} label="Время зарядки" value="3 ч 42 мин" />
  </QuickStats_Grid>
  
  <EnergyChart data={mockEnergyData.slice(0, 5)} title="Мое потребление энергии" />
</Dashboard>
```

**EnergyChart Component**:
Both modes use the same `EnergyChart` component with different data subsets:

```typescript
// EnergyChart.tsx - Data Visualization Component
export const EnergyChart: React.FC<EnergyChartProps> = ({ data, title, height }) => {
  return (
    <div className="bg-bg2 border border-gray-200 rounded-lg p-4 shadow-sm">
      <h3 className="text-ink font-medium mb-2">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#667085' }} />
          <YAxis tick={{ fontSize: 12, fill: '#667085' }} />
          <Tooltip formatter={(value) => [`${value || 0} kWh`, 'Energy']} />
          <Line type="monotone" dataKey="kwh" stroke="#12B76A" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
```

#### 🔄 User Interaction Patterns

**Station Control Actions**:
- **Start Station**: Primary button with Play icon, logs to console in current implementation
- **Stop Station**: Secondary button with StopCircle icon, appears only when station is charging
- **Console Logging**: All actions currently log to console as placeholder for real API integration

**Conditional Rendering Logic**:
```typescript
// Mode-based conditional rendering
{mode === 'commercial' ? (
  // Commercial mode components
  <>
    <CommercialKPI />
    <CommercialTable />
  </>
) : (
  // Personal mode components
  <>
    <PersonalStations />
    <PersonalStats />
  </>
)}
```

**Responsive Design Implementation**:
- **Grid Systems**: Uses Tailwind CSS responsive grid classes (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`)
- **Table Responsiveness**: Horizontal scrolling for tables on small screens
- **Card Layout**: Cards stack vertically on mobile, arrange in grids on larger screens

#### 📊 Data Visualization Strategy

**Mock Energy Data**:
- **Commercial**: Full dataset showing weekly trends
- **Personal**: Subset (first 5 days) for personal consumption
- **Chart Customization**: Different titles and heights for each mode

**Station Status Visualization**:
- **StationStatusBadge**: Color-coded status indicators (charging=green, ready=blue, offline=gray, pending=yellow, fault=red)
- **Real-time Connection**: Green dot with "Подключено" (Connected) badge

#### 🎯 User Experience Design

**Progressive Disclosure**:
- **Commercial Users**: Get full business intelligence with KPIs, detailed tables, and revenue metrics
- **Personal Users**: See only relevant personal station info and charging statistics

**Visual Hierarchy**:
1. **Primary Information**: Station status and availability
2. **Secondary Metrics**: Energy consumption and session data
3. **Tertiary Actions**: Station control buttons
4. **System Status**: Connection indicator at bottom

**Accessibility Features**:
- Semantic HTML structure
- ARIA labels on interactive elements
- Color contrast compliance with design system
- Keyboard navigable tables and buttons

This dashboard implementation demonstrates the power of React's component-based architecture combined with a thoughtful dual-mode design. The same codebase delivers two distinct user experiences while maintaining consistency in design patterns and code quality.

### 2. Stations.tsx - Station Management: Central Hub for Charging Infrastructure

**Purpose**: The Stations page serves as the operational nerve center for managing electric vehicle charging stations. It provides comprehensive CRUD (Create, Read, Update, Delete) operations with a focus on data integrity and user-friendly interactions. This page exemplifies the application's commitment to robust data management through localStorage persistence and validation.

**Architectural Foundation**:
- **Persistent State Management**: Uses `usePersistentData` hook for localStorage-backed state
- **Component Composition**: Integrates modal forms, table components, and statistical displays
- **Data Validation**: Implements normalization functions to ensure data consistency
- **Context Integration**: Leverages `ModeContext` and `TariffContext` for mode-aware features

#### 🏗️ Component Structure and Data Flow

**Hierarchical Component Layout**:
```
Stations.tsx (Main Component)
├── Header Section
│   ├── Title: "Станции" (Stations)
│   ├── Subtitle: "Управление зарядными станциями и мониторинг"
│   └── Add Station Button (Commercial mode only)
├── Statistics Card
│   ├── Total Stations Counter
│   └── Battery Icon Visualization
├── StationsTable Component
│   ├── Table Header with 7 Columns
│   ├── Sorted Station Rows
│   └── Edit/Delete Action Buttons
└── StationModal Component
    ├── StationForm for Data Entry
    ├── Validation Logic
    └── Save/Cancel Operations
```

**Data Flow Architecture**:
```typescript
// Initial Data Loading Flow
1. Component Mount → usePersistentData('stations', normalizeStations(defaultStations))
2. localStorage Check → Load existing data or use default
3. Data Normalization → normalizeStations() ensures consistency
4. State Initialization → Sorted stations displayed in table

// User Interaction Flow
User Action → Event Handler → State Update → localStorage Persistence → UI Re-render
```

#### 🔧 Data Normalization and Validation

**The `normalizeStations()` Function**:
This critical function ensures all station data adheres to system constraints before being stored or displayed:

```typescript
const normalizeStations = (stations: Station[]): Station[] => {
  return stations.map(station => {
    const normalizedStation = {
      ...station,
      // Power must be 7, 11, or 22 kW - default to 11 if invalid
      power: [7, 11, 22].includes(station.power) ? station.power : 11,
      // Ports can only be 1 or 2 - default to 2 if invalid
      ports: station.ports === 1 || station.ports === 2 ? station.ports : 2,
    };
    // Ensure every station has a tariff name
    if (!normalizedStation.tariffName) {
      normalizedStation.tariffName = 'Базовый';
    }
    return normalizedStation;
  });
};
```

**Why Normalization is Essential**:
- **Hardware Compatibility**: Charging stations in the real world have specific power ratings (7, 11, 22 kW)
- **Physical Constraints**: Stations physically have 1 or 2 charging ports
- **Business Logic**: Every station must be associated with a tariff for pricing calculations
- **Data Integrity**: Prevents invalid data from corrupting the application state

**Default Station Data Structure**:
```typescript
// stations.ts - Deterministic mock data generation
export interface Station {
  id: string;           // CHG-1000, CHG-1001, etc.
  name: string;         // Станция А, Станция Б (Cyrillic letters)
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;        // 7, 11, or 22 kW
  ports: number;        // 1 or 2
  location: string;     // Russian addresses with cities
  tariffName: string;   // Базовый, Премиум, Ночной
  energyToday: number;  // kWh consumed today
}

export const defaultStations: Station[] = Array.from({ length: 12 }).map((_, i) => ({
  id: `CHG-${1000 + i}`,
  name: `Станция ${String.fromCharCode(1040 + i)}`, // А, Б, В, Г...
  status: faker.helpers.arrayElement(['charging', 'ready', 'offline', 'pending', 'fault']),
  power: faker.helpers.arrayElement([7, 11, 22]),
  ports: faker.helpers.arrayElement([1, 2]),
  location: `${faker.location.streetAddress()}, ${faker.location.city()}`,
  tariffName: faker.helpers.arrayElement(['Базовый', 'Премиум', 'Ночной']),
  energyToday: faker.number.float({ min: 5, max: 90, multipleOf: 0.1 }),
}));
```

#### 💾 Persistent Storage Strategy

**`usePersistentData` Hook Implementation**:
The custom hook provides seamless localStorage integration with React state:

```typescript
// usePersistentData.ts - Generic localStorage hook
export function usePersistentData<T>(key: string, initialData: T): [T, (newData: T) => void] {
  const [data, setData] = useState<T>(() => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initialData;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(data));
  }, [key, data]);

  return [data, setData];
}

// Usage in Stations.tsx
const [stations, setStations] = usePersistentData<Station[]>(
  'stations',
  normalizeStations(defaultStations as Station[])
);
```

**Storage Behavior**:
- **Initial Load**: Checks `localStorage` for existing data, falls back to normalized default stations
- **Automatic Persistence**: Any state update automatically triggers `localStorage` update via `useEffect`
- **Key Namespacing**: Uses simple key `'stations'` (note: in other contexts, keys are prefixed with `'charge_admin_'`)
- **Data Serialization**: Automatic JSON serialization/deserialization

#### 🎯 User Interaction and State Management

**Modal State Management**:
```typescript
// Modal state variables
const [isModalOpen, setIsModalOpen] = useState(false);
const [editingStation, setEditingStation] = useState<Station | null>(null);

// Modal handlers
const handleOpenModal = (station?: Station) => {
  setEditingStation(station || null);
  setIsModalOpen(true);
};

const handleCloseModal = () => {
  setIsModalOpen(false);
  setEditingStation(null);
};
```

**CRUD Operations Flow**:

**Create Operation**:
```typescript
const handleAddStation = () => {
  handleOpenModal(); // Opens empty modal for new station
};

const handleSaveStation = (stationData: Station) => {
  // Add new station
  setStations([...stations, stationData]);
  handleCloseModal();
};
```

**Update Operation**:
```typescript
const handleEditStation = (station: Station) => {
  handleOpenModal(station); // Opens modal with station data
};

const handleSaveStation = (stationData: Station) => {
  if (editingStation) {
    // Edit existing station
    setStations(stations.map(s => s.id === stationData.id ? stationData : s));
  }
  handleCloseModal();
};
```

**Delete Operation**:
```typescript
const handleDeleteStation = (id: string) => {
  if (window.confirm('Вы уверены, что хотите удалить эту станцию?')) {
    setStations(stations.filter(s => s.id !== id));
  }
};
```

**Sorting Logic**:
```typescript
// Sort stations by name ascending (Cyrillic alphabet aware)
const sortedStations = [...stations].sort((a, b) => a.name.localeCompare(b.name));
```

#### 📊 Statistics and Visual Feedback

**Total Stations Counter**:
```tsx
<Card variant="filled">
  <CardContent className="p-6">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm text-muted">Всего станций</p>
        <p className="text-3xl font-bold text-ink">{totalStats.totalStations}</p>
      </div>
      <div className="h-12 w-12 rounded-full bg-brand/10 flex items-center justify-center">
        <Battery className="h-6 w-6 text-brand" />
      </div>
    </div>
  </CardContent>
</Card>
```

**Visual Design Elements**:
- **Battery Icon**: Circular container with brand color background
- **Counter Display**: Large, bold typography for emphasis
- **Card Design**: Filled variant for visual distinction from content cards
- **Responsive Layout**: Single column grid that adapts to container width

#### 🔄 Integration with Application Context

**Mode Context Usage**:
```typescript
const { mode: appMode } = useMode();
// Controls whether "Add Station" button is displayed
// Passes isCommercialMode prop to StationsTable for conditional columns
```

**Tariff Context Integration**:
```typescript
useTariff(); // Keeps tariff context available for form components
// Note: The Stations page doesn't directly use tariffs but ensures context is loaded
```

**Component Props Configuration**:
```tsx
<StationsTable
  stations={sortedStations}
  onEdit={handleEditStation}
  onDelete={handleDeleteStation}
  isCommercialMode={appMode === 'commercial'}
/>
```

#### 🎨 User Experience Design

**Progressive Disclosure**:
- **Commercial Mode**: Full CRUD operations with "Add Station" button
- **Personal Mode**: Read-only table view without creation capabilities
- **Contextual Actions**: Edit/Delete buttons only appear on hover for clean interface

**Confirmation Dialogs**:
- **Delete Operations**: Standard browser `confirm()` dialog with Russian text
- **User Safety**: Prevents accidental data loss with explicit confirmation

**Modal Interaction Patterns**:
- **Edit Mode**: Modal pre-filled with station data
- **Create Mode**: Empty form with validation
- **Consistent Behavior**: Same modal component for both operations

**Responsive Design**:
- **Table Responsiveness**: Horizontal scrolling on small screens
- **Card Layout**: Statistics card uses single column grid
- **Button Placement**: Action buttons positioned for thumb accessibility on mobile

#### 🛡️ Error Handling and Edge Cases

**Data Corruption Recovery**:
- Normalization function repairs invalid power and port values
- Default tariff assignment ensures business logic compatibility
- localStorage parsing errors fall back to default data

**Empty State Management**:
- Table gracefully handles empty station arrays
- Statistics counter shows "0" when no stations exist
- Add button remains available for initial station creation

**User Input Validation**:
- Form-level validation in `StationModal` component
- Power and port constraints enforced during normalization
- Unique ID generation for new stations

This station management implementation demonstrates a robust approach to data persistence, user interaction, and system integrity. The careful balance between flexibility (supporting various station configurations) and constraints (enforcing business rules) creates a reliable foundation for managing critical charging infrastructure.

### 3. Sessions.tsx - Session History & Monitoring: Real-Time Charging Analytics

**Purpose**: The Sessions page provides comprehensive monitoring and historical analysis of electric vehicle charging sessions. It serves as a critical tool for both personal users tracking their charging habits and commercial operators managing revenue-generating activities. The page dynamically adapts to the current mode, offering financial insights for business users while maintaining simplicity for home users.

**Architectural Foundation**:
- **Mode Context Integration**: Uses `useMode()` hook to conditionally render financial data
- **Expandable Table Design**: Implements nested rows for detailed session information
- **Real-time Statistics**: Calculates live metrics from mock session data
- **Responsive Data Grid**: Adapts column layout based on screen size and mode

#### 📊 Dual-Mode Statistical Dashboard

**Commercial Mode Statistics (4 Cards)**:
1. **Total Sessions**: Count of all sessions with Clock icon
2. **Active Sessions**: Currently charging sessions with Play icon and info color
3. **Energy Consumed**: Total kWh with Zap icon and warning color
4. **Revenue Generated**: Total income in RUB with DollarSign icon and brand color

**Personal Mode Statistics (3 Cards)**:
1. **Total Sessions**: Count of all sessions
2. **Active Sessions**: Currently charging sessions
3. **Energy Consumed**: Total kWh used

**Statistical Calculation**:
```typescript
const totalStats = {
  totalSessions: filteredSessions.length,
  activeSessions: filteredSessions.filter(s => s.status === 'active').length,
  totalEnergy: filteredSessions.reduce((sum, session) => sum + session.energy, 0),
  totalRevenue: filteredSessions.reduce((sum, session) => sum + session.cost, 0),
};
```

#### 🗂️ Session Data Structure and Mock Generation

**Session Interface**:
```typescript
export interface Session {
  id: string;           // SESS-2025-0012
  stationId: string;    // CHG-0012
  stationName: string;  // Станция А
  userId: string;       // USER-0456
  userName: string;     // Иван Петров
  startTime: string;    // 2025-01-05 14:30
  endTime: string | null;
  duration: string;     // 2ч 15м
  energy: number;       // 24.8 kWh
  power: number;        // 11 kW
  cost: number;         // 745 RUB
  status: 'active' | 'completed' | 'cancelled' | 'failed';
  paymentMethod: 'карта' | 'кошелёк';
}
```

**Mock Data Characteristics**:
- **Deterministic Generation**: Uses Faker.js with fixed seed (2026) for consistent data
- **Realistic Time Distribution**: Sessions distributed throughout the day (8:00-20:00)
- **Plausible Energy Values**: 5-80 kWh range with 0.1 kWh precision
- **Realistic Pricing**: 30 RUB/kWh standard rate for cost calculation
- **Status Distribution**: 80% completed, 20% active/cancelled for demo realism

#### 🎛️ Time Range Filtering System

**Filter Options**:
```typescript
const timeRanges = [
  { label: 'Сегодня', value: 'today' },
  { label: 'Вчера', value: 'yesterday' },
  { label: '7 дней', value: '7days' },
  { label: '30 дней', value: '30days' },
  { label: 'Все время', value: 'all' },
];
```

**UI Implementation**:
```tsx
<div className="flex rounded-lg border border-bg-2 p-1 w-fit">
  {timeRanges.map((range) => (
    <button
      key={range.value}
      onClick={() => setTimeRange(range.value)}
      className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${timeRange === range.value ? 'bg-brand text-white' : 'text-muted hover:text-ink'}`}
    >
      {range.label}
    </button>
  ))}
</div>
```

**Visual Design**:
- **Pill-shaped Buttons**: Rounded rectangular filter buttons
- **Active State Highlighting**: Brand-colored background for selected filter
- **Hover Effects**: Text color change on hover for inactive buttons
- **Compact Layout**: Minimal padding for space efficiency

#### 📋 Expandable Table with Nested Rows

**Table Structure**:
- **7 Columns (Personal Mode)**: Session ID, Station, Time, Duration, Energy, Status, Details
- **8 Columns (Commercial Mode)**: Adds Cost column after Energy
- **Expandable Rows**: Chevron toggle reveals detailed session metrics

**Column Conditional Rendering**:
```tsx
{mode === 'commercial' && (
  <th className="text-left py-3 px-4 text-sm font-medium text-muted">Стоимость</th>
)}
```

**Row Expansion Logic**:
```typescript
const [expandedSession, setExpandedSession] = useState<string | null>(null);

const toggleSessionDetails = (id: string) => {
  setExpandedSession(expandedSession === id ? null : id);
};
```

**Expanded Row Content**:
- **Commercial Mode (4 detail cards)**: Power, Payment Method, Tariff, Average Speed
- **Personal Mode (2 detail cards)**: Power, Average Speed
- **Grid Responsiveness**: Adapts from 1 to 4 columns based on screen width

**Detail Card Implementation**:
```tsx
<div className={`grid gap-4 ${mode === 'commercial' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2'}`}>
  <div className="bg-bg-2 rounded-lg p-4">
    <p className="text-xs text-muted mb-1">Мощность</p>
    <div className="flex items-center">
      <Battery className="h-4 w-4 text-brand mr-2" />
      <p className="font-medium text-ink">{session.power} кВт</p>
    </div>
  </div>
  {/* Additional detail cards */}
</div>
```

#### 🎨 Status Visualization System

**StatusBadge Component Architecture**:
```typescript
const statusConfig = {
  success: { icon: Plug, bg: 'bg-success/10', text: 'text-success' },
  info: { icon: CheckCircle, bg: 'bg-brand/light', text: 'text-brand-dark' },
  warning: { icon: Clock, bg: 'bg-warning/10', text: 'text-warning' },
  danger: { icon: AlertTriangle, bg: 'bg-error/10', text: 'text-error' },
  offline: { icon: Circle, bg: 'bg-error/10', text: 'text-error' },
};
```

**Session Status Mapping**:
```typescript
const getStatusConfig = (status: string) => {
  switch (status) {
    case 'active': return { type: 'success' as const, label: 'Активна' };
    case 'completed': return { type: 'info' as const, label: 'Завершена' };
    case 'cancelled': return { type: 'warning' as const, label: 'Отменена' };
    case 'failed': return { type: 'danger' as const, label: 'Ошибка' };
    default: return { type: 'info' as const, label: status };
  }
};
```

**Visual Design Principles**:
- **Semantic Color Coding**: Green for active, blue for completed, yellow for cancelled, red for errors
- **Contextual Icons**: Plug for charging, CheckCircle for completed, Clock for pending, AlertTriangle for faults
- **Consistent Badge Design**: Rounded full badges with icon and text
- **Accessible Contrast**: Text and background color combinations meet WCAG standards

#### 🔔 Real-Time Active Session Alerts

**Alert Trigger Logic**:
```tsx
{totalStats.activeSessions > 0 && (
  <Card variant="filled" className="border-l-4 border-brand">
    <CardContent className="p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="h-3 w-3 rounded-full bg-brand animate-pulse"></div>
          <div>
            <p className="font-medium text-ink">Активные сессии: {totalStats.activeSessions}</p>
            <p className="text-sm text-muted">Внимание! Идет зарядка в реальном времени</p>
          </div>
        </div>
      </div>
    </CardContent>
  </Card>
)}
```

**Visual Alert Features**:
- **Pulsing Dot**: Animated brand-colored circle for immediate attention
- **Left Border**: 4px brand-colored border for visual prominence
- **Clear Messaging**: Concise text describing the real-time charging situation
- **Contextual Placement**: Appears below the main table for logical flow

#### 📱 Responsive Design Implementation

**Statistical Grid Responsiveness**:
```tsx
<div className={`grid gap-6 ${mode === 'commercial' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'}`}>
```

**Table Column Management**:
- **Mobile**: Horizontal scrolling enabled via `overflow-x-auto`
- **Desktop**: Full table visibility with optimized column widths
- **Progressive Enhancement**: Detail card grid adjusts from 1 to 4 columns based on screen size

**Typography Scaling**:
- **Header**: `text-2xl` for page title, `text-muted` for description
- **Statistics**: `text-3xl` for values, `text-sm` for labels
- **Table**: `text-sm` for headers, appropriate sizing for data cells

#### 🔄 User Interaction Patterns

**Expand/Collapse Behavior**:
- **Single Expansion**: Only one session can be expanded at a time
- **Visual Feedback**: Chevron rotation (down → up) indicates state change
- **Smooth Transition**: Instant expansion without animation for simplicity

**Filter Interaction**:
- **Immediate Application**: Filter changes update displayed sessions instantly
- **Visual Selection**: Active filter prominently highlighted
- **Hover States**: Interactive feedback for all filter buttons

**Data Navigation**:
- **Table Scrolling**: Horizontal scroll for mobile users
- **Session Details**: Expandable rows prevent information overload
- **Progressive Disclosure**: Basic info in main row, details in expansion

#### 📈 Data Visualization and Calculation

**Energy Consumption Display**:
- **Icon Integration**: Zap icon with warning color for energy values
- **Precision Formatting**: One decimal place for kWh values
- **Unit Consistency**: Always "кВт·ч" for Russian users

**Cost Calculation and Display**:
- **Commercial Mode**: Cost column with DollarSign icon and brand color
- **Personal Mode**: Cost data hidden for privacy
- **Currency Formatting**: Russian ruble symbol (₽) with proper number formatting

**Average Speed Calculation**:
```typescript
{(session.energy / (parseInt(session.duration) / 60)).toFixed(1)} кВт
```
- **Real-time Calculation**: Computed from energy and duration
- **Unit Conversion**: Duration in minutes converted to hours
- **Precision Control**: One decimal place for readability

#### 🛡️ Error Handling and Edge Cases

**Null End Time Handling**:
- **Active Sessions**: Display "до {endTime}" only when `endTime` exists
- **Visual Distinction**: Active sessions show null end time naturally

**Empty State Management**:
- **Table Display**: Shows "Показано 0 сессий" when no sessions match filters
- **Statistics Update**: All stats update to zero for empty filtered sets
- **Alert Suppression**: Active sessions alert hidden when `activeSessions === 0`

**Invalid Status Handling**:
- **Default Fallback**: Unknown status types default to 'info' type with original label
- **Graceful Degradation**: UI remains functional with any status string

This sessions management implementation provides a robust platform for monitoring charging activity with careful attention to user experience across different modes and devices. The expandable table design balances information density with accessibility, while the real-time statistics and alerts keep users informed of current charging operations.

### 4. Tariffs.tsx - Tariff Management: Advanced Pricing Rule System

**Purpose**: The Tariffs page provides sophisticated pricing rule management for commercial operators, enabling the creation and maintenance of complex tariff structures with time-based pricing, session limits, and visual rule validation. This component exemplifies advanced form handling, data visualization, and state management within the CHARGE_admin application.

**Architectural Foundation**:
- **Context-Driven State**: Uses `TariffContext` for centralized tariff management with localStorage persistence
- **Modal Form Architecture**: Complex multi-step forms in modal dialogs with real-time validation
- **Visual Data Representation**: `TariffRuleVisualizer` component for intuitive rule visualization
- **Robust Validation**: Comprehensive validation system for rule overlaps, time ranges, and data integrity

#### 🏗️ Component Architecture and Data Flow

**Hierarchical Component Structure**:
```
Tariffs.tsx (Main Page)
├── Header Section
│   ├── Title: "Тарифы" (Tariffs)
│   ├── Subtitle: "Управление тарифными планами и ценообразованием"
│   └── "New Tariff" Button (opens modal)
├── Tariffs Grid (2-column on desktop)
│   ├── Tariff Cards (one per tariff)
│   │   ├── Tariff Header (name, description, action buttons)
│   │   ├── Base Price Display
│   │   ├── Session Limits Panel
│   │   └── TariffRuleVisualizer (conditional)
│   └── Empty State (when no tariffs exist)
└── TariffModal (Conditionally Rendered)
    ├── Form Sections:
    │   ├── Basic Information (name, description, base price)
    │   ├── Rules Management (time-based pricing rules)
    │   └── Session Limits (maximum time/energy constraints)
    └── Validation & Error Display
```

**Data Flow Architecture**:
```typescript
// Context State Management Flow
1. Component Mount → TariffContext loads tariffs from localStorage
2. localStorage Check → Load existing data or fall back to mock tariffs
3. State Initialization → Tariffs displayed in responsive grid
4. User Interaction → Context methods update state → localStorage persists

// CRUD Operations Flow
Create: User clicks "New Tariff" → opens empty modal → submits form → 
        context.addTariff() → state update → localStorage persistence
Edit: User clicks pencil icon → modal opens with tariff data → submits form → 
      context.updateTariff() → state update → localStorage persistence
Copy: User clicks copy icon → context.addTariff() with modified name → 
      state update → localStorage persistence
Delete: User clicks trash icon → context.deleteTariff() → 
        state update → localStorage persistence → toast notification
```

#### 📊 Tariff Data Structure and Types

**Core Type Definitions**:
```typescript
// tariff.ts - Comprehensive type system
export interface TariffRule {
  id: string;                    // Unique identifier (generated)
  days: number[] | 'all';        // 0-6 (Monday-Sunday) or 'all' for all days
  startTime: string;             // "HH:MM" format (hours only: "08:00")
  endTime: string;               // "HH:MM" format (hours only: "17:00")
  pricePerKwh: number;          // Price per kWh during this rule
}

export interface SessionLimits {
  maxTime: number;              // 0 = no limit (minutes)
  maxEnergy: number;            // 0 = no limit (kWh)
}

export interface Tariff {
  name: string;                 // Unique identifier
  description: string;          // User-friendly description
  basePricePerKwh: number;      // Default price when no rules apply
  rules: TariffRule[];          // Time-based pricing rules
  sessionLimits: SessionLimits; // Usage constraints
  createdAt: string;            // ISO date string (YYYY-MM-DD)
  updatedAt?: string;           // ISO date string (YYYY-MM-DD)
  isActive?: boolean;          // Active status flag
}

export interface TariffFormData {
  name: string;
  description: string;
  basePricePerKwh: number;
  rules: TariffRule[];
  sessionLimits: SessionLimits;
}

// Day mapping for UI display (Monday=0, Sunday=6)
export const WEEK_DAYS = [
  { id: 0, label: 'Пн', fullLabel: 'Понедельник' },
  { id: 1, label: 'Вт', fullLabel: 'Вторник' },
  { id: 2, label: 'Ср', fullLabel: 'Среда' },
  { id: 3, label: 'Чт', fullLabel: 'Четверг' },
  { id: 4, label: 'Пт', fullLabel: 'Пятница' },
  { id: 5, label: 'Сб', fullLabel: 'Суббота' },
  { id: 6, label: 'Вс', fullLabel: 'Воскресенье' },
];
```

**Tariff Creation Flow**:
```typescript
// Example of complete tariff object
const exampleTariff: Tariff = {
  name: "Премиум день",
  description: "Высокая стоимость в часы пик",
  basePricePerKwh: 35,
  rules: [
    {
      id: "rule_1744396800000_abc123",
      days: [0, 1, 2, 3, 4], // Monday-Friday
      startTime: "08:00",
      endTime: "20:00",
      pricePerKwh: 50
    },
    {
      id: "rule_1744396800001_def456",
      days: [5, 6], // Saturday-Sunday
      startTime: "09:00",
      endTime: "18:00",
      pricePerKwh: 45
    }
  ],
  sessionLimits: {
    maxTime: 240,    // 4 hours maximum
    maxEnergy: 100   // 100 kWh maximum
  },
  createdAt: "2025-01-09",
  updatedAt: "2025-01-09",
  isActive: true
};
```

#### 💾 TariffContext: Centralized State Management

**Context Implementation**:
```typescript
// TariffContext.tsx - Comprehensive state management
interface TariffContextType {
  tariffs: Tariff[];
  defaultBasePrice: number;
  addTariff: (tariffData: TariffFormData) => void;
  updateTariff: (oldName: string, tariffData: TariffFormData) => void;
  deleteTariff: (name: string) => void;
  setDefaultBasePrice: (price: number) => void;
  getTariffByName: (name: string) => Tariff | undefined;
}

// Storage Configuration
const STORAGE_KEY = 'charge_admin_tariffs';
const DEFAULT_PRICE_KEY = 'charge_admin_default_price';

// State Initialization with localStorage fallback
const [tariffs, setTariffs] = useState<Tariff[]>(() => {
  const savedTariffs = localStorage.getItem(STORAGE_KEY);
  if (savedTariffs) {
    try {
      const parsedTariffs = JSON.parse(savedTariffs);
      return Array.isArray(parsedTariffs) && parsedTariffs.length > 0 
        ? parsedTariffs 
        : mockTariffs;
    } catch (error) {
      return mockTariffs; // Fallback on parsing error
    }
  }
  return mockTariffs; // Initial load with mock data
});
```

**Key Context Methods**:
```typescript
// Add new tariff with timestamp
const addTariff = (tariffData: TariffFormData) => {
  const now = new Date().toISOString().split('T')[0];
  const newTariff: Tariff = {
    ...tariffData,
    createdAt: now,
    updatedAt: now,
    isActive: true,
  };
  setTariffs(prev => [...prev, newTariff]);
};

// Update existing tariff
const updateTariff = (oldName: string, tariffData: TariffFormData) => {
  const now = new Date().toISOString().split('T')[0];
  setTariffs(prev => prev.map(tariff => 
    tariff.name === oldName 
      ? { 
          ...tariffData, 
          createdAt: tariff.createdAt,
          updatedAt: now,
          isActive: tariff.isActive !== undefined ? tariff.isActive : true,
        }
      : tariff
  ));
};

// Delete tariff (immediate, no confirmation in context)
const deleteTariff = (name: string) => {
  setTariffs(prev => prev.filter(tariff => tariff.name !== name));
};
```

**Storage Behavior**:
- **Dual Storage**: Separate keys for tariffs (`charge_admin_tariffs`) and default price (`charge_admin_default_price`)
- **Mock Data Fallback**: Uses `mockTariffs` from `mock-tariffs.ts` when localStorage is empty or corrupt
- **Automatic Persistence**: All state changes automatically sync to localStorage via `useEffect` hooks
- **One-time Initialization**: Ensures mock data is loaded only when absolutely necessary

#### 🎨 User Interface and Interaction Patterns

**Tariff Card Design**:
```tsx
// Tariff Card Structure in 2-column grid
<div key={tariff.name} className="bg-bg2 border border-gray-200 rounded-lg p-4 shadow-sm">
  {/* Header with action buttons */}
  <div className="flex items-start justify-between mb-4">
    <div className="flex-1">
      <h3 className="text-lg font-semibold text-ink">{tariff.name}</h3>
      <p className="text-sm text-muted mt-1">{tariff.description}</p>
    </div>
    <div className="flex items-center space-x-2">
      <Button variant="icon" size="sm" onClick={() => handleEditTariff(tariff)}>
        <Edit size={16} /> {/* Edit - opens modal with tariff data */}
      </Button>
      <Button variant="icon" size="sm" onClick={() => handleCopyTariff(tariff)}>
        <Copy size={16} /> {/* Copy - creates duplicate with "(копия)" suffix */}
      </Button>
      <Button variant="icon" size="sm" onClick={() => handleDeleteTariff(tariff.name)}>
        <Trash2 size={16} /> {/* Delete - immediate with toast confirmation */}
      </Button>
    </div>
  </div>

  {/* Base Price Display */}
  <div className="flex gap-4 mb-4">
    <div className="flex items-center space-x-2 text-sm border-2 rounded-md px-2 py-1 shadow-sm"
      style={{ borderColor: '#0ea5e9' }}>
      <div className="w-[1em] h-[1em] rounded-sm flex items-center justify-center"
        style={{ backgroundColor: '#0ea5e9' }}>
        <Zap size={10} className="text-white" />
      </div>
      <span className="text-ink">{tariff.basePricePerKwh}₽/кВч</span>
    </div>
  </div>

  {/* Session Limits Panel */}
  <div className="bg-bg-2 rounded-lg p-3 mb-4">
    <div className="grid grid-cols-2 gap-4 text-sm">
      <div>
        <span className="text-muted">Макс. время: </span>
        <span className="font-medium text-ink">
          {tariff.sessionLimits.maxTime > 0 ? `${tariff.sessionLimits.maxTime} мин` : 'Нет'}
        </span>
      </div>
      <div>
        <span className="text-muted">Макс. энергия: </span>
        <span className="font-medium text-ink">
          {tariff.sessionLimits.maxEnergy > 0 ? `${tariff.sessionLimits.maxEnergy} кВт·ч` : 'Нет'}
        </span>
      </div>
    </div>
  </div>

  {/* Rule Visualization (conditional) */}
  {tariff.rules.length > 0 && (
    <TariffRuleVisualizer
      rules={tariff.rules}
      basePricePerKwh={tariff.basePricePerKwh}
    />
  )}
</div>
```

**User Interaction Patterns**:
1. **Create Operation**: "New Tariff" button opens empty modal form
2. **Edit Operation**: Pencil icon opens modal pre-filled with tariff data
3. **Copy Operation**: Copy icon duplicates tariff with "(копия)" suffix in name
4. **Delete Operation**: Trash icon triggers immediate deletion with toast notification
5. **No Confirmation Dialogs**: Delete operations are immediate for streamlined workflow
6. **Toast Feedback**: All CRUD operations provide immediate visual feedback via toast notifications

#### 🔧 TariffModal: Complex Form Management

**Modal Architecture**:
- **React Portal**: Renders modal at document.body level for proper z-index management
- **Backdrop Click**: Clicking outside the modal content triggers `onClose`
- **Escape Key**: Pressing Escape key closes the modal
- **Responsive Design**: Adapts layout for mobile/desktop with grid systems

**Form State Management**:
```typescript
// Form state with comprehensive validation
const [formData, setFormData] = useState<TariffFormData>({
  name: '',
  description: '',
  basePricePerKwh: 25,
  rules: [],
  sessionLimits: { maxTime: 0, maxEnergy: 0 },
});

// Error state management
const [errors, setErrors] = useState<Record<string, string>>({});
const [ruleErrors, setRuleErrors] = useState<Record<string, string>>({});

// Rule management functions
const addRule = () => {
  setFormData(prev => {
    const newRule: TariffRule = {
      id: generateRuleId(),
      days: 'all',
      startTime: '08:00',
      endTime: '17:00',
      pricePerKwh: prev.basePricePerKwh,
    };
    return { ...prev, rules: [...prev.rules, newRule] };
  });
};

const updateRule = (index: number, field: keyof TariffRule, value: any) => {
  // Complex update logic with time normalization
  if (field === 'startTime' || field === 'endTime') {
    const normalized = normalizeTimeRange(
      field === 'startTime' ? value : rule.startTime,
      field === 'endTime' ? value : rule.endTime
    );
    // Apply normalized times with visual feedback if swapped
  }
};

const deleteRule = (index: number) => {
  setFormData(prev => ({
    ...prev,
    rules: prev.rules.filter((_, i) => i !== index)
  }));
};
```

**Validation System**:
```typescript
const handleSubmit = (e: React.FormEvent) => {
  e.preventDefault();
  const newErrors: Record<string, string> = {};

  // Name validation
  if (!formData.name.trim()) {
    newErrors.name = 'Название обязательно';
  } else if (initialData?.name !== formData.name && existingNames.includes(formData.name)) {
    newErrors.name = 'Тариф с таким названием уже существует';
  }

  // Description validation
  if (!formData.description.trim()) {
    newErrors.description = 'Описание обязательно';
  }

  // Base price validation
  if (formData.basePricePerKwh < 0) {
    newErrors.basePricePerKwh = 'Стоимость не может быть отрицательной';
  }

  // Rule-specific validation
  const newRuleErrors: Record<string, string> = {};
  formData.rules.forEach((rule, index) => {
    if (rule.days.length === 0) {
      newRuleErrors[`rule_${index}_days`] = 'Выберите хотя бы один день';
    }
    if (!validateTimeRange(rule.startTime, rule.endTime)) {
      newRuleErrors[`rule_${index}_time`] = 'Время начала должно быть раньше времени окончания';
    }
    if (rule.pricePerKwh < 0) {
      newRuleErrors[`rule_${index}_price`] = 'Стоимость не может быть отрицательной';
    }
  });

  // Rule overlap detection
  const overlappingRules: number[] = [];
  formData.rules.forEach((rule1, i) => {
    formData.rules.forEach((rule2, j) => {
      if (i !== j && checkRuleOverlap(rule1, rule2)) {
        overlappingRules.push(i, j);
      }
    });
  });

  if (overlappingRules.length > 0) {
    newErrors.rules = 'Обнаружены пересекающиеся правила';
  }

  setErrors(newErrors);
  setRuleErrors(newRuleErrors);

  if (Object.keys(newErrors).length === 0 && Object.keys(newRuleErrors).length === 0) {
    onSubmit(formData);
    onClose();
  }
};
```

**Rule Management Interface**:
- **Days Selection**: Checkbox for "all days" or individual day selection with visual feedback
- **Time Range**: Hourly selection (08:00-17:00 format) with automatic normalization
- **Price Input**: Numeric input with validation for negative values
- **Rule Preview**: Real-time text description of each rule's effect
- **Visual Feedback**: Time swap notifications when start/end times are automatically corrected

#### 📈 TariffRuleVisualizer: Visual Rule Representation

**Visualization Architecture**:
```typescript
// Color system for rule visualization
const RULE_COLORS = [
  '#1f77b4', // blue
  '#ff7f0e', // orange
  '#2ca02c', // green
  '#d62728', // red
  '#9467bd', // purple
  '#8c564b', // brown
  '#e377c2', // pink
  '#7f7f7f', // gray
  '#bcbd22', // olive
  '#17becf', // cyan
];

const BASE_COLOR = '#0ea5e9';    // Base tariff color (sky-500)
const OVERLAP_COLOR = '#FF0000'; // Pure red for rule overlaps

// Grid data transformation
const { gridData } = useMemo(() => {
  // 7x24 grid (days x hours)
  const grid: Array<Array<{
    ruleId: string | null;
    rulePrice: number | null;
    color: string;
    hasOverlap: boolean;
  }>> = [];

  // Initialize with base tariff color
  for (let day = 0; day < 7; day++) {
    const row = Array(24).fill({
      ruleId: null,
      rulePrice: null,
      color: BASE_COLOR,
      hasOverlap: false,
    });
    grid.push(row);
  }

  // Apply rules to grid with overlap detection
  const overlapCells = new Set<string>();
  rules.forEach((rule) => {
    // Parse and validate time ranges
    // Apply rule to applicable days and hours
    // Detect and mark overlaps
  });

  return { gridData: grid };
}, [rules]);
```

**Visual Features**:
- **7x24 Grid**: Days of week (rows) vs hours (columns) visualization
- **Color Coding**: Each rule gets distinct color; base price shown in sky blue
- **Overlap Detection**: Conflicting rules highlighted in bright red with warning icon
- **Hover Tooltips**: Display price information on hover (base price or rule price) - desktop only
- **Mobile Tooltips**: Tap-activated tooltips with dark background, white bold text, auto-dismiss after 1 second
- **Legend System**: Color-coded price labels for each rule
- **Responsive Design**: Horizontal scrolling for small screens with fixed day labels

**User Experience**:
- **Immediate Feedback**: Rule creation/modification instantly updates visualization
- **Conflict Visibility**: Overlaps are immediately visible and identifiable
- **Intuitive Understanding**: Color-coded grid makes complex rules easily comprehensible
- **Interactive Exploration**: Hover tooltips (desktop) and tap tooltips (mobile) provide detailed pricing information
- **Mobile Optimization**: Touch detection ensures mobile tooltips only appear on touch devices, desktop uses hover only
- **Scrolling Support**: Tooltip position updates automatically when scrolling, maintaining correct position above tapped cell

#### 🛡️ Validation and Error Handling

**Time Range Validation**:
```typescript
export const validateTimeRange = (startTime: string, endTime: string): boolean => {
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startTotal = startHours * 60 + startMinutes;
  const endTotal = endHours * 60 + endMinutes;
  
  return startTotal < endTotal;
};

export const normalizeTimeRange = (
  startTime: string, 
  endTime: string
): { startTime: string; endTime: string; wasSwapped: boolean } => {
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startTotal = startHours * 60 + startMinutes;
  const endTotal = endHours * 60 + endMinutes;
  
  // Automatically swap if start > end
  if (startTotal > endTotal) {
    return { startTime: endTime, endTime: startTime, wasSwapped: true };
  }
  
  return { startTime, endTime, wasSwapped: false };
};
```

**Rule Overlap Detection**:
```typescript
export const checkRuleOverlap = (
  rule1: TariffRule,
  rule2: TariffRule
): boolean => {
  // Check day overlap
  const days1 = rule1.days === 'all' ? [0, 1, 2, 3, 4, 5, 6] : rule1.days;
  const days2 = rule2.days === 'all' ? [0, 1, 2, 3, 4, 5, 6] : rule2.days;
  
  const hasDayOverlap = days1.some(day => days2.includes(day));
  if (!hasDayOverlap) return false;
  
  // Check time overlap
  const [start1Hours, start1Minutes] = rule1.startTime.split(':').map(Number);
  const [end1Hours, end1Minutes] = rule1.endTime.split(':').map(Number);
  const [start2Hours, start2Minutes] = rule2.startTime.split(':').map(Number);
  const [end2Hours, end2Minutes] = rule2.endTime.split(':').map(Number);
  
  const start1 = start1Hours * 60 + start1Minutes;
  const end1 = end1Hours * 60 + end1Minutes;
  const start2 = start2Hours * 60 + start2Minutes;
  const end2 = end2Hours * 60 + end2Minutes;
  
  return !(end1 <= start2 || end2 <= start1);
};
```

**Error Display System**:
- **Inline Validation**: Errors displayed below relevant form fields
- **Rule-specific Errors**: Individual rule validation with field highlighting
- **Time Swap Notifications**: Visual feedback when time ranges are automatically corrected
- **Overlap Warnings**: Clear indication of rule conflicts in both form and visualization

#### 🔄 Integration with Application Context

**Protected Route Integration**:
- **Commercial Mode Only**: Tariffs page only accessible in commercial mode via `ProtectedRoute`
- **Context Dependency**: Relies on `TariffContext` for all data operations
- **Toast Integration**: Uses `useToast` hook for user feedback on all operations
- **LocalStorage Persistence**: All tariff data persists across browser sessions

**Performance Considerations**:
- **Memoized Visualizations**: `TariffRuleVisualizer` uses `useMemo` for expensive grid calculations
- **Optimized Re-renders**: Context updates only trigger necessary component re-renders
- **Efficient Grid Updates**: Rule changes only recalculate affected grid cells
- **Lazy Initialization**: Mock data only loaded when absolutely necessary

This tariff management system represents one of the most complex components in the CHARGE_admin application, combining sophisticated form handling, real-time validation, and advanced data visualization to provide commercial operators with powerful pricing rule management capabilities.

### 5. Layout Components: Adaptive Navigation System

**Purpose**: The layout components form the structural foundation of the CHARGE_admin application, providing a seamless, mode-aware navigation experience across desktop and mobile devices. This system exemplifies the application's commitment to responsive design and user-centric accessibility.

**Architectural Foundation**:
- **Media Query Detection**: Uses `useMediaQuery` hook for breakpoint-based layout switching
- **Mode-Aware Navigation**: Dynamically filters navigation items based on current mode (personal/commercial)
- **Dual Layout Strategy**: Separate desktop and mobile layouts optimized for each form factor
- **Context Integration**: Leverages `ModeContext` and `UserContext` for personalized navigation

#### 📱 ResponsiveLayout.tsx: The Layout Dispatcher

**Implementation**:
```tsx
import React from 'react';
import { useMediaQuery } from '../../hooks/useMediaQuery';
import { DesktopLayout } from './DesktopLayout';
import { MobileLayout } from './MobileLayout';

export const ResponsiveLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  if (isDesktop) {
    return <DesktopLayout>{children}</DesktopLayout>;
  }

  return <MobileLayout>{children}</MobileLayout>;
};
```

**Key Design Decisions**:
- **Breakpoint**: 1024px (standard desktop threshold)
- **Conditional Rendering**: Simple if-else for clarity and performance
- **Component Composition**: Passes children through to selected layout
- **Hook Abstraction**: Encapsulates media query logic for testability

#### 🖥️ DesktopLayout.tsx: Sidebar Navigation for Productivity

**Visual Layout**:
1. **Sidebar (Left)**: Fixed-width navigation panel with logo, filtered navigation, and user info
2. **Main Content (Right)**: Flexible content area with header and connection status
3. **Header**: Secondary navigation with page title and user actions
4. **Connection Status**: Persistent system status indicator at bottom

**Navigation Filtering Logic**:
```tsx
// Filter navigation items based on mode
const filteredNavigationItems = navigationItems.filter(item => {
  if (mode === 'personal') {
    // Hide Tariffs and Finance in personal mode
    return item.name !== 'Тарифы' && item.name !== 'Финансы';
  }
  return true;
});
```

**User Information Display**:
- **Sidebar**: Compact user card with name and mode indicator
- **Header**: Redundant user info for quick access
- **Visual Consistency**: Same avatar and information in both locations

**Component Structure**:
- **Fixed Sidebar**: `w-64 xl:w-72` (responsive width with XL breakpoint)
- **Sticky Header**: `sticky top-0` for content scrolling
- **Flexible Main**: `flex-1` for remaining space

#### 📲 MobileLayout.tsx: Thumb-Friendly Bottom Navigation

**Visual Layout**:
1. **Header**: Compact header with menu button, logo, and user icon
2. **Main Content**: Full-width content area with bottom padding for navigation
3. **Bottom Navigation**: Fixed-position tab bar with primary navigation items
4. **Drawer Menu**: Slide-out panel for full navigation (including filtered items)

**Touch Optimization**:
- **Bottom Tabs**: Positioned within thumb reach (iOS/Android patterns)
- **Icon + Text**: Clear labeling for each navigation item
- **Active States**: Brand color indication for current page
- **Drawer Access**: Hamburger menu for secondary options

**Drawer Implementation**:
- **Overlay Pattern**: Semi-transparent backdrop with slide-in panel
- **Escape Handling**: Click outside or X button to close
- **Smooth Animation**: CSS transitions for drawer opening/closing
- **Complete Navigation**: Shows all filtered items in vertical list

**Connection Status**: Same persistent indicator as desktop, positioned above bottom navigation

#### 🔧 useMediaQuery.ts: Responsive Foundation Hook

**Implementation**:
```tsx
import { useState, useEffect } from 'react';

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const media = window.matchMedia(query);
    
    if (media.matches !== matches) {
      setMatches(media.matches);
    }

    const listener = (event: MediaQueryListEvent) => {
      setMatches(event.matches);
    };

    media.addEventListener('change', listener);
    
    return () => {
      media.removeEventListener('change', listener);
    };
  }, [query, matches]);

  return matches;
}
```

**Key Features**:
- **Event-Driven**: Listens to media query changes (window resize, orientation)
- **Cleanup**: Proper event listener removal on unmount
- **State Synchronization**: Initial check and updates kept in sync
- **Generic Design**: Reusable for any media query

#### 🎨 Navigation Item Configuration

**Desktop Navigation Items**:
```tsx
const navigationItems = [
  { name: 'Главная', icon: Home, path: '/' },
  { name: 'Станции', icon: Battery, path: '/stations' },
  { name: 'Сессии', icon: Clock, path: '/sessions' },
  { name: 'Тарифы', icon: CreditCard, path: '/tariffs' },
  { name: 'Финансы', icon: DollarSign, path: '/finance' },
  { name: 'Профиль', icon: User, path: '/profile' },
];
```

**Mobile Navigation**: Uses same configuration with filtered display
- **Bottom Tabs**: Primary filtered items (max 5 for thumb accessibility)
- **Drawer**: Complete filtered list for secondary access

#### 🔄 User Experience Patterns

**Mode Switching Behavior**:
- **Immediate Filtering**: Navigation updates instantly when mode changes
- **Visual Feedback**: User info shows current mode (personal/commercial)
- **Access Control**: Protected routes handle unauthorized access attempts

**Responsive Transitions**:
- **Seamless Switching**: Layout changes without page reload
- **State Preservation**: Component state maintained across layout changes
- **Performance**: No unnecessary re-renders, efficient media query handling

**Accessibility Features**:
- **Keyboard Navigation**: Full tab navigation in desktop layout
- **Touch Targets**: Minimum 44px touch targets in mobile layout
- **Screen Reader Support**: ARIA labels and semantic HTML structure
- **Color Contrast**: Meets WCAG standards in both layouts

#### 🛡️ Error Handling and Edge Cases

**Empty Navigation States**:
- **No Items**: Graceful handling when all items are filtered
- **Fallback Behavior**: Default to dashboard if current page becomes inaccessible

**Window Resize Handling**:
- **Debounced Updates**: Media query listener handles rapid resizing
- **Layout Stability**: No flash of incorrect layout during transitions

**User Context Integration**:
- **Fallback Data**: Default user data if context not loaded
- **Loading States**: Skeleton screens during async operations

This layout system provides a robust foundation for the CHARGE_admin application, ensuring optimal user experience across devices while maintaining clean separation of concerns and efficient performance characteristics.

## Component Library Documentation

### Core UI Components

#### Button.tsx
**Purpose**: Reusable button component with multiple variants
**Variants**: `primary`, `secondary`, `danger`, `ghost`, `icon`
**Sizes**: `sm`, `md`, `lg`, `icon`
**Features**:
- Loading state with spinner
- Icon positioning (left/right)
- Micro-animations (scale on active)
- Focus states for accessibility
**Usage Example**:
```tsx
<Button variant="primary" icon={Plus} onClick={handleClick}>
  Add Item
</Button>
```

#### Card.tsx
**Purpose**: Container component for content grouping
**Variants**: `default`, `filled`
**Structure**: Header, Content, Footer sections
**Usage**: Wrapper for dashboard metrics, tables, forms

#### StatusBadge.tsx
**Purpose**: Visual status indicators
**Status Types**: `success`, `warning`, `error`, `info`, `neutral`
**Customization**: Custom labels and colors
**Usage**: Session status, connection status, operation states

#### MetricCard.tsx
**Purpose**: KPI/metric display with icons and change indicators
**Features**: Icon, label, value, optional change indicator
**Usage**: Dashboard statistics, quick overview cards

### Feature Components

#### Station Components
- **StationForm.tsx**: Comprehensive form for station data entry
- **StationModal.tsx**: Modal wrapper for station forms
- **StationsTable.tsx**: Table display with edit/delete actions
- **StationCard.tsx**: Card-based display for personal mode

#### Tariff Components
- **TariffForm.tsx**: Complex form with time-based rule management
- **TariffRuleVisualizer.tsx**: Graphical representation of pricing rules
- **TariffModal.tsx**: Modal wrapper for tariff forms

### Layout Components
**Responsive Design**: Media query hooks for adaptive layouts
**Navigation**: Mode-aware filtering and user context display

## User Interaction Patterns

### Navigation Flow
```
Desktop: Sidebar navigation → Page content
Mobile: Bottom navigation → Page content
Mode Switching: Affects available navigation items
```

### Form Interactions
1. **Modal Forms**: Station creation/editing uses modal dialogs
2. **Inline Forms**: Tariff management uses collapsible inline forms
3. **Validation**: Client-side validation with error display
4. **Submission**: Context-based state updates with localStorage persistence

### Table Operations
1. **Sorting**: Default sorting by name (Stations)
2. **Filtering**: Time-based filtering (Sessions)
3. **Expansion**: Row expansion for detailed views (Sessions)
4. **Actions**: Edit/Delete per row with confirmation

### State Management Patterns
1. **Context Providers**: Global state with localStorage persistence
2. **Custom Hooks**: `usePersistentData` for localStorage integration
3. **Event Handling**: Console logging for placeholder actions
4. **Toast Notifications**: Success/error feedback for user actions

## Data Flow & State Management

### Context Architecture
```mermaid
graph TB
    ModeContext[ModeContext] --> Dashboard
    ModeContext --> Stations
    ModeContext --> Sessions
    ModeContext --> Tariffs
    ModeContext --> Finance
    ModeContext --> Profile
    
    UserContext[UserContext] --> Profile
    UserContext --> Layouts
    
    TariffContext[TariffContext] --> Tariffs
    TariffContext --> Stations
    
    FinanceContext[FinanceContext] --> Finance
    
    Dashboard --> MockData[Mock Data]
    Stations --> LocalStorage[LocalStorage]
    Tariffs --> LocalStorage
    Finance --> LocalStorage
    Profile --> LocalStorage
```

### Persistence Strategy
- **LocalStorage Keys**: Namespaced with `'charge_admin_'` prefix
- **Fallback Data**: Mock data when localStorage is empty
- **Data Normalization**: Validation and correction on load
- **Real-time Updates**: Context listeners for immediate UI updates

### Event Propagation
1. User action triggers component event handler
2. Handler updates context state
3. Context persists to localStorage
4. Components re-render with updated data
5. Toast notifications provide user feedback

## Code Snapshots

### 1. Dashboard.tsx (Key Sections)

```tsx
import React from 'react';
import { Card, CardHeader, CardContent, CardFooter } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StatusBadge, StationStatusBadge } from '../components/ui/StatusBadge';
import { MetricCard } from '../components/ui/MetricCard';
import { EnergyChart } from '../components/ui/EnergyChart';
import { useMode } from '../contexts/ModeContext';
import { Battery, Zap, Clock, DollarSign, Plus, Play, StopCircle } from 'lucide-react';

// Import mock data from /data folder
import { mockStations } from '../data/dashboard-stations';
import { mockEnergyData } from '../data/energy';

export const Dashboard: React.FC = () => {
  const { mode } = useMode();

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full">
      {/* Header with mode-specific title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-ink">Панель управления</h2>
          <p className="text-muted">
            {mode === 'commercial' 
              ? 'Обзор ваших зарядных станций и активности' 
              : 'Мои зарядные станции'}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {mode === 'commercial' && (
            <Button icon={Plus}>Добавить станцию</Button>
          )}
        </div>
      </div>

      {mode === 'commercial' ? (
        <>
          {/* Commercial mode: 4 KPI cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MetricCard
              icon={<Battery className="h-5 w-5" />}
              label="Активные станции"
              value="8"
              change="+2"
            />
            {/* ... more metric cards */}
          </div>
          
          {/* Stations table with action buttons */}
          <table className="min-w-full text-sm divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-muted uppercase tracking-wider">Статус</th>
                <th className="px-4 py-3 text-left font-medium text-muted uppercase tracking-wider">Device ID / Имя</th>
                {/* ... more headers */}
              </tr>
            </thead>
            <tbody className="bg-bg2 divide-y divide-gray-200">
              {mockStations.map((station) => (
                <tr key={station.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <StationStatusBadge status={station.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-ink">{station.name}</p>
                      <p className="text-sm text-muted font-mono">{station.id}</p>
                    </div>
                  </td>
                  {/* ... more cells */}
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-2">
                      {station.status === 'charging' ? (
                        <Button 
                          variant="secondary" 
                          size="sm" 
                          icon={StopCircle}
                          onClick={() => console.log('Остановить станцию', station.id)}
                        >
                          Остановить
                        </Button>
                      ) : (
                        <Button 
                          variant="primary" 
                          size="sm" 
                          icon={Play}
                          onClick={() => console.log('Запустить станцию', station.id)}
                        >
                          Запустить
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      ) : (
        <>
          {/* Personal mode: Station cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {mockStations.slice(0, 3).map((station) => (
              <Card key={station.id} variant="filled" className="bg-bg2 border border-gray-200 rounded-lg p-4 shadow-sm">
                <CardContent className="p-0">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <StationStatusBadge status={station.status} />
                        <div>
                          <p className="font-medium text-ink">{station.name}</p>
                          <p className="text-sm text-muted font-mono">{station.id}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted">Мощность:</span>
                        <span className="font-medium text-ink">{station.power} кВт</span>
                      </div>
                      {/* ... more station details */}
                    </div>
                    
                    <div className="flex space-x-2 pt-2">
                      <Button variant="primary" size="sm" icon={Play} className="flex-1">
                        Запустить
                      </Button>
                      <Button variant="secondary" size="sm" icon={StopCircle} className="flex-1">
                        Остановить
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
```

### 2. Stations.tsx (Core Logic)

```tsx
import React, { useState } from 'react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StationModal } from '../components/station/StationModal';
import { StationsTable } from '../components/station/StationsTable';
import { Battery, Plus } from 'lucide-react';

import type { Station } from '../data/stations';
import { defaultStations } from '../data';
import { usePersistentData } from '../hooks/usePersistentData';
import { useMode } from '../contexts/ModeContext';
import { useTariff } from '../contexts/TariffContext';

// Data normalization function
const normalizeStations = (stations: Station[]): Station[] => {
  return stations.map(station => {
    const normalizedStation = {
      ...station,
      // Power must be 7, 11, or 22 kW
      power: [7, 11, 22].includes(station.power) ? station.power : 11,
      // Ports can only be 1 or 2
      ports: station.ports === 1 || station.ports === 2 ? station.ports : 2,
    };
    // Add tariffName if missing
    if (!normalizedStation.tariffName) {
      normalizedStation.tariffName = 'Базовый';
    }
    return normalizedStation;
  });
};

export const Stations: React.FC = () => {
  // Persistent data hook with localStorage
  const [stations, setStations] = usePersistentData<Station[]>(
    'stations',
    normalizeStations(defaultStations as Station[])
  );
  
  // Modal state management
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStation, setEditingStation] = useState<Station | null>(null);
  
  const { mode: appMode } = useMode();

  // Sort stations by name
  const sortedStations = [...stations].sort((a, b) => a.name.localeCompare(b.name));

  // Modal handlers
  const handleOpenModal = (station?: Station) => {
    setEditingStation(station || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingStation(null);
  };

  const handleSaveStation = (stationData: Station) => {
    if (editingStation) {
      // Edit existing station
      setStations(stations.map(s => s.id === stationData.id ? stationData : s));
    } else {
      // Add new station
      setStations([...stations, stationData]);
    }
    handleCloseModal();
  };

  const handleDeleteStation = (id: string) => {
    if (window.confirm('Вы уверены, что хотите удалить эту станцию?')) {
      setStations(stations.filter(s => s.id !== id));
    }
  };

  const handleEditStation = (station: Station) => {
    handleOpenModal(station);
  };

  const handleAddStation = () => {
    handleOpenModal();
  };

  return (
    <>
      <div className="space-y-6 max-w-7xl mx-auto w-full">
        {/* Header with add button */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-ink">Станции</h2>
            <p className="text-muted">Управление зарядными станциями и мониторинг</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="primary" 
              icon={Plus} 
              onClick={handleAddStation}
            >
              Добавить станцию
            </Button>
          </div>
        </div>

        {/* Stats overview card */}
        <Card variant="filled">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted">Всего станций</p>
                <p className="text-3xl font-bold text-ink">{stations.length}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-brand/10 flex items-center justify-center">
                <Battery className="h-6 w-6 text-brand" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stations table component */}
        <Card>
          <CardContent className="p-6">
            <StationsTable
              stations={sortedStations}
              onEdit={handleEditStation}
              onDelete={handleDeleteStation}
              isCommercialMode={appMode === 'commercial'}
            />
          </CardContent>
        </Card>
      </div>

      {/* Station Modal for create/edit */}
      <StationModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSubmit={handleSaveStation}
        initialData={editingStation}
      />
    </>
  );
};
```

### 3. Sessions.tsx (Expandable Table)

```tsx
import React, { useState } from 'react';
import { Card, CardHeader, CardContent, CardFooter } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { useMode } from '../contexts/ModeContext';
import { Clock, Zap, DollarSign, Battery, Play, ChevronDown, ChevronUp } from 'lucide-react';

// Import mock data
import { mockSessions } from '../data/sessions';

export const Sessions: React.FC = () => {
  const { mode } = useMode();
  const [timeRange, setTimeRange] = useState('today');
  const [expandedSession, setExpandedSession] = useState<string | null>(null);

  const toggleSessionDetails = (id: string) => {
    setExpandedSession(expandedSession === id ? null : id);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full">
      {/* Stats overview with mode-specific columns */}
      <div className={`grid gap-6 ${mode === 'commercial' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'}`}>
        {/* Stat cards */}
      </div>

      {/* Sessions table with expandable rows */}
      <Card>
        <CardHeader title="История сессий" description="Детальная информация по всем зарядным сессиям" />
        
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-bg-2">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted">ID сессии</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted">Станция</th>
                  {/* ... more headers */}
                  {mode === 'commercial' && (
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">Стоимость</th>
                  )}
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted">Статус</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted">Подробнее</th>
                </tr>
              </thead>
              <tbody>
                {mockSessions.map((session) => {
                  return (
                    <React.Fragment key={session.id}>
                      <tr className="border-b border-bg-2 hover:bg-bg-1">
                        {/* Session data cells */}
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <Button
                              variant="icon"
                              size="md"
                              onClick={() => toggleSessionDetails(session.id)}
                            >
                              {expandedSession === session.id ? (
                                <ChevronUp size={20} />
                              ) : (
                                <ChevronDown size={20} />
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                      {expandedSession === session.id && (
                        <tr className="border-b border-bg-2 bg-bg-1">
                          <td colSpan={mode === 'commercial' ? 8 : 7} className="py-4 px-4">
                            <div className={`grid gap-4 ${mode === 'commercial' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2'}`}>
                              <div className="bg-bg-2 rounded-lg p-4">
                                <p className="text-xs text-muted mb-1">Мощность</p>
                                <div className="flex items-center">
                                  <Battery className="h-4 w-4 text-brand mr-2" />
                                  <p className="font-medium text-ink">{session.power} кВт</p>
                                </div>
                              </div>
                              {mode === 'commercial' && (
                                <div className="bg-bg-2 rounded-lg p-4">
                                  <p className="text-xs text-muted mb-1">Способ оплаты</p>
                                  <div className="flex items-center">
                                    <DollarSign className="h-4 w-4 text-brand mr-2" />
                                    <p className="font-medium text-ink capitalize">{session.paymentMethod}</p>
                                  </div>
                                </div>
                              )}
                              {/* ... more detail cells */}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
```

### 4. Tariffs.tsx (Card-based Management)

```tsx
import React, { useState } from 'react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { TariffModal } from '../components/tariff/TariffModal';
import { useTariff } from '../contexts/TariffContext';
import { TariffRuleVisualizer } from '../components/tariff/TariffRuleVisualizer';
import { useToast } from '../components/ui/Toast';
import type { Tariff, TariffFormData } from '../types/tariff';
import { Zap, Plus, Edit, Trash2, Copy } from 'lucide-react';

export const Tariffs: React.FC = () => {
  const { tariffs, addTariff, updateTariff, deleteTariff } = useTariff();
  const { showToast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTariff, setEditingTariff] = useState<Tariff | null>(null);

  const handleCreateTariff = () => {
    setEditingTariff(null);
    setIsModalOpen(true);
  };

  const handleEditTariff = (tariff: Tariff) => {
    setEditingTariff(tariff);
    setIsModalOpen(true);
  };

  const handleCopyTariff = (tariff: Tariff) => {
    const newTariff = {
      ...tariff,
      name: `${tariff.name} (копия)`,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    addTariff(newTariff);
    showToast(`Тариф "${tariff.name}" скопирован`, 'success');
  };

  const handleDeleteTariff = (name: string) => {
    deleteTariff(name);
    showToast(`Тариф "${name}" удален`, 'success');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-ink">Тарифы</h2>
          <p className="text-muted">Управление тарифными планами и ценообразованием</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="primary" icon={Plus} onClick={handleCreateTariff}>
            Новый тариф
          </Button>
        </div>
      </div>

      {/* Tariffs grid */}
      <Card className="mt-4">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {tariffs.map((tariff: Tariff) => (
              <div key={tariff.name} className="bg-bg2 border border-gray-200 rounded-lg p-4 shadow-sm">
                {/* Tariff header with action buttons */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-ink">{tariff.name}</h3>
                    <p className="text-sm text-muted mt-1">{tariff.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="icon" size="sm" onClick={() => handleEditTariff(tariff)}>
                      <Edit size={16} />
                    </Button>
                    <Button variant="icon" size="sm" onClick={() => handleCopyTariff(tariff)}>
                      <Copy size={16} />
                    </Button>
                    <Button variant="icon" size="sm" onClick={() => handleDeleteTariff(tariff.name)}>
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>

                {/* Price display */}
                <div className="flex gap-4 mb-4">
                  <div className="flex items-center space-x-2 text-sm border-2 rounded-md px-2 py-1 shadow-sm"
                    style={{ borderColor: '#0ea5e9' }}>
                    <div className="w-[1em] h-[1em] rounded-sm flex items-center justify-center"
                      style={{ backgroundColor: '#0ea5e9' }}>
                      <Zap size={10} className="text-white" />
                    </div>
                    <span className="text-ink">{tariff.basePricePerKwh}₽/кВч</span>
                  </div>
                </div>

                {/* Session limits */}
                <div className="bg-bg-2 rounded-lg p-3 mb-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted">Макс. время: </span>
                      <span className="font-medium text-ink">
                        {tariff.sessionLimits.maxTime > 0 ? `${tariff.sessionLimits.maxTime} мин` : 'Нет'}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted">Макс. энергия: </span>
                      <span className="font-medium text-ink">
                        {tariff.sessionLimits.maxEnergy > 0 ? `${tariff.sessionLimits.maxEnergy} кВт·ч` : 'Нет'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Rule visualization */}
                {tariff.rules.length > 0 && (
                  <TariffRuleVisualizer
                    rules={tariff.rules}
                    basePricePerKwh={tariff.basePricePerKwh}
                  />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modal for tariff creation/editing */}
      <TariffModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTariff(null);
        }}
        onSubmit={handleSubmitTariff}
        initialData={editingTariff}
        existingNames={tariffs.filter(t => t.name !== editingTariff?.name).map(t => t.name)}
      />
    </div>
  );
};
```

### 5. Layout Components

#### ResponsiveLayout.tsx
```tsx
import React from 'react';
import { useMediaQuery } from '../../hooks/useMediaQuery';
import { DesktopLayout } from './DesktopLayout';
import { MobileLayout } from './MobileLayout';

export const ResponsiveLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  if (isDesktop) {
    return <DesktopLayout>{children}</DesktopLayout>;
  }

  return <MobileLayout>{children}</MobileLayout>;
};
```

#### DesktopLayout.tsx (Navigation Logic)
```tsx
// Filter navigation items based on mode
const filteredNavigationItems = navigationItems.filter(item => {
  if (mode === 'personal') {
    // Hide Tariffs and Finance in personal mode
    return item.name !== 'Тарифы' && item.name !== 'Финансы';
  }
  return true;
});

// Navigation rendering
{filteredNavigationItems.map((item) => (
  <li key={item.name}>
    <NavLink
      to={item.path}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 px-4 py-2 text-sm font-medium rounded-md transition-colors",
          isActive
            ? "bg-brand/light text-brand"
            : "text-muted hover:bg-brand/light hover:text-brand-dark"
        )
      }
    >
      <>
        <div className="p-2 rounded-md">
          <item.icon className="h-5 w-5" />
        </div>
        <span>{item.name}</span>
      </>
    </NavLink>
  </li>
))}
```

### 6. Button.tsx (UI Component)

```tsx
import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'icon';
export type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right';
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon: Icon,
  iconPosition = 'left',
  className,
  disabled,
  ...props
}) => {
  // Base styles with micro-animations
  const baseClasses = 'inline-flex items-center justify-center font-medium rounded-lg transition-colors transition-transform duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-hover active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed';
  
  const variants = {
    primary: 'bg-brand text-white hover:bg-brand-hover active:bg-brand-active focus:ring-brand',
    secondary: 'bg-bg-2 text-ink hover:bg-bg-1 active:bg-bg-0 border border-bg-1',
    danger: 'bg-danger text-white hover:bg-red-600 active:bg-red-700 focus:ring-danger',
    ghost: 'text-ink hover:bg-bg-1 active:bg-bg-2',
    icon: 'p-2 rounded-full hover:bg-bg-1 active:bg-bg-2',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2 text-base',
    lg: 'px-6 py-3 text-lg',
    icon: 'p-2',
  };

  const sizeClass = variant === 'icon' ? sizes.icon : sizes[size];

  return (
    <button
      className={cn(
        baseClasses,
        variants[variant],
        sizeClass,
        loading && 'opacity-70 cursor-wait',
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && (
        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      )}
      {!loading && Icon && iconPosition === 'left' && <Icon className="mr-2 h-4 w-4" />}
      {children}
      {!loading && Icon && iconPosition === 'right' && <Icon className="ml-2 h-4 w-4" />}
    </button>
  );
};
```

## Summary

The CHARGE_admin project demonstrates a sophisticated React application with:

1. **Dual-Mode Architecture**: Personal/Commercial mode switching with conditional UI
2. **Responsive Design**: Mobile-first approach with adaptive layouts
3. **Component-Based Architecture**: Reusable UI components with consistent patterns
4. **State Management**: Context providers with localStorage persistence
5. **User-Centric Design**: Intuitive navigation and interaction patterns

The UI follows consistent patterns across all pages while providing mode-specific functionality. The codebase maintains clean separation of concerns with well-defined component responsibilities and data flow patterns.

Key technical decisions include:
- TypeScript for type safety
- Tailwind CSS for utility-first styling
- React Context for state management
- LocalStorage for data persistence
- Mock data for development and demonstration

This architecture provides a solid foundation for future expansion, including backend API integration, real-time updates, and additional features for both personal and commercial users.
