import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Battery, 
  Clock, 
  CreditCard, 
  DollarSign, 
  User,
  LogOut
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Logo } from '../ui/Logo';
import { cn } from '../../utils/cn';
import { useMode } from '../../contexts/useMode';
import { useUser } from '../../contexts/useUser';

const navigationItems = [
  { name: 'Главная', icon: Home, path: '/' },
  { name: 'Станции', icon: Battery, path: '/stations' },
  { name: 'Сессии', icon: Clock, path: '/sessions' },
  { name: 'Тарифы', icon: CreditCard, path: '/tariffs' },
  { name: 'Финансы', icon: DollarSign, path: '/finance' },
  { name: 'Профиль', icon: User, path: '/profile' },
];

export const DesktopLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { mode, setMode } = useMode();
  const { userData } = useUser();

  // Filter navigation items based on mode
  const filteredNavigationItems = navigationItems.filter(item => {
    if (mode === 'personal') {
      // Hide Tariffs and Finance in personal mode
      return item.name !== 'Тарифы' && item.name !== 'Финансы';
    }
    return true;
  });

  return (
    <div className="flex h-screen overflow-hidden bg-bg1 text-ink" data-mode={mode}>
      {/* Sidebar: Flexbox based, fixed width */}
      <aside className="w-64 flex-shrink-0 flex flex-col border-r border-bg-2 z-20 bg-bg2 w-64">
        {/* Logo */}
        <div className="flex items-center p-6 border-b border-bg-2 flex-shrink-0">
          <Logo className="text-2xl" />
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          <ul className="space-y-2">
            {filteredNavigationItems.map((item) => (
              <li key={item.name}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 px-4 py-4 text-sm lg:text-base font-medium rounded-md transition-colors min-h-[44px]",
                      isActive
                        ? "bg-brand-light text-brand"
                        : "text-muted hover:bg-brand-light hover:text-brand-dark"
                    )
                  }
                >
                  <>
                    <div className="p-2 rounded-md">
                      <item.icon className="h-5 w-5" />
                    </div>
                    <span>{item.name}</span>
                  </>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Right Column: Header + Content */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative">
        {/* Header - Flex item */}
        <header className="flex-shrink-0 border-b border-bg-2 z-10 bg-bg2 h-20 flex items-center">
          <div className="w-full px-6">
            <div className="flex items-center justify-between">
              <div className="max-w-[50%]">
                <h1 className="font-bold text-ink text-xl">Административная панель</h1>
                <p className="text-sm text-muted">Управление зарядными станциями</p>
              </div>
              
              <div className="flex items-center space-x-4">
                {/* Mode Switcher */}
                <div className="bg-bg1 rounded-lg p-1 flex items-center border border-bg-2" style={{ gap: '4px' }}>
                  <button
                    onClick={() => setMode('personal')}
                    className={cn(
                      "px-4 py-3 text-sm font-medium rounded-md transition-all duration-200 min-h-[44px]",
                      mode === 'personal'
                        ? "bg-success text-white shadow-sm"
                        : "text-muted hover:text-ink hover:bg-bg-2"
                    )}
                  >
                    Личный
                  </button>
                  <button
                    onClick={() => setMode('commercial')}
                    className={cn(
                      "px-4 py-3 text-sm font-medium rounded-md transition-all duration-200 min-h-[44px]",
                      mode === 'commercial'
                        ? "bg-brand text-white shadow-sm"
                        : "text-muted hover:text-ink hover:bg-bg-2"
                    )}
                  >
                    Бизнес
                  </button>
                </div>

                <Button 
                  variant="icon" 
                  onClick={() => {
                    console.log('Выход из системы');
                    // В реальном приложении здесь была бы логика выхода
                  }}
                  title="Выйти из системы"
                  aria-label="Выйти из системы"
                >
                  <LogOut size={20} />
                </Button>
                <div className="flex items-center space-x-3">
                <div className="h-8 w-8 rounded-full bg-brand-light flex items-center justify-center">
                  <User size={16} className="text-brand" />
                </div>
                  <div>
                    <p className="text-sm lg:text-base font-medium text-ink">{userData.name}</p>
                    <p className="text-xs text-muted">
                      {mode === 'commercial' ? 'Коммерческий режим' : 'Личный режим'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content - Flex item */}
        <main className="flex-[1_1_0%] overflow-y-auto p-6 bg-bg1">
          <div className="w-full">
            {children}
          </div>
        </main>

      </div>
    </div>
  );
};
