import React, { memo } from 'react';
import { cn } from '../../utils/cn';

export interface MetricCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  change?: string; // e.g. "+5"
  className?: string;
}

export const MetricCard: React.FC<MetricCardProps> = memo(({ 
  icon, 
  label, 
  value, 
  change, 
  className 
}) => {
  return (
    <div className={cn(
      "flex items-center p-4 bg-bg2 border border-bg-2 rounded-lg shadow-sm",
      className
    )}>
      <div className="p-3 rounded-full bg-brand/light text-brand">
        {icon}
      </div>
      <div className="ml-4 flex flex-col gap-1">
        <span className="text-muted text-sm">{label}</span>
        <div className="flex items-baseline gap-2">
          <span className="text-ink text-2xl font-semibold">{value}</span>
          {change && (
            <span className={cn(
              "text-xs font-medium px-1.5 py-0.5 rounded",
              change.startsWith('+') 
                ? "bg-success/10 text-success" 
                : "bg-error/10 text-error"
            )}>
              {change}
            </span>
          )}
        </div>
      </div>
    </div>
  );
});

MetricCard.displayName = 'MetricCard';
