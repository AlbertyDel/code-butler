import React, { useState } from 'react';
import { Card, CardHeader, CardContent, CardFooter } from '../components/ui/Card';
import { SessionDetailsModal } from '../components/session/SessionDetailsModal';
import { SessionsTable } from '../components/session/SessionsTable';
import { useMode } from '../contexts/useMode';
import { 
  Clock, 
  Zap, 
  // DollarSign, 
  Play,
} from 'lucide-react';

// Import mock data from /data folder
import { mockSessions, type Session } from '../data/sessions';

const timeRanges = [
  { label: 'Сегодня', value: 'today' },
  { label: 'Вчера', value: 'yesterday' },
  { label: '7 дней', value: '7days' },
  { label: '30 дней', value: '30days' },
  { label: 'Все время', value: 'all' },
];

export const Sessions: React.FC = () => {
  const { mode } = useMode();
  const [timeRange, setTimeRange] = useState('today');
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredSessions = mockSessions;
  
  // Temporary inline styles because Tailwind CSS isn't loading
  const tempStyles = `
    /* Force brand color border for all cards */
    .grid > div.rounded-xl {
      border-color: #4F46E5 !important;
      border-width: 2px !important;
      border-radius: 12px !important; /* rounded-xl */
    }
    
    /* Make container background white */
    .grid {
      background-color: white !important;
      padding: 16px !important;
      border-radius: 12px !important;
    }
    
    @media (min-width: 640px) {
      /* Show all table columns on desktop */
      table th.hidden.sm\\:table-cell,
      table td.hidden.sm\\:table-cell {
        display: table-cell !important;
      }
      
      /* Show status badge text on desktop */
      span.inline-flex.items-center span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Hide screen reader text on desktop */
      span.inline-flex.items-center span.sr-only.sm\\:not-sr-only {
        display: none !important;
      }
      
      /* Show desktop header text, hide mobile header icons */
      th span.sm\\:hidden {
        display: none !important;
      }
      th span.hidden.sm\\:inline {
        display: inline !important;
      }
      
      /* Reset icon sizes on desktop */
      th svg.w-6.h-4 {
        width: auto !important;
        height: auto !important;
      }
    }
    
    @media (max-width: 639px) {
      /* Hide table columns on mobile */
      table th.hidden.sm\\:table-cell,
      table td.hidden.sm\\:table-cell {
        display: none !important;
      }
      
      /* Hide status badge text on mobile */
      span.inline-flex.items-center span.hidden.sm\\:inline {
        display: none !important;
      }
      
      /* Show screen reader text on mobile */
      span.inline-flex.items-center span.sr-only.sm\\:not-sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
      }
      
      /* Show mobile header icons, hide desktop header text */
      th span.sm\\:hidden {
        display: inline !important;
      }
      th span.hidden.sm\\:inline {
        display: none !important;
      }
      
      /* Make mobile header icons 150% larger with current size as minimum */
      th svg.w-6.h-4 {
        /* Current size (21.5px) as minimum at 320px, 150% larger (32.25px) at 430px */
        /* Width: scales from 21.5px (320px) to 32.25px (430px) to max 40px */
        width: clamp(21.5px, 9.77vw, 40px) !important;
        /* Height: scales from 17.2px (320px) to 25.8px (430px) to max 32px */
        height: clamp(17.2px, 7.82vw, 32px) !important;
        /* Ensure minimum and maximum constraints */
        min-width: 21.5px !important;
        min-height: 17.2px !important;
        max-width: 40px !important;
        max-height: 32px !important;
        /* Maintain aspect ratio (5:4) */
        aspect-ratio: 5/4 !important;
      }
      
      /* Increase header cell height to accommodate 150% larger icons */
      th {
        min-height: 40px !important;
        height: auto !important;
      }
      
      /* Ensure header cell content is properly centered */
      th div.flex.items-center.justify-center {
        min-height: 36px !important;
        align-items: center !important;
      }
      
      /* Center align mobile header icons */
      th div.flex.items-center.justify-center {
        justify-content: center !important;
        text-align: center !important;
      }
      
      /* Ensure gap works for time filter buttons */
      div.flex.gap-0\\.5 {
        gap: 2px !important;
      }
      
      /* Ensure buttons shrink properly on mobile */
      button.flex-shrink {
        flex-shrink: 1 !important;
        min-width: 0 !important;
      }
      
      /* Ensure text stays single line */
      button.whitespace-nowrap {
        white-space: nowrap !important;
      }
      
      /* Ensure padding and font size work on mobile */
      button.text-base {
        font-size: 16px !important;
        line-height: 1.5rem !important;
      }
      
      button.px-4 {
        padding-left: 16px !important;
        padding-right: 16px !important;
      }
      
      button.py-3 {
        padding-top: 12px !important;
        padding-bottom: 12px !important;
      }
      
      /* Ensure flex-grow works */
      button.flex-grow {
        flex-grow: 1 !important;
      }
      
      /* Ensure text is centered on mobile */
      div.flex.gap-0\\.5 button {
        text-align: center !important;
      }
      
      /* On very small screens (< 450px), reduce padding to keep text centered */
      @media (max-width: 449px) {
        div.flex.gap-0\\.5 button {
          padding-left: 8px !important;
          padding-right: 8px !important;
        }
      }
    }
    
      /* Desktop styles (≥1024px) */
      @media (min-width: 1024px) {
        /* Ensure text is left-aligned on desktop */
        div.flex.gap-0\\.5 button {
          text-align: left !important;
        }
        
        /* Remove flex-grow on desktop */
        div.flex.gap-0\\.5 button.flex-grow {
          flex-grow: 0 !important;
        }
        
        /* Set auto width on desktop */
        div.flex.gap-0\\.5 button {
          width: auto !important;
        }
        
        /* Increase table header font size by 30% (from 16px to 20.8px) */
        table th {
          font-size: 20.8px !important;
        }
        
        /* Ensure uppercase and tracking */
        table th {
          text-transform: uppercase !important;
          letter-spacing: 0.05em !important;
        }
        
        /* SessionsTable handles its own column widths and alignment */
      }
  `;

  // const handleStatusClick = (session: Session) => {
  //   setSelectedSession(session);
  //   setIsModalOpen(true);
  // };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedSession(null);
  };


  const totalStats = {
    totalSessions: filteredSessions.length,
    activeSessions: filteredSessions.filter(s => s.status === 'active').length,
    totalEnergy: filteredSessions.reduce((sum, session) => sum + session.energy, 0),
    totalRevenue: filteredSessions.reduce((sum, session) => sum + session.cost, 0),
  };

  const handleSessionClick = (session: Session) => {
    setSelectedSession(session);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-20 sm:pb-0">
      {/* Temporary style tag because Tailwind CSS isn't loading */}
      <style dangerouslySetInnerHTML={{ __html: tempStyles }} />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-ink">Сессии</h2>
          <p className="text-muted">История и управление зарядными сессиями</p>
        </div>
      </div>

      {/* Stats overview - 4 cards in one row on all screen sizes with fluid scaling */}
      <div className={`grid ${mode === 'commercial' ? 'grid-cols-4' : 'grid-cols-3'} gap-2 sm:gap-3 md:gap-4 lg:gap-6`}>
        <Card variant="outline" className="overflow-hidden !border-brand">
          <CardContent className="p-2 sm:p-3 md:p-4 lg:p-6 pb-0 lg:pb-6">
            <div className="flex flex-col items-center lg:flex-row lg:items-start" style={{ gap: '0px' }}>
              <div className="rounded-full bg-brand/10 flex items-center justify-center flex-shrink-0 self-center lg:self-auto"
                   style={{
                     width: 'clamp(3.5rem, 7vw, 4.5rem)',
                     height: 'clamp(3.5rem, 7vw, 4.5rem)',
                     minWidth: '3.5rem',
                     minHeight: '3.5rem'
                   }}>
                <Clock className="text-brand" style={{
                  width: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                  height: 'clamp(1.75rem, 3.5vw, 2.25rem)'
                }} />
              </div>
              <div className="min-w-0 flex-1 w-full text-center lg:text-left" style={{ marginTop: '4px' }}>
                <p className="text-muted w-full" style={{
                  fontSize: 'clamp(1rem, 3.5vw, 1.5rem)',
                  lineHeight: '1',
                  fontWeight: '500',
                  marginTop: '0',
                  marginBottom: '0',
                  width: '100%',
                  textAlign: 'center',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden'
                }}>Сессий</p>
                <p className="font-bold text-ink w-full mt-0 lg:mt-1 text-center lg:text-left" style={{
                  fontSize: 'clamp(1.25rem, 3vw, 1.875rem)',
                  lineHeight: '1',
                  marginTop: '0',
                  marginBottom: '0',
                  paddingBottom: '0',
                  textAlign: 'center'
                }}>{totalStats.totalSessions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card variant="outline" className="overflow-hidden !border-brand">
          <CardContent className="p-2 sm:p-3 md:p-4 lg:p-6 pb-0 lg:pb-6">
            <div className="flex flex-col items-center lg:flex-row lg:items-start" style={{ gap: '0px' }}>
              <div className="rounded-full bg-info/10 flex items-center justify-center flex-shrink-0 self-center lg:self-auto"
                   style={{
                     width: 'clamp(3.5rem, 7vw, 4.5rem)',
                     height: 'clamp(3.5rem, 7vw, 4.5rem)',
                     minWidth: '3.5rem',
                     minHeight: '3.5rem'
                   }}>
                <Play className="text-info" style={{
                  width: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                  height: 'clamp(1.75rem, 3.5vw, 2.25rem)'
                }} />
              </div>
              <div className="min-w-0 flex-1 w-full text-center lg:text-left" style={{ marginTop: '4px' }}>
                <p className="text-muted w-full" style={{
                  fontSize: 'clamp(1rem, 3.5vw, 1.5rem)',
                  lineHeight: '1',
                  fontWeight: '500',
                  marginTop: '0',
                  marginBottom: '0',
                  width: '100%',
                  textAlign: 'center',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden'
                }}>Активные</p>
                <p className="font-bold text-ink w-full mt-0 lg:mt-1 text-center lg:text-left" style={{
                  fontSize: 'clamp(1.25rem, 3vw, 1.875rem)',
                  lineHeight: '1',
                  marginTop: '0',
                  marginBottom: '0',
                  paddingBottom: '0',
                  textAlign: 'center'
                }}>{totalStats.activeSessions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card variant="outline" className="overflow-hidden !border-brand">
          <CardContent className="p-2 sm:p-3 md:p-4 lg:p-6 pb-0 lg:pb-6">
            <div className="flex flex-col items-center lg:flex-row lg:items-start" style={{ gap: '0px' }}>
              <div className="rounded-full bg-warning/10 flex items-center justify-center flex-shrink-0 self-center lg:self-auto"
                   style={{
                     width: 'clamp(3.5rem, 7vw, 4.5rem)',
                     height: 'clamp(3.5rem, 7vw, 4.5rem)',
                     minWidth: '3.5rem',
                     minHeight: '3.5rem'
                   }}>
                <Zap className="text-warning" style={{
                  width: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                  height: 'clamp(1.75rem, 3.5vw, 2.25rem)'
                }} />
              </div>
              <div className="min-w-0 flex-1 w-full text-center lg:text-left" style={{ marginTop: '4px' }}>
                <p className="text-muted w-full" style={{
                  fontSize: 'clamp(1rem, 3.5vw, 1.5rem)',
                  lineHeight: '1',
                  fontWeight: '500',
                  marginTop: '0',
                  marginBottom: '0',
                  width: '100%',
                  textAlign: 'center',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden'
                }}>Энергия</p>
                <p className="font-bold text-ink w-full mt-0 lg:mt-1 text-center lg:text-left" style={{
                  fontSize: 'clamp(1.25rem, 3vw, 1.875rem)',
                  lineHeight: '1',
                  marginTop: '0',
                  marginBottom: '0',
                  paddingBottom: '0',
                  textAlign: 'center'
                }}>{Math.round(totalStats.totalEnergy)}К</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {mode === 'commercial' && (
          <Card variant="outline" className="overflow-hidden !border-brand">
            <CardContent className="p-2 sm:p-3 md:p-4 lg:p-6 pb-0 lg:pb-6">
              <div className="flex flex-col items-center lg:flex-row lg:items-start" style={{ gap: '0px' }}>
                <div className="rounded-full bg-success/10 flex items-center justify-center flex-shrink-0 self-center lg:self-auto"
                     style={{
                       width: 'clamp(3.5rem, 7vw, 4.5rem)',
                       height: 'clamp(3.5rem, 7vw, 4.5rem)',
                       minWidth: '3.5rem',
                       minHeight: '3.5rem'
                     }}>
                  <span className="text-success font-bold" style={{
                    width: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                    height: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                    fontSize: 'clamp(1.75rem, 3.5vw, 2.25rem)',
                    lineHeight: '1',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#10B981'
                  }}>₽</span>
                </div>
                <div className="min-w-0 flex-1 w-full text-center lg:text-left" style={{ marginTop: '4px' }}>
                  <p className="text-muted w-full" style={{
                    fontSize: 'clamp(1rem, 3.5vw, 1.5rem)',
                    lineHeight: '1',
                    fontWeight: '500',
                    marginTop: '0',
                    marginBottom: '0',
                    width: '100%',
                    textAlign: 'center',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden'
                  }}>Доход</p>
                  <p className="font-bold text-ink w-full mt-0 lg:mt-1 text-center lg:text-left" style={{
                    fontSize: 'clamp(1.25rem, 3vw, 1.875rem)',
                    lineHeight: '1',
                    marginTop: '0',
                    marginBottom: '0',
                    paddingBottom: '0',
                    textAlign: 'center'
                  }}>{totalStats.totalRevenue.toLocaleString()}₽</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>


      {/* Sessions list */}
      <Card>
        <CardHeader
          title="История сессий"
          description="Детальная информация по всем зарядным сессиям"
        />
        
        {/* Time range filters */}
        <div className="px-6 pt-4 pb-4">
          <div className="flex gap-0.5">
            {timeRanges.map((range) => (
              <button
                key={range.value}
                onClick={() => setTimeRange(range.value)}
                className={`px-4 py-3 rounded-md text-base sm:text-sm font-medium transition-colors min-h-[44px] flex-grow flex-shrink whitespace-nowrap border sm:flex-grow-0 sm:w-auto sm:text-left ${timeRange === range.value ? 'bg-brand text-white border-brand' : 'bg-bg-2 text-ink border-bg-1 hover:bg-bg-1'}`}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>
        
        <CardContent className="p-0">
          <SessionsTable
            sessions={filteredSessions}
            isCommercialMode={mode === 'commercial'}
            onSessionClick={handleSessionClick}
          />
        </CardContent>
        <CardFooter className="flex items-center justify-between">
          <div className="text-sm text-muted">
            Показано {filteredSessions.length} сессий
          </div>
        </CardFooter>
      </Card>

      {/* Session Details Modal */}
      <SessionDetailsModal
        session={selectedSession}
        isOpen={isModalOpen}
        onClose={closeModal}
      />
    </div>
  );
};
