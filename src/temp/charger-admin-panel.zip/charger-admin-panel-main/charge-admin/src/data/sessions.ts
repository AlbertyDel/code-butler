import { fakerRU as faker } from '@faker-js/faker';

// Ensure deterministic results on each app start
faker.seed(2026);

export interface Session {
  id: string;
  stationId: string;
  stationName: string;
  userId: string;
  userName: string;
  startTime: string;
  endTime: string | null;
  duration: string;
  energy: number;
  power: number;
  cost: number;
  status: 'active' | 'completed' | 'cancelled' | 'failed';
  paymentMethod: 'карта' | 'кошелёк' | 'QR-код';
  cardNumber?: string; // For карта payments
  walletId?: string; // For кошелёк payments
  qrCodeId?: string; // For QR-код payments
}

// Mock sessions data - matches exact structure from Sessions.tsx
export const mockSessions: Session[] = [
  { 
    id: 'SESS-2025-0012', 
    stationId: 'CHG-0012',
    stationName: 'Станция А',
    userId: 'USER-0456',
    userName: 'Иван Петров',
    startTime: '2025-01-05 14:30',
    endTime: '2025-01-05 16:45',
    duration: '2ч 15м',
    energy: 24.8,
    power: 11,
    cost: 745,
    status: 'completed',
    paymentMethod: 'карта',
    cardNumber: '•••• •••• •••• 1234'
  },
  { 
    id: 'SESS-2025-0013', 
    stationId: 'CHG-0015',
    stationName: 'Станция Г',
    userId: 'USER-0789',
    userName: 'Анна Сидорова',
    startTime: '2025-01-05 15:20',
    endTime: '2025-01-05 17:10',
    duration: '1ч 50м',
    energy: 20.3,
    power: 11,
    cost: 609,
    status: 'completed',
    paymentMethod: 'кошелёк',
    walletId: 'WALLET-7890'
  },
  { 
    id: 'SESS-2025-0014', 
    stationId: 'CHG-0016',
    stationName: 'Станция Д',
    userId: 'USER-0123',
    userName: 'Пётр Иванов',
    startTime: '2025-01-05 16:00',
    endTime: null,
    duration: '1ч 30м',
    energy: 67.5,
    power: 50,
    cost: 2025,
    status: 'active',
    paymentMethod: 'QR-код',
    qrCodeId: 'QR-2025-0014'
  },
  { 
    id: 'SESS-2025-0015', 
    stationId: 'CHG-0012',
    stationName: 'Станция А',
    userId: 'USER-0567',
    userName: 'Мария Козлова',
    startTime: '2025-01-05 10:15',
    endTime: '2025-01-05 11:30',
    duration: '1ч 15м',
    energy: 13.8,
    power: 11,
    cost: 414,
    status: 'completed',
    paymentMethod: 'карта',
    cardNumber: '•••• •••• •••• 5678'
  },
  { 
    id: 'SESS-2025-0016', 
    stationId: 'CHG-0013',
    stationName: 'Станция Б',
    userId: 'USER-0890',
    userName: 'Сергей Смирнов',
    startTime: '2025-01-05 09:00',
    endTime: '2025-01-05 11:45',
    duration: '2ч 45м',
    energy: 30.3,
    power: 11,
    cost: 909,
    status: 'completed',
    paymentMethod: 'кошелёк',
    walletId: 'WALLET-9012'
  },
  { 
    id: 'SESS-2025-0017', 
    stationId: 'CHG-0016',
    stationName: 'Станция Д',
    userId: 'USER-0345',
    userName: 'Ольга Новикова',
    startTime: '2025-01-05 13:00',
    endTime: null,
    duration: '0ч 45м',
    energy: 37.5,
    power: 50,
    cost: 1125,
    status: 'active',
    paymentMethod: 'QR-код',
    qrCodeId: 'QR-2025-0017'
  },
];

// Keep defaultSessions as alias for backward compatibility
export const defaultSessions = mockSessions;

// Generate additional sessions using Faker
export const generateSessions = (count: number = 10): Session[] => {
  const sessions: Session[] = [];
  const stations = [
    { id: 'CHG-0012', name: 'Станция А' },
    { id: 'CHG-0013', name: 'Станция Б' },
    { id: 'CHG-0014', name: 'Станция В' },
    { id: 'CHG-0015', name: 'Станция Г' },
    { id: 'CHG-0016', name: 'Станция Д' },
  ];
  const statuses: Session['status'][] = ['active', 'completed', 'completed', 'completed', 'cancelled'];
  const paymentMethods: Session['paymentMethod'][] = ['карта', 'кошелёк', 'QR-код'];
  
  const baseDate = new Date(2025, 0, 5); // January 5, 2025
  
  for (let i = 0; i < count; i++) {
    const station = faker.helpers.arrayElement(stations);
    const startHour = faker.number.int({ min: 8, max: 20 });
    const durationHours = faker.number.float({ min: 0.5, max: 4, multipleOf: 0.25 });
    const energy = faker.number.float({ min: 5, max: 80, multipleOf: 0.1 });
    const power = faker.helpers.arrayElement([7, 11, 22, 50]);
    const cost = Math.round(energy * 30); // 30 ₽/kWh
    const paymentMethod = faker.helpers.arrayElement(paymentMethods);
    
    const startDate = new Date(baseDate);
    startDate.setHours(startHour, faker.number.int({ min: 0, max: 59 }));
    
    const endDate = new Date(startDate);
    endDate.setHours(startDate.getHours() + Math.floor(durationHours));
    endDate.setMinutes(startDate.getMinutes() + Math.round((durationHours % 1) * 60));
    
    const durationStr = `${Math.floor(durationHours)}ч ${Math.round((durationHours % 1) * 60)}м`;
    
    // Generate payment details based on method
    const sessionData: Session = {
      id: `SESS-2025-${1000 + i}`,
      stationId: station.id,
      stationName: station.name,
      userId: `USER-${String(1000 + i).padStart(4, '0')}`,
      userName: faker.person.fullName(),
      startTime: `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')} ${String(startDate.getHours()).padStart(2, '0')}:${String(startDate.getMinutes()).padStart(2, '0')}`,
      endTime: faker.datatype.boolean(0.8) ? `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')} ${String(endDate.getHours()).padStart(2, '0')}:${String(endDate.getMinutes()).padStart(2, '0')}` : null,
      duration: durationStr,
      energy,
      power,
      cost,
      status: faker.helpers.arrayElement(statuses),
      paymentMethod,
    };
    
    // Add payment-specific details
    if (paymentMethod === 'карта') {
      sessionData.cardNumber = `•••• •••• •••• ${faker.finance.creditCardNumber().slice(-4)}`;
    } else if (paymentMethod === 'кошелёк') {
      sessionData.walletId = `WALLET-${faker.string.numeric(6)}`;
    } else if (paymentMethod === 'QR-код') {
      sessionData.qrCodeId = `QR-${startDate.getFullYear()}-${String(1000 + i).padStart(4, '0')}`;
    }
    
    sessions.push(sessionData);
  }
  
  return sessions;
};
