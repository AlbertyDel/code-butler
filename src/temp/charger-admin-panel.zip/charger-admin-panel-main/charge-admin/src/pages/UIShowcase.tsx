import React, { useState } from 'react';
import { useMode } from '../contexts/useMode';
import { Button } from '../components/ui/Button';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { SmartGrid } from '../components/ui/SmartGrid';
import { StatusBadge } from '../components/ui/StatusBadge';
import { Skeleton, MetricCardSkeleton } from '../components/ui/Skeleton';
import { 
  Zap, 
  RefreshCw,
  Battery,
  DollarSign,
  Plus,
  X,
  Save,
  AlertCircle,
  Edit,
  Trash2,
  Eye,
  Clock,
  User,
  Building,
  CreditCard,
  Info,
  Check,
  ArrowRight,
  Shield,
  BatteryCharging
} from 'lucide-react';

// Import mock data
import { mockStations } from '../data/dashboard-stations';

const UIShowcase: React.FC = () => {
  const { mode: currentMode } = useMode();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedMode, setSelectedMode] = useState<'personal' | 'commercial'>(currentMode);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'gradient'>('primary');
  const [formData, setFormData] = useState({
    name: '',
    id: 'CHG-1000',
    location: '',
    power: 11,
    ports: 1,
    status: 'ready' as const,
    tariffName: 'Базовый',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleModeToggle = () => {
    const newMode = selectedMode === 'personal' ? 'commercial' : 'personal';
    setSelectedMode(newMode);
  };

  const handleSimulateLoading = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  const handleOpenModal = (modalName: string) => {
    setActiveModal(modalName);
  };

  const handleCloseModal = () => {
    setActiveModal(null);
    setErrors({});
  };

  const handleFormChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Название станции обязательно';
    }
    
    if (!formData.location.trim()) {
      newErrors.location = 'Локация обязательна';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      console.log('Form submitted:', formData);
      handleCloseModal();
    }
  };

  // Showcase-specific design tokens
  const showcaseTokens = {
    personal: {
      primary: 'bg-personal-primary-500',
      secondary: 'bg-personal-secondary-500',
      accent: 'bg-personal-accent-500',
      background: 'bg-personal-background-DEFAULT',
      surface: 'bg-personal-surface-DEFAULT',
      textPrimary: 'text-personal-text-primary',
      textSecondary: 'text-personal-text-secondary',
      border: 'border-personal-primary-200',
      hover: 'hover:bg-personal-primary-100',
      focus: 'focus:ring-personal-primary-300',
    },
    commercial: {
      primary: 'bg-commercial-primary-500',
      secondary: 'bg-commercial-secondary-500',
      accent: 'bg-commercial-accent-500',
      background: 'bg-commercial-background-DEFAULT',
      surface: 'bg-commercial-surface-DEFAULT',
      textPrimary: 'text-commercial-text-primary',
      textSecondary: 'text-commercial-text-secondary',
      border: 'border-commercial-primary-300',
      hover: 'hover:bg-commercial-primary-100',
      focus: 'focus:ring-commercial-primary-300',
    }
  };

  const tokens = showcaseTokens[selectedMode];

  // Modal render functions
  const renderStationModal = () => {
    if (activeModal !== 'station') return null;
    
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
        style={{ top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div className={`w-full max-w-2xl ${tokens.surface} border ${tokens.border} rounded-lg shadow-xl max-h-[90vh] overflow-y-auto`}>
          <div className="border-b border-bg-2 p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-ink">
              {formData.id ? 'Редактировать станцию' : 'Создать новую станцию'}
            </h2>
            <Button variant="icon" onClick={handleCloseModal}>
              <X size={24} />
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="relative">
              <label htmlFor="station-name" className="block text-sm font-medium text-muted mb-2">
                Название станции *
              </label>
              <input
                id="station-name"
                type="text"
                className={`w-full bg-bg-2 border ${errors.name ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                value={formData.name}
                onChange={(e) => handleFormChange('name', e.target.value)}
                placeholder="Введите название станции"
                aria-describedby={errors.name ? "name-error" : undefined}
              />
              {errors.name && (
                <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                  <div className="bg-danger text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative text-white">
                    <AlertCircle size={14} className="flex-shrink-0" />
                    <span>{errors.name}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-danger"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="relative">
              <label htmlFor="station-location" className="block text-sm font-medium text-muted mb-2">
                Локация *
              </label>
              <input
                id="station-location"
                type="text"
                className={`w-full bg-bg-2 border ${errors.location ? 'border-danger' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                value={formData.location}
                onChange={(e) => handleFormChange('location', e.target.value)}
                placeholder="Введите адрес станции"
                aria-describedby={errors.location ? "location-error" : undefined}
              />
              {errors.location && (
                <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                  <div className="bg-danger text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative text-white">
                    <AlertCircle size={14} className="flex-shrink-0" />
                    <span>{errors.location}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-danger"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2" style={{ gap: '16px' }}>
              <div>
                <label htmlFor="station-power" className="block text-sm font-medium text-muted mb-2">
                  Мощность (кВт) *
                </label>
                <select
                  id="station-power"
                  className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                  value={formData.power}
                  onChange={(e) => handleFormChange('power', Number(e.target.value))}
                >
                  <option value="7">7 кВт</option>
                  <option value="11">11 кВт</option>
                  <option value="22">22 кВт</option>
                </select>
              </div>

              <div>
                <label htmlFor="station-ports" className="block text-sm font-medium text-muted mb-2">
                  Количество портов *
                </label>
                <select
                  id="station-ports"
                  className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                  value={formData.ports}
                  onChange={(e) => handleFormChange('ports', Number(e.target.value))}
                >
                  <option value="1">1 порт</option>
                  <option value="2">2 порта</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="station-status" className="block text-sm font-medium text-muted mb-2">
                Статус *
              </label>
              <select
                id="station-status"
                className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                value={formData.status}
                onChange={(e) => handleFormChange('status', e.target.value)}
              >
                <option value="ready">Готова</option>
                <option value="charging">Заряжает</option>
                <option value="offline">Оффлайн</option>
                <option value="pending">Ожидание</option>
                <option value="fault">Неисправность</option>
              </select>
            </div>

            <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
              <Button variant="secondary" onClick={handleCloseModal} icon={X} type="button">
                Отмена
              </Button>
              <Button variant="primary" type="submit" icon={Save} className={tokens.primary}>
                Сохранить
              </Button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const renderTariffModal = () => {
    if (activeModal !== 'tariff') return null;
    
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
        style={{ top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div className={`w-full max-w-2xl ${tokens.surface} border ${tokens.border} rounded-lg shadow-xl max-h-[90vh] overflow-y-auto`}>
          <div className="border-b border-bg-2 p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-ink">
              Создать новый тариф
            </h2>
            <Button variant="icon" onClick={handleCloseModal}>
              <X size={24} />
            </Button>
          </div>

          <div className="p-6 space-y-4">
            <div>
              <label htmlFor="tariff-name" className="block text-sm font-medium text-muted mb-2">
                Название тарифа *
              </label>
              <input
                id="tariff-name"
                type="text"
                className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                placeholder="Например: Базовый, Премиум, Ночной"
              />
            </div>

            <div>
              <label htmlFor="tariff-price" className="block text-sm font-medium text-muted mb-2">
                Цена за кВт·ч (руб) *
              </label>
              <input
                id="tariff-price"
                type="number"
                step="0.01"
                className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                placeholder="5.50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-muted mb-2">
                Временные правила
              </label>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="peak-hours" className="rounded" />
                  <label htmlFor="peak-hours" className="text-sm text-ink">
                    Пиковые часы (повышенная ставка)
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="night-hours" className="rounded" />
                  <label htmlFor="night-hours" className="text-sm text-ink">
                    Ночные часы (пониженная ставка)
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="weekend" className="rounded" />
                  <label htmlFor="weekend" className="text-sm text-ink">
                    Выходные дни
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
              <Button variant="secondary" onClick={handleCloseModal} icon={X} type="button">
                Отмена
              </Button>
              <Button variant="primary" type="button" icon={Save} className={tokens.primary}>
                Создать тариф
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSessionDetailsModal = () => {
    if (activeModal !== 'session') return null;
    
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
        style={{ top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div className={`w-full max-w-2xl ${tokens.surface} border ${tokens.border} rounded-lg shadow-xl max-h-[90vh] overflow-y-auto`}>
          <div className="border-b border-bg-2 p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-ink">
              Детали сессии
            </h2>
            <Button variant="icon" onClick={handleCloseModal}>
              <X size={24} />
            </Button>
          </div>

          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted mb-2">Информация о сессии</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">ID сессии:</span>
                    <span className="font-medium">SESS-7890</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">Станция:</span>
                    <span className="font-medium">CHG-1001</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">Статус:</span>
                    <StatusBadge status="success" label="Завершена" />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-muted mb-2">Данные о зарядке</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">Энергия:</span>
                    <span className="font-medium">42.5 кВт·ч</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">Длительность:</span>
                    <span className="font-medium">3 ч 42 мин</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted">Стоимость:</span>
                    <span className="font-medium">$23.38</span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted mb-2">Временная шкала</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted">Начало:</span>
                  <span className="font-medium">15:30, 15 янв 2026</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted">Окончание:</span>
                  <span className="font-medium">19:12, 15 янв 2026</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted">Длительность:</span>
                  <span className="font-medium">3 ч 42 мин</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-bg-2 flex justify-end">
              <Button variant="primary" onClick={handleCloseModal} className={tokens.primary}>
                Закрыть
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Main render
  return (
    <div 
      data-mode={selectedMode}
      className={`min-h-screen bg-mode-background p-4 md:p-8 xl:p-12`}
    >
      {/* Sticky Navigation */}
      <div className="sticky top-0 z-40 mb-8 bg-mode-surface/80 backdrop-blur-sm border-b border-mode-border -mx-4 md:-mx-8 xl:-mx-12 px-4 md:px-8 xl:px-12 py-3 xl:py-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between" style={{ gap: '16px' }}>
          <div>
            <h1 className="text-display-sm md:text-display-md xl:text-display-lg font-bold text-ink">
              Дизайн-система CHARGE_admin
            </h1>
            <p className="mt-1 text-body-sm md:text-body-md xl:text-body-lg text-muted">
              Демонстрация компонентов и паттернов дизайн-системы
            </p>
          </div>
          
          <div className="flex items-center gap-4 xl:gap-6">
              <div className="flex items-center gap-2 xl:gap-3">
              <span className="text-sm xl:text-base font-medium text-ink">
                Режим: <span className="font-semibold">{selectedMode === 'personal' ? 'Персональный' : 'Коммерческий'}</span>
              </span>
              <div className="flex bg-bg-2 rounded-lg p-1" style={{ gap: '8px' }}>
                <button
                  onClick={() => setSelectedMode('personal')}
                  className={`px-4 py-2 rounded-md text-sm xl:text-base font-medium transition-colors ${
                    selectedMode === 'personal'
                      ? `${tokens.primary} text-white`
                      : 'text-muted hover:text-ink'
                  }`}
                >
                  Персональный
                </button>
                <button
                  onClick={() => setSelectedMode('commercial')}
                  className={`px-4 py-2 rounded-md text-sm xl:text-base font-medium transition-colors ${
                    selectedMode === 'commercial'
                      ? `${tokens.primary} text-white`
                      : 'text-muted hover:text-ink'
                  }`}
                >
                  Коммерческий
                </button>
              </div>
            </div>
            
            <Button
              variant="secondary"
              onClick={handleModeToggle}
              icon={RefreshCw}
              size="md"
              className="inline-flex truncate min-w-fit text-sm md:text-base"
            >
              Переключить
            </Button>
          </div>
        </div>
        
        {/* Quick Navigation */}
        <div className="mt-3 xl:mt-4 flex flex-wrap gap-2 xl:gap-3">
          <a href="#modals" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Модалки
          </a>
          <a href="#buttons" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Кнопки
          </a>
          <a href="#loading" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Загрузка
          </a>
          <a href="#status" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Статусы
          </a>
          <a href="#forms" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Формы
          </a>
          <a href="#tables" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Таблицы
          </a>
          <a href="#metrics" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Метрики
          </a>
          <a href="#accessibility" className="text-xs xl:text-sm px-3 py-1.5 xl:px-4 xl:py-2 bg-bg-2 hover:bg-bg-1 text-ink rounded-md transition-colors">
            Доступность
          </a>
        </div>
      </div>

      {/* Mode Info Banner */}
      <div className="mb-8 p-4 border border-bg-1 rounded-lg bg-gradient-to-r from-brand/5 to-transparent">
        <div className="flex items-center gap-3">
          <Info size={20} className="text-brand flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-ink">
              Текущий режим: <span className="font-semibold">{selectedMode === 'personal' ? 'Персональный' : 'Коммерческий'}</span>
            </p>
            <p className="text-xs text-muted mt-1">
              Компоненты автоматически адаптируются под выбранный режим. Цвета, тени и типография меняются в зависимости от контекста.
            </p>
          </div>
        </div>
      </div>

      {/* Modal Gallery Section */}
      <section id="modals" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Модальные окна
        </h2>
        <SmartGrid minColumnWidth={300} maxColumns={3} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card 
            variant="elevated" 
            hover 
            shadow={selectedMode === 'personal' ? 'personal' : 'md'}
            animation="fade-in"
            className={`border-l-4 ${selectedMode === 'personal' ? 'border-l-personal-primary-500' : 'border-l-commercial-primary-500'}`}
          >
            <CardContent className="p-6">
              <CardHeader
                title="Станция"
                description="Форма создания и редактирования станций с валидацией полей"
                icon={<Building className={`h-6 w-6 ${selectedMode === 'personal' ? 'text-personal-primary-500' : 'text-commercial-primary-500'}`} />}
                size="sm"
              />
              <Button 
                variant="primary" 
                onClick={() => handleOpenModal('station')}
                className={`mt-4 ${selectedMode === 'personal' ? 'bg-personal-primary-500 hover:bg-personal-primary-600' : 'bg-commercial-primary-500 hover:bg-commercial-primary-600'}`}
              >
                Открыть модалку
              </Button>
            </CardContent>
          </Card>

          <Card 
            variant="elevated" 
            hover 
            shadow={selectedMode === 'commercial' ? 'commercial' : 'md'}
            animation="slide-up"
            className={`border-l-4 ${selectedMode === 'commercial' ? 'border-l-commercial-primary-500' : 'border-l-personal-primary-500'}`}
          >
            <CardContent className="p-6">
              <CardHeader
                title="Тариф"
                description="Создание тарифов с временными правилами и настройки"
                icon={<CreditCard className={`h-6 w-6 ${selectedMode === 'commercial' ? 'text-commercial-primary-500' : 'text-personal-primary-500'}`} />}
                size="sm"
              />
              <Button 
                variant="primary" 
                onClick={() => handleOpenModal('tariff')}
                className={`mt-4 ${selectedMode === 'commercial' ? 'bg-commercial-primary-500 hover:bg-commercial-primary-600' : 'bg-personal-primary-500 hover:bg-personal-primary-600'}`}
              >
                Открыть модалку
              </Button>
            </CardContent>
          </Card>

          <Card 
            variant="elevated" 
            hover 
            shadow="md"
            animation="bounce-subtle"
            className={`border-l-4 ${selectedMode === 'personal' ? 'border-l-personal-primary-500' : 'border-l-commercial-primary-500'}`}
          >
            <CardContent className="p-6">
              <CardHeader
                title="Сессия"
                description="Детальная информация о сессии зарядки с временной шкалой"
                icon={<BatteryCharging className="h-6 w-6 text-brand" />}
                size="sm"
              />
              <Button 
                variant="primary" 
                onClick={() => handleOpenModal('session')}
                className="mt-4"
              >
                Открыть модалку
              </Button>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Buttons Section */}
      <section id="buttons" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Кнопки
        </h2>
        <SmartGrid minColumnWidth={400} maxColumns={2} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="elevated" hover shadow="sm">
            <CardHeader title="Варианты кнопок" />
            <CardContent className="space-y-6">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                <div className="flex flex-wrap" style={{ gap: '20px' }}>
                  <Button variant="primary" className={tokens.primary}>Основная</Button>
                  <Button variant="secondary" className={tokens.secondary}>Вторичная</Button>
                  <Button variant="outline">Контурная</Button>
                  <Button variant="ghost">Призрачная</Button>
                  <Button variant="danger">Опасность</Button>
                  <Button variant="gradient">Градиент</Button>
                </div>
                <div className="flex flex-wrap" style={{ gap: '20px' }}>
                  <Button size="xs">Очень малая</Button>
                  <Button size="sm">Маленькая</Button>
                  <Button size="md">Средняя</Button>
                  <Button size="lg">Большая</Button>
                  <Button size="xl">Очень большая</Button>
                </div>
                <div className="flex flex-wrap" style={{ gap: '20px' }}>
                  <Button icon={Check} iconPosition="left">С иконкой</Button>
                  <Button icon={ArrowRight} iconPosition="right">С иконкой</Button>
                  <Button icon={Plus} iconPosition="only" aria-label="Добавить" />
                  <Button loading>Загрузка</Button>
                  <Button disabled>Отключена</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" hover shadow="sm" animation="fade-in">
            <CardHeader title="Интерактивная демонстрация" />
            <CardContent style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div className="flex flex-wrap" style={{ gap: '12px' }}>
                  {(['primary', 'secondary', 'outline', 'ghost', 'danger', 'gradient'] as const).map((variant) => (
                    <Button
                      key={variant}
                      variant={variant}
                      size="sm"
                      onClick={() => setSelectedVariant(variant)}
                      className={selectedVariant === variant ? 'ring-2 ring-brand ring-offset-2' : ''}
                    >
                      {variant}
                    </Button>
                  ))}
                </div>
                <Button
                  variant={selectedVariant}
                  size="lg"
                  loading={isLoading}
                  icon={isLoading ? undefined : Zap}
                  iconPosition="left"
                  onClick={handleSimulateLoading}
                  className={selectedVariant === 'primary' ? tokens.primary : ''}
                >
                  {isLoading ? 'Загрузка...' : 'Нажми меня'}
                </Button>
              </div>
              <p className="text-body-sm text-muted">
                Выбран вариант: <span className="font-semibold text-ink">{selectedVariant}</span>
              </p>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Button Groups & FAB Section */}
      <section id="button-groups" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Группы кнопок и FAB
        </h2>
        <SmartGrid minColumnWidth={300} maxColumns={2} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="elevated" hover shadow="sm">
            <CardHeader title="Группы кнопок" />
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="text-sm font-medium text-muted">Горизонтальная группа</div>
                <div className="flex" style={{ gap: '8px' }}>
                  <Button variant="secondary" className="rounded-r-none">Левая</Button>
                  <Button variant="secondary" className="rounded-none">Средняя</Button>
                  <Button variant="secondary" className="rounded-l-none">Правая</Button>
                </div>
                
                <div className="text-sm font-medium text-muted">Вертикальная группа</div>
                <div className="flex flex-col w-fit" style={{ gap: '8px' }}>
                  <Button variant="secondary" className="rounded-b-none">Верхняя</Button>
                  <Button variant="secondary" className="rounded-none">Средняя</Button>
                  <Button variant="secondary" className="rounded-t-none">Нижняя</Button>
                </div>
                
                <div className="text-sm font-medium text-muted">Группа с разными вариантами</div>
                <div className="flex" style={{ gap: '8px' }}>
                  <Button variant="primary" className="rounded-r-none">Сохранить</Button>
                  <Button variant="outline" className="rounded-none">Предпросмотр</Button>
                  <Button variant="ghost" className="rounded-l-none">Отмена</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" hover shadow="sm" animation="fade-in">
            <CardHeader title="FAB и специальные кнопки" />
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex flex-wrap items-center" style={{ gap: '16px' }}>
                  <Button variant="fab" icon={Plus} size="lg" />
                  <Button variant="fab" icon={Edit} size="md" />
                  <Button variant="fab" icon={Trash2} size="sm" />
                </div>
                
                <div className="text-sm font-medium text-muted">Кнопки с анимацией</div>
                <div className="flex flex-wrap" style={{ gap: '12px' }}>
                  <Button variant="primary" animation="pulse">Пульсация</Button>
                  <Button variant="secondary" animation="bounce-subtle">Подскок</Button>
                  <Button variant="gradient" animation="float">Плавание</Button>
                </div>
                
                <div className="text-sm font-medium text-muted">Кнопки с тенями</div>
                <div className="flex flex-wrap" style={{ gap: '12px' }}>
                  <Button variant="primary" shadow="sm">Тень sm</Button>
                  <Button variant="primary" shadow="md">Тень md</Button>
                  <Button variant="primary" shadow="lg">Тень lg</Button>
                  <Button variant="primary" shadow="xl">Тень xl</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Loading States & Skeletons Section */}
      <section id="loading" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Состояния загрузки и скелетоны
        </h2>
        <SmartGrid minColumnWidth={200} maxColumns={2} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="elevated" hover shadow="sm">
            <CardHeader title="Типы скелетонов" />
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Текстовые скелетоны</p>
                <Skeleton variant="text" width="100%" animation="wave" />
                <Skeleton variant="text" width="80%" animation="wave" />
                <Skeleton variant="text" width="60%" animation="wave" />
              </div>
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Круглые и прямоугольные</p>
                <div className="flex space-x-4">
                  <Skeleton variant="avatar" animation="wave" />
                  <Skeleton variant="circular" width={60} height={60} animation="wave" />
                  <Skeleton variant="rectangular" width={80} height={60} animation="wave" />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Элементы интерфейса</p>
                <div className="flex flex-wrap gap-2">
                  <Skeleton variant="button" animation="wave" />
                  <Skeleton variant="input" animation="wave" />
                  <Skeleton variant="button" width="8rem" animation="wave" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" hover shadow="sm" animation="fade-in">
            <CardHeader title="Анимации загрузки" />
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Типы анимаций</p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Skeleton variant="text" width="40%" animation="pulse" />
                    <span className="text-caption text-muted">Пульсация</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Skeleton variant="text" width="40%" animation="wave" />
                    <span className="text-caption text-muted">Волна</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Skeleton variant="text" width="40%" animation="shimmer" />
                    <span className="text-caption text-muted">Сияние</span>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Группы скелетонов</p>
                <Skeleton variant="text" count={3} spacing="md" animation="wave" />
              </div>
              <div className="space-y-2">
                <p className="text-body-sm font-medium text-ink">Компоненты скелетонов</p>
                <div className="space-y-4">
                  <MetricCardSkeleton variant="compact" />
                  <div className="flex gap-2">
                    <Skeleton variant="button" animation="wave" />
                    <Skeleton variant="button" animation="wave" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Status Badges Section */}
      <section id="status" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Статусные бейджи
        </h2>
        <SmartGrid minColumnWidth={150} maxColumns={5} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="elevated" hover shadow="sm" className="h-full">
            <CardContent className="p-6 text-center space-y-2">
              <StatusBadge status="success" label="Готова" />
              <p className="text-caption text-muted">Успех</p>
            </CardContent>
          </Card>
          <Card variant="elevated" hover shadow="sm" className="h-full">
            <CardContent className="p-6 text-center space-y-2">
              <StatusBadge status="warning" label="Ожидание" />
              <p className="text-caption text-muted">Предупреждение</p>
            </CardContent>
          </Card>
          <Card variant="elevated" hover shadow="sm" className="h-full">
            <CardContent className="p-6 text-center space-y-2">
              <StatusBadge status="danger" label="Неисправность" />
              <p className="text-caption text-muted">Ошибка</p>
            </CardContent>
          </Card>
          <Card variant="elevated" hover shadow="sm" className="h-full">
            <CardContent className="p-6 text-center space-y-2">
              <StatusBadge status="info" label="Заряжает" />
              <p className="text-caption text-muted">Информация</p>
            </CardContent>
          </Card>
          <Card variant="elevated" hover shadow="sm" className="h-full">
            <CardContent className="p-6 text-center space-y-2">
              <StatusBadge status="offline" label="Оффлайн" />
              <p className="text-caption text-muted">Нейтральный</p>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Form Components Section */}
      <section id="forms" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Формы и поля ввода
        </h2>
        <SmartGrid minColumnWidth={200} maxColumns={2} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="filled">
            <CardHeader title="Поля ввода" />
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-muted mb-2">
                  Текстовое поле
                </label>
                <input
                  type="text"
                  className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                  placeholder="Введите текст"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted mb-2">
                  Выпадающий список
                </label>
                <select
                  className={`w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 ${tokens.focus}`}
                >
                  <option value="">Выберите опцию</option>
                  <option value="1">Опция 1</option>
                  <option value="2">Опция 2</option>
                  <option value="3">Опция 3</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted mb-2">
                  Чекбоксы
                </label>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="checkbox1" className="rounded" />
                    <label htmlFor="checkbox1" className="text-sm text-ink">
                      Чекбокс 1
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="checkbox2" className="rounded" />
                    <label htmlFor="checkbox2" className="text-sm text-ink">
                      Чекбокс 2
                    </label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="filled">
            <CardHeader title="Валидация форм" />
            <CardContent className="space-y-4">
              <div className="relative">
                <label className="block text-sm font-medium text-muted mb-2">
                  Поле с ошибкой
                </label>
                <input
                  type="text"
                  className="w-full bg-bg-2 border border-danger rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-danger"
                  placeholder="Это поле содержит ошибку"
                  aria-describedby="error-message"
                />
                <p id="error-message" className="mt-1 text-xs text-danger">
                  Это поле обязательно для заполнения
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted mb-2">
                  Успешная валидация
                </label>
                <input
                  type="text"
                  className="w-full bg-bg-2 border border-success rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-success"
                  placeholder="Валидация пройдена"
                />
                <p className="mt-1 text-xs text-success">
                  ✓ Валидация пройдена успешно
                </p>
              </div>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Data Tables Preview */}
      <section id="tables" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Таблицы данных
        </h2>
        <Card variant="filled">
          <CardHeader 
            title="Пример таблицы станций" 
            description="Демонстрация табличного представления данных"
          />
          <CardContent className="xl:p-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-bg-2">
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">ID</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">Название</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">Статус</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">Мощность</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted">Действия</th>
                  </tr>
                </thead>
                <tbody>
                  {mockStations.slice(0, 3).map((station) => (
                    <tr key={station.id} className="border-b border-bg-1 hover:bg-bg-2">
                      <td className="py-3 px-4 text-sm text-ink">{station.id}</td>
                      <td className="py-3 px-4 text-sm text-ink">{station.name}</td>
                      <td className="py-3 px-4">
                        <StatusBadge status={station.status === 'ready' ? 'success' : 'warning'} label={station.status} />
                      </td>
                      <td className="py-3 px-4 text-sm text-ink">{station.power} кВт</td>
                      <td className="py-3 px-4">
                        <div className="flex" style={{ gap: '8px' }}>
                          <Button variant="ghost" size="sm" icon={Eye} />
                          <Button variant="ghost" size="sm" icon={Edit} />
                          <Button variant="ghost" size="sm" icon={Trash2} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Metric Cards Section */}
      <section id="metrics" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Метрики и карточки данных
        </h2>
        <SmartGrid minColumnWidth={190} maxColumns={5} gap="md" matchHeights={true} mobileOptimization={true}>
          <div className="bg-bg-1 border border-bg-2 rounded-xl p-5 xl:p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-brand/10">
                <Zap className="h-6 w-6 text-brand" />
              </div>
              <div>
                <h3 className="text-heading-sm font-semibold text-ink">Энергия сегодня</h3>
                <p className="text-body-sm text-muted">По сравнению со вчера</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-display-sm font-bold text-ink">142.5</span>
              <span className="text-body-sm text-muted">кВт·ч</span>
            </div>
            <div className="mt-2 flex items-center gap-1">
              <span className="text-success text-sm font-medium">↑ 12.5%</span>
            </div>
          </div>
          
          <div className="bg-bg-1 border border-bg-2 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-brand/10">
                <Battery className="h-6 w-6 text-brand" />
              </div>
              <div>
                <h3 className="text-heading-sm font-semibold text-ink">Активные станции</h3>
                <p className="text-body-sm text-muted">Всего станций в сети</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-display-sm font-bold text-ink">8</span>
              <span className="text-body-sm text-muted">из 12</span>
            </div>
            <div className="mt-2 flex items-center gap-1">
              <span className="text-muted text-sm font-medium">Стабильно</span>
            </div>
          </div>
          
          <div className="bg-bg-1 border border-bg-2 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-brand/10">
                <Clock className="h-6 w-6 text-brand" />
              </div>
              <div>
                <h3 className="text-heading-sm font-semibold text-ink">Средняя сессия</h3>
                <p className="text-body-sm text-muted">Средняя длительность</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-display-sm font-bold text-ink">2.8</span>
              <span className="text-body-sm text-muted">ч</span>
            </div>
            <div className="mt-2 flex items-center gap-1">
              <span className="text-warning text-sm font-medium">↓ 5.2%</span>
            </div>
          </div>
          
          <div className="bg-bg-1 border border-bg-2 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-brand/10">
                <DollarSign className="h-6 w-6 text-brand" />
              </div>
              <div>
                <h3 className="text-heading-sm font-semibold text-ink">Доход сегодня</h3>
                <p className="text-body-sm text-muted">Общая выручка</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-display-sm font-bold text-ink">$1,245</span>
              <span className="text-body-sm text-muted">USD</span>
            </div>
            <div className="mt-2 flex items-center gap-1">
              <span className="text-success text-sm font-medium">↑ 18.3%</span>
            </div>
          </div>
        </SmartGrid>
      </section>

      {/* Accessibility Examples */}
      <section id="accessibility" className="mb-12 scroll-mt-20">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Доступность (Accessibility)
        </h2>
        <Card variant="filled">
          <CardContent className="p-6 xl:p-8">
            <div className="flex items-start gap-4">
              <Info className="h-6 w-6 text-brand flex-shrink-0" />
              <div>
                <h3 className="text-heading-sm font-semibold text-ink mb-2">
                  ARIA атрибуты и доступность
                </h3>
                <div className="space-y-4">
                  <p className="text-body-sm text-muted">
                    Все компоненты разработаны с учетом доступности. Вот ключевые примеры:
                  </p>
                  <ul className="space-y-2 text-body-sm text-muted">
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                      <span><strong>ARIA-label:</strong> Все интерактивные элементы имеют описательные метки</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                      <span><strong>Клавиатурная навигация:</strong> Полная поддержка Tab, Enter, Space, Escape</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                      <span><strong>Контрастность:</strong> Все цвета соответствуют WCAG 2.1 AA (4.5:1)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                      <span><strong>Фокус-менеджмент:</strong> Правильное управление фокусом в модальных окнах</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                      <span><strong>Семантический HTML:</strong> Использование правильных HTML-тегов</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Mode Comparison */}
      <section className="mb-12">
        <h2 className="text-heading-md xl:text-heading-lg font-semibold text-ink mb-6 xl:mb-8">
          Сравнение режимов
        </h2>
        <SmartGrid minColumnWidth={300} maxColumns={2} gap="lg" matchHeights={true} mobileOptimization={true}>
          <Card variant="filled" className={`border-l-4 ${selectedMode === 'personal' ? 'border-l-personal-primary-500' : 'border-l-commercial-primary-500'}`}>
            <CardContent className="p-6 xl:p-8">
              <div className="flex items-center gap-3 mb-4">
                <User className="h-8 w-8 text-personal-primary-500" />
                <div>
                  <h3 className="text-heading-sm font-semibold text-ink">Персональный режим</h3>
                  <p className="text-body-sm text-muted">Для индивидуальных пользователей</p>
                </div>
              </div>
              <ul className="space-y-2 text-body-sm text-muted">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Упрощенный интерфейс</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Основные метрики зарядки</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Личная статистика</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Управление одной станцией</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card variant="filled" className={`border-l-4 ${selectedMode === 'personal' ? 'border-l-personal-primary-500' : 'border-l-commercial-primary-500'}`}>
            <CardContent className="p-6 xl:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Building className="h-8 w-8 text-commercial-primary-500" />
                <div>
                  <h3 className="text-heading-sm font-semibold text-ink">Коммерческий режим</h3>
                  <p className="text-body-sm text-muted">Для бизнес-операторов</p>
                </div>
              </div>
              <ul className="space-y-2 text-body-sm text-muted">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Расширенная аналитика</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Управление множеством станций</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Финансовые отчеты</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-success" />
                  <span>Настройка тарифов</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </SmartGrid>
      </section>

      {/* Footer Note */}
      <Card variant="outline" className="border-brand/20">
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center" style={{ gap: '8px' }}>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-brand" />
              <span className="text-sm font-medium text-ink">Дизайн-система CHARGE_admin</span>
            </div>
            <p className="text-body-sm text-muted max-w-2xl">
              Эта демонстрационная страница показывает все компоненты и паттерны дизайн-системы.
              Все компоненты адаптируются под выбранный режим (персональный/коммерческий) и соответствуют стандартам доступности.
            </p>
            <div className="flex items-center mt-4" style={{ gap: '16px' }}>
              <Button variant="ghost" size="sm" icon={ArrowRight} iconPosition="left" onClick={() => window.location.href = '/'}>
                Вернуться в приложение
              </Button>
              <Button variant="secondary" size="sm" icon={RefreshCw} iconPosition="left" onClick={handleSimulateLoading}>
                Обновить демонстрацию
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Render active modal */}
      {renderStationModal()}
      {renderTariffModal()}
      {renderSessionDetailsModal()}
    </div>
  );
};

export default UIShowcase;
