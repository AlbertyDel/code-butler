/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState } from 'react';
import type { ReactNode } from 'react';

export interface UserData {
  name: string;
  email: string;
  phone: string;
  role: string;
  company: string;
  location: string;
  joinDate: string;
  status: string;
  avatar: string;
  // Коммерческие данные
  organizationType?: string;
  inn?: string;
  ogrn?: string;
  bankAccount?: string;
  // Контактные лица
  responsiblePerson?: {
    name: string;
    position: string;
    phone: string;
    email: string;
  };
  technicalPerson?: {
    name: string;
    position: string;
    phone: string;
    email: string;
  };
  useSameAsResponsible?: boolean;
}

export interface UserContextType {
  userData: UserData;
  updateUserData: (updates: Partial<UserData>) => void;
}

const defaultUserData: UserData = {
  name: 'Александр Иванов',
  email: 'alex.ivanov@example.com',
  phone: '+7 (999) 123-45-67',
  role: 'Администратор',
  company: 'Зарядные сети России',
  location: 'Москва, Россия',
  joinDate: '15 марта 2024',
  status: 'active',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alexander',
};

export const UserContext = createContext<UserContextType | undefined>(undefined);

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [userData, setUserData] = useState<UserData>(() => {
    // Try to load from localStorage
    const saved = localStorage.getItem('userData');
    return saved ? JSON.parse(saved) : defaultUserData;
  });

  const updateUserData = (updates: Partial<UserData>) => {
    setUserData(prev => {
      const newData = { ...prev, ...updates };
      localStorage.setItem('userData', JSON.stringify(newData));
      return newData;
    });
  };

  return (
    <UserContext.Provider value={{ userData, updateUserData }}>
      {children}
    </UserContext.Provider>
  );
};
