/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';

export type Mode = 'personal' | 'commercial';

export interface ModeContextType {
  mode: Mode;
  setMode: (mode: Mode) => void;
}

export const ModeContext = createContext<ModeContextType | undefined>(undefined);

interface ModeProviderProps {
  children: ReactNode;
}

export const ModeProvider: React.FC<ModeProviderProps> = ({ children }) => {
  // Initialize mode from localStorage or default to 'personal'
  const [mode, setModeState] = useState<Mode>(() => {
    const savedMode = localStorage.getItem('charge-mode') as Mode;
    return savedMode === 'commercial' ? 'commercial' : 'personal';
  });

  // Persist mode to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('charge-mode', mode);
  }, [mode]);

  const setMode = (newMode: Mode) => {
    setModeState(newMode);
  };

  // Expose setMode globally for programmatic access
  useEffect(() => {
    // Extend Window interface to include our global function
    interface ExtendedWindow extends Window {
      __CHARGE_SET_MODE__?: (mode: Mode) => void;
    }
    
    (window as ExtendedWindow).__CHARGE_SET_MODE__ = setMode;
  }, []);

  return (
    <ModeContext.Provider value={{ mode, setMode }}>
      {children}
    </ModeContext.Provider>
  );
};
