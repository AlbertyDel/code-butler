import React from 'react';
import { StationStatusBadge } from '../ui/StatusBadge';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Eye, Edit, Trash2 } from 'lucide-react';
import type { Station } from '../../data/stations';
import { StationDetailView } from './StationDetailView';

/**
 * Presents a single EV charging station in a card format.
 * The card shows the station's status, name, ID, location, power, ports,
 * daily energy and assigned tariff. It also exposes actions to view
 * detailed information, edit the station or delete it. When the card
 * is in "viewing" mode it will render a detailed view beneath the summary.
 */
interface StationCardProps {
  station: Station;
  /** Flag indicating whether this station's details are currently expanded */
  isViewing: boolean;
  /** Called to toggle viewing on; parent maintains which station is expanded */
  onView: (station: Station) => void;
  /** Called to collapse the detail view */
  onCloseView: () => void;
  /** Called when the user chooses to edit this station */
  onEdit: (station: Station) => void;
  /** Called when the user chooses to delete this station */
  onDelete: (id: string) => void;
  /** Disable edit button (e.g., when another station is being edited/added) */
  isEditDisabled?: boolean;
  /** Disable delete button (e.g., when any operation is in progress) */
  isDeleteDisabled?: boolean;
  /** Disable view button (e.g., when any operation is in progress) */
  isViewDisabled?: boolean;
}

export const StationCard: React.FC<StationCardProps> = ({
  station,
  isViewing,
  onView,
  onCloseView,
  onEdit,
  onDelete,
  isEditDisabled = false,
  isDeleteDisabled = false,
  isViewDisabled = false,
}) => {
  return (
    <div className="space-y-4">
      <Card className="h-full">
        <CardContent className="p-5 space-y-4">
          {/* Header with status badge and station identifiers */}
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <StationStatusBadge status={station.status} />
              <div>
                <p className="font-medium text-ink truncate" title={station.name}>{station.name}</p>
                <p className="text-xs text-muted font-mono truncate" title={station.id}>{station.id}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {/* View/collapse button */}
              <Button
                variant="ghost"
                size="sm"
                icon={Eye}
                disabled={isViewDisabled}
                onClick={() => {
                  if (isViewing) {
                    onCloseView();
                  } else {
                    onView(station);
                  }
                }}
              >
                {isViewing ? 'Скрыть' : 'Просмотр'}
              </Button>
              {/* Edit button - hide when this station is being edited (showing edit form) */}
              {!isEditDisabled && (
                <Button 
                  variant="icon" 
                  size="sm" 
                  onClick={() => onEdit(station)}
                  disabled={isEditDisabled}
                >
                  <Edit size={16} />
                </Button>
              )}
              <Button 
                variant="icon" 
                size="sm" 
                onClick={() => onDelete(station.id)}
                disabled={isDeleteDisabled}
              >
                <Trash2 size={16} />
              </Button>
            </div>
          </div>
          {/* Main info grid */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-muted">Локация</p>
              <p className="text-sm text-ink truncate" title={station.location}>{station.location}</p>
            </div>
            <div>
              <p className="text-xs text-muted">Мощность</p>
              <p className="text-sm text-ink">{station.power} кВт</p>
            </div>
            <div>
              <p className="text-xs text-muted">Порты</p>
              <p className="text-sm text-ink">{station.ports}</p>
            </div>
            <div>
              <p className="text-xs text-muted">Энергия</p>
              <p className="text-sm text-ink">{station.energyToday} кВт·ч</p>
            </div>
            <div>
              <p className="text-xs text-muted">Тариф</p>
              <p className="text-sm text-ink">{station.tariffName || 'Не назначен'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* Conditionally render the detailed view below the card */}
      {isViewing && (
        <StationDetailView station={station} onClose={onCloseView} />
      )}
    </div>
  );
};