import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'icon' | 'outline' | 'gradient' | 'fab';
export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right' | 'only';
  fullWidth?: boolean;
  rounded?: 'sm' | 'md' | 'lg' | 'full';
  shadow?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  animation?: 'none' | 'pulse' | 'bounce-subtle' | 'float';
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon: Icon,
  iconPosition = 'left',
  fullWidth = false,
  rounded = 'md',
  shadow = 'none',
  animation = 'none',
  className,
  disabled,
  ...props
}) => {
  // Enhanced base classes with optimized transitions
  const baseClasses = 'inline-flex items-center justify-center font-medium transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transform-gpu origin-center will-change-transform motion-reduce:transition-none motion-reduce:transform-none';
  
  const variants = {
    primary: 'bg-mode-primary text-mode-button-primary-text hover:bg-mode-primary/90 active:bg-mode-primary/80 focus:ring-mode-primary hover:shadow-lg active:shadow-md active:scale-[0.98] transition-all duration-200 ease-out',
    secondary: 'bg-mode-button-secondary-bg text-mode-button-secondary-text hover:bg-mode-button-secondary-bg/80 active:bg-mode-button-secondary-bg/60 border border-mode-border hover:border-mode-border-strong hover:shadow-md active:shadow-sm active:scale-[0.98] transition-all duration-200 ease-out',
    danger: 'bg-danger text-white hover:bg-red-600 active:bg-red-700 focus:ring-danger hover:shadow-lg active:shadow-md active:scale-[0.98] transition-all duration-200 ease-out',
    ghost: 'text-mode-text-primary hover:bg-mode-surface-alt active:bg-mode-surface hover:shadow-sm active:scale-[0.98] transition-all duration-200 ease-out',
    outline: 'border-2 border-mode-primary text-mode-primary hover:bg-mode-primary/10 active:bg-mode-primary/20 focus:ring-mode-primary hover:shadow-md active:shadow-sm active:scale-[0.98] transition-all duration-200 ease-out',
    gradient: 'bg-gradient-personal text-white hover:opacity-95 active:opacity-85 focus:ring-brand hover:shadow-lg active:shadow-md active:scale-[0.98] transition-all duration-200 ease-out',
    icon: 'p-2 hover:bg-mode-surface-alt active:bg-mode-surface active:scale-[0.95] transition-all duration-200 ease-out',
    fab: 'rounded-full bg-mode-primary text-mode-button-primary-text shadow-xl hover:shadow-2xl hover:brightness-110 active:brightness-90 active:scale-[0.95] focus:ring-mode-primary transition-all duration-300 ease-out',
  };

  const sizes = {
    xs: 'px-2.5 py-1.5 text-xs min-h-[28px]',
    sm: 'px-3 py-2 text-sm min-h-[36px]',
    md: 'px-4 py-2.5 text-base min-h-[44px]',
    lg: 'px-6 py-3.5 text-lg min-h-[52px]',
    xl: 'px-8 py-4 text-xl min-h-[60px]',
    icon: 'p-3 min-w-[44px] min-h-[44px]',
    fab: 'p-4 min-w-[56px] min-h-[56px]',
  };

  const roundedClasses = {
    sm: 'rounded',
    md: 'rounded-lg',
    lg: 'rounded-xl',
    full: 'rounded-full',
  };

  const shadowClasses = {
    none: '',
    sm: 'shadow-sm',
    md: 'shadow-md',
    lg: 'shadow-lg',
    xl: 'shadow-xl',
  };

  const animationClasses = {
    none: '',
    pulse: 'animate-pulse-slow',
    'bounce-subtle': 'animate-bounce-subtle',
    float: 'animate-float',
  };

  const sizeClass = variant === 'icon' ? sizes.icon : variant === 'fab' ? sizes.fab : sizes[size];
  const isIconOnly = iconPosition === 'only' || (!children && Icon);

  return (
    <button
      className={cn(
        baseClasses,
        variants[variant],
        sizeClass,
        roundedClasses[rounded],
        shadowClasses[shadow],
        animationClasses[animation],
        fullWidth && 'w-full',
        loading && 'opacity-70 cursor-wait',
        isIconOnly && 'aspect-square',
        className
      )}
      disabled={disabled || loading}
      aria-label={isIconOnly && children ? String(children) : undefined}
      {...props}
    >
      {loading && (
        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      )}
      {!loading && Icon && (iconPosition === 'left' || isIconOnly) && (
        <Icon className={cn('h-4 w-4', !isIconOnly && 'mr-2')} />
      )}
      {!isIconOnly && children}
      {!loading && Icon && iconPosition === 'right' && !isIconOnly && (
        <Icon className="ml-2 h-4 w-4" />
      )}
    </button>
  );
};

// Button Group Component
interface ButtonGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  orientation?: 'horizontal' | 'vertical';
  spacing?: 'none' | 'sm' | 'md' | 'lg';
}

export const ButtonGroup: React.FC<ButtonGroupProps> = ({
  children,
  orientation = 'horizontal',
  spacing = 'md',
  className,
  ...props
}) => {
  const spacingClasses = {
    none: 'gap-0',
    sm: 'gap-2',  // Increased from gap-1 (4px) to gap-2 (8px)
    md: 'gap-3',  // Increased from gap-2 (8px) to gap-3 (12px)
    lg: 'gap-4',  // Increased from gap-3 (12px) to gap-4 (16px)
  };

  const orientationClasses = {
    horizontal: 'flex-row',
    vertical: 'flex-col',
  };

  return (
    <div
      className={cn(
        'flex',
        orientationClasses[orientation],
        spacingClasses[spacing],
        className
      )}
      role="group"
      {...props}
    >
      {React.Children.map(children, (child, index) => {
        if (React.isValidElement<ButtonProps>(child)) {
          return React.cloneElement(child, {
            className: cn(
              child.props.className,
              orientation === 'horizontal' && index > 0 && 'rounded-l-none',
              orientation === 'horizontal' && index < React.Children.count(children) - 1 && 'rounded-r-none',
              orientation === 'vertical' && index > 0 && 'rounded-t-none',
              orientation === 'vertical' && index < React.Children.count(children) - 1 && 'rounded-b-none'
            ),
          });
        }
        return child;
      })}
    </div>
  );
};
