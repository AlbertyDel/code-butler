import React from 'react';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { Battery, X } from 'lucide-react';
import { StationStatusBadge } from '../ui/StatusBadge';

interface Station {
  id: string;
  name: string;
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;
  location: string;
  tariffName?: string;
  ports: number;
  energyToday: number;
}

interface StationDetailViewProps {
  station: Station;
  onClose: () => void;
}

export const StationDetailView: React.FC<StationDetailViewProps> = ({
  station,
  onClose,
}) => {
  return (
    <Card className="mt-4 mb-6">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="h-12 w-12 rounded-lg bg-brand/10 flex items-center justify-center">
              <Battery className="h-6 w-6 text-brand" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-ink">Детальный вид станции</h3>
              <p className="text-sm text-muted">Просмотр данных станции: {station.name}</p>
            </div>
          </div>
          <StationStatusBadge status={station.status} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Левая колонка - основные данные */}
          <div className="space-y-6">
            <div>
              <p className="text-sm font-medium text-muted mb-2">Название станции</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                {station.name}
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted mb-2">ID станции</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink font-mono">
                {station.id}
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted mb-2">Локация</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                {station.location}
              </div>
            </div>
          </div>

          {/* Правая колонка - характеристики */}
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted mb-2">Мощность</p>
                <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                  {station.power} кВт
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted mb-2">Количество портов</p>
                <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                  {station.ports} порт(а)
                </div>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted mb-2">Статус</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                {station.status === 'ready' && 'Готова'}
                {station.status === 'charging' && 'Заряжает'}
                {station.status === 'offline' && 'Оффлайн'}
                {station.status === 'pending' && 'Ожидание'}
                {station.status === 'fault' && 'Неисправность'}
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted mb-2">Энергия сегодня</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                {station.energyToday} кВт·ч
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted mb-2">Тариф</p>
              <div className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-3 text-ink">
                {station.tariffName || 'Не назначен'}
              </div>
            </div>
          </div>
        </div>

        {/* Кнопка закрытия */}
        <div className="pt-6 border-t border-bg-2 flex justify-end">
          <Button variant="secondary" onClick={onClose} icon={X}>
            Закрыть
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
