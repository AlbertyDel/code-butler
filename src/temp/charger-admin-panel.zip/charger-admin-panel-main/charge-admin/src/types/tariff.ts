export interface TariffRule {
  id: string;
  days: number[] | 'all'; // 0-6 (Пн-Вс), 'all' для всех дней
  startTime: string; // "HH:MM"
  endTime: string; // "HH:MM"
  pricePerKwh: number;
}

export interface SessionLimits {
  maxTime: number; // 0 = без ограничений
  maxEnergy: number; // 0 = без ограничений (в кВт*ч)
}

export interface Tariff {
  name: string; // уникальный идентификатор
  description: string;
  basePricePerKwh: number;
  rules: TariffRule[];
  sessionLimits: SessionLimits;
  createdAt: string;
  updatedAt?: string;
  isActive?: boolean;
}

export interface TariffFormData {
  name: string;
  description: string;
  basePricePerKwh: number;
  rules: TariffRule[];
  sessionLimits: SessionLimits;
}

// Дни недели для отображения
export const WEEK_DAYS = [
  { id: 0, label: 'Пн', fullLabel: 'Понедельник' },
  { id: 1, label: 'Вт', fullLabel: 'Вторник' },
  { id: 2, label: 'Ср', fullLabel: 'Среда' },
  { id: 3, label: 'Чт', fullLabel: 'Четверг' },
  { id: 4, label: 'Пт', fullLabel: 'Пятница' },
  { id: 5, label: 'Сб', fullLabel: 'Суббота' },
  { id: 6, label: 'Вс', fullLabel: 'Воскресенье' },
];

// Временные интервалы для выбора
export const TIME_INTERVALS = Array.from({ length: 24 * 4 }, (_, i) => {
  const hours = Math.floor(i / 4);
  const minutes = (i % 4) * 15;
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
});

// Утилиты для работы с тарифами
export const generateRuleId = (): string => {
  return `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const validateTimeRange = (startTime: string, endTime: string): boolean => {
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startTotal = startHours * 60 + startMinutes;
  const endTotal = endHours * 60 + endMinutes;
  
  return startTotal < endTotal;
};

export const normalizeTimeRange = (
  startTime: string, 
  endTime: string
): { startTime: string; endTime: string; wasSwapped: boolean } => {
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startTotal = startHours * 60 + startMinutes;
  const endTotal = endHours * 60 + endMinutes;
  
  // If start time is later than end time, swap them
  if (startTotal > endTotal) {
    return { startTime: endTime, endTime: startTime, wasSwapped: true };
  }
  
  return { startTime, endTime, wasSwapped: false };
};

export const checkRuleOverlap = (
  rule1: TariffRule,
  rule2: TariffRule
): boolean => {
  // Проверяем пересечение дней
  const days1 = rule1.days === 'all' ? [0, 1, 2, 3, 4, 5, 6] : rule1.days;
  const days2 = rule2.days === 'all' ? [0, 1, 2, 3, 4, 5, 6] : rule2.days;
  
  const hasDayOverlap = days1.some(day => days2.includes(day));
  if (!hasDayOverlap) return false;
  
  // Проверяем пересечение времени
  const [start1Hours, start1Minutes] = rule1.startTime.split(':').map(Number);
  const [end1Hours, end1Minutes] = rule1.endTime.split(':').map(Number);
  const [start2Hours, start2Minutes] = rule2.startTime.split(':').map(Number);
  const [end2Hours, end2Minutes] = rule2.endTime.split(':').map(Number);
  
  const start1 = start1Hours * 60 + start1Minutes;
  const end1 = end1Hours * 60 + end1Minutes;
  const start2 = start2Hours * 60 + start2Minutes;
  const end2 = end2Hours * 60 + end2Minutes;
  
  return !(end1 <= start2 || end2 <= start1);
};

export const formatRuleDescription = (rule: TariffRule): string => {
  if (rule.days === 'all') {
    return `Все дни, ${rule.startTime}-${rule.endTime}: ${rule.pricePerKwh} руб/кВт*ч`;
  }
  
  const dayLabels = rule.days.map(day => WEEK_DAYS[day].label).join(', ');
  return `${dayLabels}, ${rule.startTime}-${rule.endTime}: ${rule.pricePerKwh} руб/кВт*ч`;
};

export const getDefaultTariff = (basePrice: number): TariffFormData => ({
  name: '',
  description: '',
  basePricePerKwh: basePrice,
  rules: [],
  sessionLimits: {
    maxTime: 0,
    maxEnergy: 0,
  },
});

export const copyTariff = (tariff: Tariff, existingNames: string[]): TariffFormData => {
  // Генерируем уникальное имя
  const baseName = tariff.name.replace(/\(\d+\)$/, '').trim();
  let copyNumber = 1;
  let newName = `${baseName} (${copyNumber})`;
  
  while (existingNames.includes(newName)) {
    copyNumber++;
    newName = `${baseName} (${copyNumber})`;
  }
  
  return {
    name: newName,
    description: tariff.description,
    basePricePerKwh: tariff.basePricePerKwh,
    rules: tariff.rules.map(rule => ({
      ...rule,
      id: generateRuleId(),
    })),
    sessionLimits: { ...tariff.sessionLimits },
  };
};
