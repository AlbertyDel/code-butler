# CHARGE_admin Technical Context

## Technologies Used

### Core Framework & Libraries
- **React 19.2.0**: Latest React version with concurrent features and improved performance
- **TypeScript 5.5.4**: Type-safe development with strict type checking
- **Vite 7.2.5 (Rolldown-based)**: Fast build tool and development server with hot module replacement
- **React Router DOM 7.11.0**: Client-side routing with lazy loading and protected routes
- **Tailwind CSS 4.1.18**: Utility-first CSS framework with JIT compilation
- **Lucide React 0.469.0**: Icon library with consistent design and tree-shaking support
- **Recharts 2.12.0**: Charting library for data visualization (energy charts)

### Development Tools
- **ESLint**: Code linting with TypeScript and React Hooks rules
- **PostCSS 8.4.47**: CSS processing with Autoprefixer
- **@faker-js/faker 9.4.0**: Mock data generation with Russian locale support
- **npm**: Package management and script execution

### Key Dependencies and Their Roles
- **State Management**: React Context API (no additional state management libraries)
- **Routing**: React Router with lazy loading and protected route components
- **Styling**: Tailwind CSS with custom design tokens and PostCSS for vendor prefixes
- **Icons**: Lucide React for consistent iconography across the application
- **Charts**: Recharts for energy consumption visualization
- **Mock Data**: @faker-js/faker for deterministic mock data generation

## Development Setup

### Prerequisites
- **Node.js**: Version 18 or higher (LTS recommended)
- **npm**: Version 10 or higher (comes with Node.js)
- **Code Editor**: VS Code with recommended extensions (ESLint, Prettier, Tailwind CSS IntelliSense)

### Installation and Setup
```bash
# Clone the repository (if applicable)
# Navigate to charge-admin directory
cd charge-admin

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Run linter
npm run lint

# Preview production build locally
npm run preview
```

### Project Structure
```
charge-admin/
├── public/                    # Static assets
├── src/
│   ├── assets/               # Images, fonts, etc.
│   ├── components/           # Reusable UI components
│   │   ├── layout/          # Layout components (DesktopLayout, MobileLayout, ResponsiveLayout)
│   │   ├── station/         # Station-related components
│   │   ├── tariff/          # Tariff-related components
│   │   └── ui/              # Base UI components (Button, Card, StatusBadge, etc.)
│   ├── contexts/            # React Context providers
│   │   ├── ModeContext.tsx    # Application mode (personal/commercial)
│   │   ├── UserContext.tsx    # User profile data
│   │   ├── TariffContext.tsx  # Tariff management
│   │   └── FinanceContext.tsx # Financial operations
│   ├── data/                # Mock data modules
│   │   ├── stations.ts      # Default station data
│   │   ├── tariffs.ts       # Default tariff data
│   │   ├── sessions.ts      # Default session data
│   │   ├── finance.ts       # Default finance data
│   │   ├── dashboard.ts     # Dashboard KPI data
│   │   ├── user.ts          # Default user data
│   │   └── index.ts         # Aggregated exports
│   ├── hooks/               # Custom React hooks
│   │   ├── useMediaQuery.ts    # Media query hook for responsive design
│   │   └── usePersistentData.ts # LocalStorage persistence hook
│   ├── pages/               # Page components (routes)
│   │   ├── Dashboard.tsx   # Dual-mode dashboard
│   │   ├── Stations.tsx    # Station management
│   │   ├── Sessions.tsx    # Session history
│   │   ├── Tariffs.tsx     # Tariff management (commercial only)
│   │   ├── Finance.tsx     # Financial operations (commercial only)
│   │   └── Profile.tsx     # User profile
│   ├── types/               # TypeScript type definitions
│   │   ├── tariff.ts       # Tariff interfaces
│   │   └── finance.ts      # Finance interfaces
│   ├── utils/               # Utility functions
│   │   ├── cn.ts           # Classname utility (Tailwind class merging)
│   │   └── resetLocalStorage.ts # Utility to reset localStorage data
│   ├── App.tsx             # Root component with routing and context providers
│   ├── main.tsx            # Application entry point
│   └── index.css           # Global styles and Tailwind directives
├── package.json            # Dependencies and scripts
├── vite.config.ts          # Vite configuration
├── tailwind.config.cjs     # Tailwind CSS configuration
├── tsconfig.json           # TypeScript base configuration
├── tsconfig.app.json       # TypeScript configuration for app
├── tsconfig.node.json      # TypeScript configuration for Node (build tools)
└── README.md               # Project documentation
```

### Configuration Files

**Tailwind CSS Configuration (tailwind.config.cjs)**:
```javascript
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#12B76A',    // Primary brand color (green)
          light: '#D1FADF',      // Light variant
          dark: '#0E9957',       // Dark variant
          hover: '#49C584',      // Hover state
          active: '#2E8E5F',     // Active state
        },
        info: '#2E90FA',         // Informational color
        warning: '#F79009',      // Warning color
        success: '#039855',      // Success color
        error: '#EF4444',        // Error color
        ink: '#101828',          // Primary text color
        muted: '#667085',        // Secondary/muted text color
        bg1: '#F9FAFB',          // Background level 1
        bg2: '#FFFFFF',          // Background level 2 (cards, etc.)
      },
    },
  },
  plugins: [],
};
```

**Vite Configuration (vite.config.ts)**:
```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
});
```

**TypeScript Configuration**:
- **tsconfig.json**: Base configuration with path aliases and compiler options
- **tsconfig.app.json**: Application-specific configuration for React
- **tsconfig.node.json**: Node-specific configuration for build tools

## Technical Constraints

### Browser Support
- **Target Browsers**: Modern browsers with ES6+ support (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)
- **Polyfills**: Limited polyfills (rely on browser native support for modern APIs)
- **Mobile Support**: Responsive design tested on iOS Safari and Chrome for Android

### Performance Constraints
- **Bundle Size**: Target under 500KB for initial load (gzipped)
- **Load Time**: <3 seconds on average 3G connections
- **Interaction Response**: <100ms for user interactions
- **Memory Usage**: Stable memory footprint without leaks

### Storage Constraints
- **LocalStorage**: Primary persistence mechanism with 5-10MB limit per domain
- **Data Structure**: JSON serialization for complex objects
- **Fallback Strategy**: Mock data when localStorage is empty or corrupted

## Development Workflow

### Code Quality Standards
- **TypeScript Strictness**: `strict: true` in tsconfig with minimal `any` usage
- **ESLint Rules**: React Hooks rules, TypeScript compatibility, import ordering
- **Code Formatting**: Prettier via editor integration with project-specific settings
- **Commit Conventions**: Conventional commits with semantic versioning

### Current Code Quality Issues
The project has 3 ESLint errors that need immediate attention:

1. **MobileLayout.tsx line 29:57**:
   - **Issue**: `extraNavigationItems: Array<{ name: string; icon: any; path: string }> = [];`
   - **Problem**: Using `any` type for icon prop reduces type safety
   - **Fix**: Replace `any` with proper type: `icon: LucideIcon`

2. **InlineStationEditForm.tsx line 32:5**:
   - **Issue**: `setFormData(station);` in `useEffect` without dependencies
   - **Problem**: Causes unnecessary re-renders and potential infinite loops
   - **Fix**: Add dependency array: `useEffect(() => { setFormData(station); }, [station]);`

3. **StationForm.tsx line 48:19**:
   - **Issue**: `tariffName: tariffs.length > 0 ? tariffs[0].name : '',` where `tariffs` is used before declaration
   - **Problem**: Hook call order violation - using hook value before hook is called
   - **Fix**: Move `const { tariffs } = useTariff();` above the useState initialization

### Testing Approach
- **Unit Testing**: Planned for utilities and hooks (not yet implemented)
- **Integration Testing**: Manual testing of component interactions
- **Browser Testing**: Cross-browser testing on major browsers
- **Performance Testing**: Bundle size analysis and load time monitoring

### Build and Deployment
- **Development Server**: Vite dev server with HMR on `localhost:5173`
- **Production Build**: Optimized build with code splitting and asset optimization
- **Preview Mode**: Local preview of production build before deployment
- **Deployment Target**: Static hosting (Netlify, Vercel, GitHub Pages, etc.)

## Tool Usage Patterns

### React Patterns
- **Functional Components**: All components are function components with hooks
- **Custom Hooks**: `usePersistentData`, `useMediaQuery` for reusable logic
- **Context Providers**: Domain-specific contexts for state management
- **Lazy Loading**: Route-based code splitting for performance

### Styling Patterns
- **Tailwind Utility Classes**: Primary styling approach with custom design tokens
- **CSS Custom Properties**: Design tokens exposed as CSS variables for consistency
- **Component Variants**: Standardized variant system (primary, secondary, etc.)
- **Responsive Design**: Mobile-first breakpoints with Tailwind responsive prefixes

### State Management Patterns
- **Local State**: `useState` for component-specific state
- **Lifted State**: State lifted to parent components when shared
- **Context State**: `useContext` for global state with localStorage persistence
- **Form State**: Controlled components with React state management

### Data Persistence Patterns
- **LocalStorage Integration**: Automatic persistence via `usePersistentData` hook
- **Key Namespacing**: `charge_admin_` prefix for localStorage keys
- **Data Normalization**: Validation and correction on load (e.g., `normalizeStations`)
- **Mock Data Fallback**: Deterministic mock data when no user data exists

## Integration Points

### Current Integrations
- **Lucide React Icons**: Icon library integrated with component system
- **Recharts**: Charting library for energy consumption visualization
- **Faker.js**: Mock data generation for development and demonstration
- **React Router**: Client-side routing with protected routes

### Planned Integrations
- **Backend API**: REST API or GraphQL for data persistence
- **Authentication**: OAuth2/OpenID Connect for user authentication
- **Real-time Updates**: WebSocket connections for live station status
- **Payment Processing**: Stripe or similar for financial transactions
- **Mapping Services**: Google Maps or OpenStreetMap for station locations

## Development Environment

### VS Code Configuration
```json
{
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "typescript.preferences.importModuleSpecifier": "shortest",
  "tailwindCSS.experimental.classRegex": [
    ["cn\\(([^)]*)\\)", "'([^']*)'"]
  ]
}
```

### Recommended Extensions
- **ESLint**: Integrates ESLint into VS Code
- **Prettier**: Code formatter
- **Tailwind CSS IntelliSense**: Autocomplete for Tailwind classes
- **TypeScript Vue Plugin (Volar)**: TypeScript support for Vue (if needed)
- **GitLens**: Git blame and history

### Debugging Tools
- **React DevTools**: Component tree and state inspection
- **Redux DevTools**: Context state inspection (compatible with React Context)
- **Browser DevTools**: Network, performance, and storage inspection
- **Vite DevTools**: Build and HMR debugging

## Performance Optimization

### Build Optimizations
- **Code Splitting**: Route-based lazy loading
- **Tree Shaking**: Unused code elimination via ES modules
- **Asset Optimization**: Image compression and SVG optimization
- **Minification**: JavaScript and CSS minification

### Runtime Optimizations
- **Memoization**: `React.memo`, `useMemo`, `useCallback` for expensive operations
- **Virtualization**: Planned for large lists (not yet implemented)
- **Image Optimization**: Lazy loading and responsive images
- **Bundle Analysis**: Regular bundle size monitoring

### Caching Strategy
- **Service Workers**: Planned for PWA capabilities (not yet implemented)
- **LocalStorage Cache**: Data persistence across sessions
- **Browser Cache**: Static asset caching via HTTP headers

## Security Considerations

### Frontend Security
- **XSS Protection**: React's built-in XSS protection via JSX
- **Data Validation**: Client-side validation for all user inputs
- **LocalStorage Security**: No sensitive data stored in localStorage (planned for backend integration)
- **HTTPS Requirement**: All deployments should use HTTPS

### Privacy Considerations
- **Data Localization**: User data stored locally by default
- **No Tracking**: No analytics or user tracking in current implementation
- **Transparent Data Usage**: Clear data persistence indicators

## Maintenance and Updates

### Dependency Management
- **Regular Updates**: Monthly dependency updates with compatibility testing
- **Security Patches**: Immediate updates for security vulnerabilities
- **Version Locking**: Exact versions in package.json for reproducibility

### Documentation
- **Code Comments**: Inline documentation for complex logic
- **TypeScript Types**: Comprehensive type definitions as documentation
- **Memory Bank**: Project documentation in markdown files
- **Component Documentation**: Storybook planned for future (not yet implemented)

### Monitoring and Alerts
- **Error Tracking**: Planned integration with error tracking service (Sentry, etc.)
- **Performance Monitoring**: Real User Monitoring (RUM) planned for production
- **Usage Analytics**: Basic analytics planned for feature usage (opt-in)

## Code Quality Improvement Plan

### Immediate Actions (High Priority)
1. **Fix ESLint Errors**:
   - Update `MobileLayout.tsx` to use proper `LucideIcon` type instead of `any`
   - Add dependency array to `useEffect` in `InlineStationEditForm.tsx`
   - Reorder code in `StationForm.tsx` to call hooks before using their values

2. **Type Safety Improvements**:
   - Audit all `any` types in the codebase
   - Add proper TypeScript interfaces for all data structures
   - Implement strict null checking

3. **React Hook Best Practices**:
   - Ensure all hooks follow Rules of Hooks
   - Add proper dependency arrays to all effects
   - Use useCallback for event handlers passed to child components

### Medium-term Improvements
1. **Testing Infrastructure**:
   - Set up Jest or Vitest for unit testing
   - Add React Testing Library for component testing
   - Implement integration tests for context providers

2. **Performance Optimization**:
   - Implement code splitting for larger components
   - Add React.memo for expensive components
   - Optimize context providers to prevent unnecessary re-renders

3. **Developer Experience**:
   - Improve inline documentation and JSDoc comments
   - Set up automated code formatting and linting in CI/CD
   - Create component documentation with Storybook

This technical context document provides comprehensive information about the technologies, tools, and patterns used in the CHARGE_admin project, serving as a reference for developers working on the codebase, including current code quality issues and improvement plans.
