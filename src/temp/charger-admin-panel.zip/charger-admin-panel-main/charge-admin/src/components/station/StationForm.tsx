import React, { useState } from 'react';
import { Button } from '../ui/Button';
import { ChevronUp, ChevronDown, Save, X } from 'lucide-react';
import { useTariff } from '../../contexts/useTariff';
import { useMode } from '../../contexts/useMode';

// Тип для станции (дублируем из Stations.tsx для независимости)
interface Station {
  id: string;
  name: string;
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;
  location: string;
  tariffName?: string;
  ports: number;
  energyToday: number;
}

interface StationFormProps {
  isExpanded: boolean;
  onToggleExpand: () => void;
  onSubmit: (station: Station) => void;
  initialData: Station | null;
  mode: 'create' | 'edit';
  onCancel?: () => void;
}

export const StationForm: React.FC<StationFormProps> = ({
  isExpanded,
  onToggleExpand,
  onSubmit,
  initialData,
  mode,
  onCancel,
}) => {
  const { tariffs } = useTariff();
  const { mode: appMode } = useMode();
  
  const [formData, setFormData] = useState<Station>(() => {
    if (initialData) {
      return initialData;
    }
    // Генерация нового ID для новой станции
    const newId = `CHG-${Math.floor(1000 + Math.random() * 9000)}`;
    return {
      id: newId,
      name: '',
      status: 'ready',
      power: 11,
      location: '',
      tariffName: tariffs.length > 0 ? tariffs[0].name : '',
      ports: 1,
      energyToday: 0,
    };
  });
  
  const [errors, setErrors] = useState<{
    name?: string;
    id?: string;
    location?: string;
    tariffName?: string;
  }>({});

  // Reset form when initialData changes - use key prop on parent instead of effect
  // The parent component should provide a new key when initialData changes

  const validateForm = (): boolean => {
    const newErrors: typeof errors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Название станции обязательно';
    } else if (formData.name.length > 100) {
      newErrors.name = 'Название не должно превышать 100 символов';
    }

    if (formData.id.length > 8) {
      newErrors.id = 'ID станции не должен превышать 8 символов';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Локация обязательна';
    }

    // В коммерческом режиме тариф обязателен
    if (appMode === 'commercial' && !formData.tariffName?.trim()) {
      newErrors.tariffName = 'Выберите тариф для станции';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
      // Форма автоматически сворачивается после успешного сохранения
      if (isExpanded) {
        onToggleExpand();
      }
    }
  };

  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    }
    // Сворачиваем форму при отмене
    if (isExpanded) {
      onToggleExpand();
    }
  };

  return (
    <div className="bg-bg-0 rounded-lg border border-bg-2 mb-6">
      {/* Заголовок с кнопкой свертывания */}
      <div className="flex items-center justify-between p-4 border-b border-bg-2 cursor-pointer" onClick={onToggleExpand}>
        <div className="flex items-center space-x-3">
          <div className="h-8 w-8 rounded-lg bg-brand/10 flex items-center justify-center">
            <Save className="h-4 w-4 text-brand" />
          </div>
          <div>
            <h3 className="font-semibold text-ink">
              {mode === 'create' ? 'Добавить новую станцию' : `Редактировать станцию: ${formData.name}`}
            </h3>
            <p className="text-sm text-muted">
              {mode === 'create' ? 'Заполните данные новой станции' : 'Измените данные станции'}
            </p>
          </div>
        </div>
        <Button variant="icon">
          {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </Button>
      </div>

      {/* Форма (отображается только при isExpanded) */}
      {isExpanded && (
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-muted mb-2">
              Название станции *
            </label>
            <input
              type="text"
              required
              maxLength={100}
              className={`w-full bg-bg-2 border ${errors.name ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Введите название станции"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-error">{errors.name}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-muted mb-2">
              ID станции
            </label>
            <input
              type="text"
              maxLength={8}
              className={`w-full bg-bg-2 border ${errors.id ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
              value={formData.id}
              onChange={(e) => setFormData({ ...formData, id: e.target.value })}
              placeholder="CHG-XXXX"
            />
            {errors.id && (
              <p className="mt-1 text-sm text-error">{errors.id}</p>
            )}
            <p className="mt-1 text-xs text-muted">Максимум 8 символов</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-muted mb-2">
              Локация *
            </label>
            <input
              type="text"
              required
              className={`w-full bg-bg-2 border ${errors.location ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder="Введите адрес станции"
            />
            {errors.location && (
              <p className="mt-1 text-sm text-error">{errors.location}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-muted mb-2">
                Мощность (кВт) *
              </label>
              <select
                className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                value={formData.power}
                onChange={(e) => setFormData({ ...formData, power: Number(e.target.value) })}
              >
                <option value="7">7 кВт</option>
                <option value="11">11 кВт</option>
                <option value="22">22 кВт</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-muted mb-2">
                Количество портов *
              </label>
              <select
                className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                value={formData.ports}
                onChange={(e) => setFormData({ ...formData, ports: Number(e.target.value) })}
              >
                <option value="1">1 порт</option>
                <option value="2">2 порта</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-muted mb-2">
              Статус *
            </label>
            <select
              className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as Station['status'] })}
            >
              <option value="ready">Готова</option>
              <option value="charging">Заряжает</option>
              <option value="offline">Оффлайн</option>
              <option value="pending">Ожидание</option>
              <option value="fault">Неисправность</option>
            </select>
          </div>

          {/* Поле выбора тарифа (только в коммерческом режиме) */}
          {appMode === 'commercial' && (
            <div>
              <label className="block text-sm font-medium text-muted mb-2">
                Тариф *
              </label>
              <select
                className={`w-full bg-bg-2 border ${errors.tariffName ? 'border-error' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand`}
                value={formData.tariffName || ''}
                onChange={(e) => setFormData({ ...formData, tariffName: e.target.value })}
              >
                <option value="">Выберите тариф</option>
                {tariffs.map((tariff) => (
                  <option key={tariff.name} value={tariff.name}>
                    {tariff.name}
                  </option>
                ))}
              </select>
              {errors.tariffName && (
                <p className="mt-1 text-sm text-error">{errors.tariffName}</p>
              )}
            </div>
          )}

          <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
            <Button variant="secondary" onClick={handleCancel} icon={X}>
              Отмена
            </Button>
            <Button variant="primary" type="submit" icon={Save}>
              Сохранить
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};
