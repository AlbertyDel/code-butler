
export interface Tariff {
  id: string;
  name: string;
  basePrice: number;
  timeRules: { start: string; end: string; price: number }[];
}

// Default tariff plans: defines static and time‑based pricing models
export const defaultTariffs: Tariff[] = [
  {
    id: 'TRF-01',
    name: 'Базовый',
    basePrice: 8.5,
    timeRules: [
      { start: '00:00', end: '07:00', price: 6.0 },
      { start: '07:00', end: '23:59', price: 8.5 },
    ],
  },
  {
    id: 'TRF-02',
    name: 'Премиум',
    basePrice: 12.0,
    timeRules: [{ start: '00:00', end: '23:59', price: 12.0 }],
  },
  {
    id: 'TRF-03',
    name: 'Ночной',
    basePrice: 5.0,
    timeRules: [
      { start: '00:00', end: '06:00', price: 4.0 },
      { start: '06:00', end: '23:59', price: 6.0 },
    ],
  },
];