import React from 'react';
import type { LucideIcon } from 'lucide-react';

interface HeaderCellProps {
  icon: LucideIcon;
  text: string;
  // Visibility control
  showMobileIcon?: boolean;
  showTabletIcon?: boolean;
  showDesktopText?: boolean;
  // Alignment
  mobileAlign?: 'start' | 'center' | 'end';
  tabletAlign?: 'start' | 'center' | 'end';
  desktopAlign?: 'start' | 'center' | 'end';
  // Column specific
  isPowerOrPortsColumn?: boolean;
  isCommercialOnly?: boolean;
  className?: string;
}

export const HeaderCell: React.FC<HeaderCellProps> = ({
  icon: Icon,
  text,
  showMobileIcon = true,
  showTabletIcon = true,
  showDesktopText = true,
  mobileAlign = 'center',
  tabletAlign = 'center',
  desktopAlign = 'start',
  isPowerOrPortsColumn = false,
  // isCommercialOnly prop is reserved for future use
  className = '',
}) => {
  // Alignment classes
  const getAlignClass = (align: 'start' | 'center' | 'end') => {
    switch (align) {
      case 'start': return 'justify-start';
      case 'center': return 'justify-center';
      case 'end': return 'justify-end';
    }
  };

  const mobileAlignClass = getAlignClass(mobileAlign);
  const tabletAlignClass = getAlignClass(tabletAlign);
  const desktopAlignClass = getAlignClass(desktopAlign);

  // For Power/Ports columns, we need special handling
  const isSpecialColumn = isPowerOrPortsColumn;

  return (
    <th className={`px-4 py-3 text-left text-xl font-medium text-muted uppercase tracking-wider ${className} ${isSpecialColumn ? 'hidden sm:table-cell' : ''}`}>
      <div className={`
        flex items-center
        ${mobileAlignClass}
        sm:${tabletAlignClass}
        lg:${desktopAlignClass}
      `}>
        {/* Mobile icon - visible only on mobile */}
        {showMobileIcon && (
          <span className="icon-mobile">
            <Icon className="w-6 h-4 text-muted" />
          </span>
        )}
        
        {/* Tablet icon - visible only on tablet */}
        {showTabletIcon && (
          <span className="icon-tablet">
            <Icon className="w-6 h-4 text-muted" />
          </span>
        )}
        
        {/* Desktop text - visible only on desktop */}
        {showDesktopText && (
          <span className="hidden md:hidden lg:inline">
            {text}
          </span>
        )}
      </div>
    </th>
  );
};
