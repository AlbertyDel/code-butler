import { fakerRU as faker } from '@faker-js/faker';

// Ensure deterministic results on each app start
faker.seed(2026);

export interface DashboardStation {
  id: string;
  name: string;
  status: 'charging' | 'ready' | 'offline' | 'pending' | 'fault';
  power: number;
  location: string;
  sessionsToday: number;
}

// Mock stations for dashboard - matches exact structure from Dashboard.tsx
export const mockStations: DashboardStation[] = [
  { id: 'CHG-0012', name: 'Станция А', status: 'charging', power: 22, location: 'Москва', sessionsToday: 3 },
  { id: 'CHG-0013', name: 'Станция Б', status: 'ready', power: 11, location: 'Санкт-Петербург', sessionsToday: 1 },
  { id: 'CHG-0014', name: 'Станция В', status: 'offline', power: 22, location: 'Казань', sessionsToday: 0 },
  { id: 'CHG-0015', name: 'Станция Г', status: 'pending', power: 11, location: 'Екатеринбург', sessionsToday: 2 },
];

// Generate additional dashboard stations using Faker
export const generateDashboardStations = (count: number = 8): DashboardStation[] => {
  const stations: DashboardStation[] = [];
  const cities = ['Москва', 'Санкт-Петербург', 'Казань', 'Екатеринбург', 'Новосибирск', 'Нижний Новгород', 'Самара', 'Ростов-на-Дону'];
  const statuses: DashboardStation['status'][] = ['charging', 'ready', 'offline', 'pending', 'fault'];
  
  for (let i = 0; i < count; i++) {
    stations.push({
      id: `CHG-${1000 + i}`,
      name: `Станция ${String.fromCharCode(1040 + i)}`, // А, Б, В, Г...
      status: faker.helpers.arrayElement(statuses),
      power: faker.helpers.arrayElement([7, 11, 22]),
      location: faker.helpers.arrayElement(cities),
      sessionsToday: faker.number.int({ min: 0, max: 10 }),
    });
  }
  
  return stations;
};