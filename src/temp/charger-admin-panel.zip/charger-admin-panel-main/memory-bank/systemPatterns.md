# CHARGE_admin System Patterns

## System Architecture

### Dual-Mode Architecture
The core architectural pattern of CHARGE_admin is the **dual-mode system** that enables a single application to serve two distinct user types (personal and commercial) with tailored experiences. This pattern is implemented through:

**Mode Context Pattern**:
```typescript
// ModeContext.tsx - Central mode management
type Mode = 'personal' | 'commercial';
const [mode, setMode] = useState<Mode>('personal');
```

**Mode Propagation**:
- **Navigation Filtering**: Both `DesktopLayout` and `MobileLayout` filter navigation items based on current mode
- **Protected Routes**: `ProtectedRoute` component restricts access to `/tariffs` and `/finance` routes in personal mode
- **Conditional Rendering**: Components use `useMode()` hook to conditionally render mode-specific content
- **Data Display**: Tables and forms show/hide columns and fields based on mode

**Architectural Benefits**:
- **Code Reuse**: 80%+ code shared between modes
- **Consistent UX**: Same design system and interaction patterns
- **Flexible Deployment**: Single codebase, dual-purpose application

### Component Hierarchy and Relationships

**Top-Level Application Structure**:
```
App.tsx (Root)
├── Context Providers (Nested)
│   ├── ToastProvider (UI feedback)
│   ├── UserProvider (User data)
│   ├── ModeProvider (Application mode)
│   ├── TariffProvider (Pricing rules)
│   └── FinanceProvider (Financial operations)
├── Router Configuration
│   ├── ProtectedRoute (Mode-based access control)
│   ├── Lazy Loading (Code splitting)
│   └── Error Boundaries (Graceful error handling)
└── ResponsiveLayout (Layout switching)
    ├── DesktopLayout (≥1024px)
    └── MobileLayout (<1024px)
```

**Page Component Relationships**:
- **Dashboard.tsx**: Dual-mode entry point with conditional KPI cards and station displays
- **Stations.tsx**: Shared station management with mode-specific "Add Station" button
- **Sessions.tsx**: Expandable table with mode-dependent columns (cost, payment method)
- **Tariffs.tsx**: Commercial-only complex tariff management with visual rule editor
- **Finance.tsx**: Commercial-only financial operations and subscription management
- **Profile.tsx**: Mode-aware profile with conditional tabs (Company, Contacts in commercial)

### Data Flow Architecture

**Context-Based State Management Flow**:
```
User Action → Component Handler → Context Method → State Update → localStorage Persistence → UI Re-render
```

**Context Provider Chain**:
```typescript
<ToastProvider>
  <UserProvider>
    <ModeProvider>
      <TariffProvider>
        <FinanceProvider>
          {/* Application Components */}
        </FinanceProvider>
      </TariffProvider>
    </ModeProvider>
  </UserProvider>
</ToastProvider>
```

**Data Persistence Patterns**:
- **LocalStorage Integration**: Each context automatically persists to localStorage on state changes
- **Mock Data Fallback**: Contexts initialize with mock data when localStorage is empty
- **Data Normalization**: `normalizeStations()` function ensures data consistency on load
- **Storage Namespacing**: Keys prefixed with `'charge_admin_'` to avoid collisions

### Component Design Patterns

**Reusable UI Component Pattern**:
```typescript
// Button.tsx - Variant-based component
type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'icon';
type ButtonSize = 'sm' | 'md' | 'lg';

const Button: React.FC<ButtonProps> = ({ variant, size, children, ...props }) => {
  // Variant and size classes mapped to Tailwind CSS
  return <button className={cn(variantClasses[variant], sizeClasses[size])} {...props}>{children}</button>;
};
```

**Compound Component Pattern** (Card):
```typescript
// Card.tsx - Compound component with subcomponents
const Card = ({ children, variant }: CardProps) => <div className={cardClasses[variant]}>{children}</div>;
Card.Header = ({ children }: { children: React.ReactNode }) => <div className="card-header">{children}</div>;
Card.Content = ({ children }: { children: React.ReactNode }) => <div className="card-content">{children}</div>;
Card.Footer = ({ children }: { children: React.ReactNode }) => <div className="card-footer">{children}</div>;
```

**Custom Hook Pattern**:
```typescript
// usePersistentData.ts - Generic localStorage hook
function usePersistentData<T>(key: string, initialData: T): [T, (newData: T) => void] {
  const [data, setData] = useState<T>(() => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initialData;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(data));
  }, [key, data]);

  return [data, setData];
}
```

### Form Management Patterns

**Modal Form Pattern** (StationModal, TariffModal):
- **State Management**: Modal open/close state managed by parent component
- **Initial Data**: Editing passes initial data, creation passes null/empty object
- **Validation**: Form-level validation with error display
- **Submission**: Callback to parent for data persistence

**Inline Form Pattern** (TariffForm in Tariffs page):
- **Collapsible Design**: Form expands/collapses to save screen space
- **Real-time Validation**: Validation occurs on change with immediate feedback
- **Complex Rule Management**: Dynamic rule addition/removal with visual feedback

**Validation Patterns**:
- **Field-level Validation**: Individual input validation with error messages
- **Cross-field Validation**: Rule overlap detection in tariff management
- **Business Logic Validation**: Station power (7, 11, 22 kW) and ports (1, 2) constraints

### Data Visualization Patterns

**Chart Integration Pattern** (EnergyChart):
```typescript
// Recharts integration with responsive container
<ResponsiveContainer width="100%" height={300}>
  <LineChart data={data}>
    <CartesianGrid strokeDasharray="3 3" />
    <XAxis dataKey="date" />
    <YAxis />
    <Tooltip />
    <Line type="monotone" dataKey="kwh" stroke="#12B76A" />
  </LineChart>
</ResponsiveContainer>
```

**Grid Visualization Pattern** (TariffRuleVisualizer):
- **7x24 Grid**: Days vs. hours visualization of pricing rules
- **Color Coding**: Each rule gets distinct color; overlaps highlighted in red
- **Interactive Tooltips**: Hover reveals price information
- **Legend System**: Color-coded price labels

**Status Visualization Pattern**:
- **StatusBadge**: Generic status component with color-coded variants
- **StationStatusBadge**: Specialized for station statuses (charging, ready, offline, etc.)
- **Icon Integration**: Lucide React icons paired with status labels

### Responsive Design Patterns

**Layout Switching Pattern**:
```typescript
// ResponsiveLayout.tsx - Media query-based layout switching
const isDesktop = useMediaQuery('(min-width: 1024px)');
return isDesktop ? <DesktopLayout>{children}</DesktopLayout> : <MobileLayout>{children}</MobileLayout>;
```

**Navigation Adaptation**:
- **Desktop**: Sidebar navigation with full-height layout
- **Mobile**: Bottom navigation with hamburger menu for additional items
- **Mode Filtering**: Both layouts filter navigation items based on current mode

**Responsive Grid Patterns**:
```typescript
// Dashboard statistics grid - adaptive columns
<div className={`grid gap-6 ${mode === 'commercial' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'}`}>
```

**Table Responsiveness**:
- **Horizontal Scrolling**: Tables use `overflow-x-auto` on mobile
- **Column Prioritization**: Less important columns hidden on small screens
- **Touch-Friendly**: Action buttons sized appropriately for touch

### Error Handling and Recovery Patterns

**Error Boundary Pattern**:
- **Component-Level**: Individual components handle their own error states
- **Graceful Degradation**: Features unavailable show friendly messages instead of crashing
- **Recovery Options**: Clear paths to recover from error states

**Validation Feedback**:
- **Inline Errors**: Error messages displayed near problematic fields
- **Form-level Errors**: Validation summaries for complex forms
- **Toast Notifications**: Success/error feedback for user actions

**Data Corruption Recovery**:
- **Normalization Functions**: `normalizeStations()` repairs invalid data on load
- **Mock Data Fallback**: Corrupted localStorage triggers fallback to mock data
- **Default Values**: Missing fields populated with sensible defaults

### Performance Optimization Patterns

**Code Splitting Pattern**:
```typescript
// Route-based code splitting in App.tsx
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Stations = lazy(() => import('./pages/Stations'));
// ... other pages
```

**Memoization Patterns**:
```typescript
// TariffRuleVisualizer.tsx - Expensive grid calculations memoized
const { gridData } = useMemo(() => {
  // Complex grid calculation logic
  return { gridData: calculatedGrid };
}, [rules, basePricePerKwh]);
```

**Efficient Re-render Patterns**:
- **Context Segmentation**: Separate contexts prevent unnecessary re-renders
- **Component Memoization**: `React.memo` for expensive components
- **Prop Stabilization**: `useMemo`/`useCallback` for stable callback references

### Testing and Quality Assurance Patterns

**Type-Driven Development**:
- **Interface-First**: TypeScript interfaces defined before implementation
- **Strict Typing**: Minimized use of `any` type (current technical debt)
- **Type Utilities**: Shared type definitions in `/src/types` directory

**Code Quality Patterns**:
- **ESLint Configuration**: React Hooks rules, TypeScript compatibility
- **Auto-Formatting**: Consistent code style via editor configuration
- **Import Organization**: Grouped imports (React, external, internal)

### Deployment and Build Patterns

**Build Configuration**:
- **Vite 7.2.5 (Rolldown-based)**: Fast builds with optimized output
- **TypeScript Separation**: `tsconfig.app.json` (app) and `tsconfig.node.json` (build tools)
- **Tailwind CSS 4**: JIT compilation for minimal CSS output

**Development Workflow**:
- **Hot Module Replacement**: Fast development iterations
- **Mock Data Generation**: Deterministic Faker.js data for consistent testing
- **LocalStorage Simulation**: Browser persistence without backend dependency

## Critical Implementation Paths

### Station Management Flow
```
1. Stations Page Load
   → usePersistentData loads stations from localStorage
   → normalizeStations ensures data consistency
   → StationsTable renders sorted stations

2. Add Station
   → User clicks "Add Station" (commercial only)
   → StationModal opens with empty form
   → User fills form with validation
   → onSubmit saves to stations array
   → localStorage automatically persists
   → UI updates with new station

3. Edit Station
   → User clicks edit icon on station row
   → StationModal opens with station data
   → User modifies form with validation
   → onSubmit updates stations array
   → localStorage persists changes
   → UI updates with modified station

4. Delete Station
   → User clicks delete icon
   → confirm() dialog for confirmation
   → Station removed from stations array
   → localStorage persists changes
   → UI updates without deleted station
```

### Tariff Management Flow
```
1. Tariff Creation
   → User clicks "New Tariff"
   → TariffModal opens with empty form
   → User adds rules with time-based pricing
   → TariffRuleVisualizer shows rule visualization
   → Validation checks for overlaps and errors
   → onSubmit calls TariffContext.addTariff()
   → localStorage persists new tariff
   → Toast notification confirms success

2. Rule Management
   → User adds/edits/deletes tariff rules
   → Time ranges automatically normalized (swap if start > end)
   → Overlap detection highlights conflicts in red
   → Visual grid updates in real-time
   → Form validation prevents submission with errors

3. Tariff Application
   → Stations reference tariff by name
   → Sessions calculate cost based on active tariff rules
   → Commercial mode shows cost column in sessions table
```

### Mode Switching Flow
```
1. Mode Change Initiation
   → User clicks mode switcher (not yet implemented in UI)
   → ModeContext.setMode() updates global state
   → No localStorage persistence for mode (session-only)

2. UI Adaptation
   → Navigation items immediately filtered
   → Protected routes re-evaluate accessibility
   → Dashboard re-renders with mode-appropriate content
   → Tables show/hide mode-specific columns

3. Data Filtering
   → Personal mode: Hide financial data, commercial-only features
   → Commercial mode: Show full feature set with financial columns
```

## System Constraints and Limitations

### Technical Constraints
- **LocalStorage Limit**: 5-10MB maximum storage capacity
- **Browser Compatibility**: Modern browsers with ES6+ support required
- **Bundle Size Target**: <500KB initial load
- **Performance Target**: <3s initial load, <100ms interaction response

### Architectural Constraints
- **Frontend-Only**: No backend integration in current phase
- **Single-User**: No multi-user collaboration features
- **Offline-First**: Designed for intermittent connectivity
- **Russian Language**: Interface optimized for Russian users

### Business Logic Constraints
- **Station Power**: Only 7, 11, or 22 kW values allowed
- **Station Ports**: Only 1 or 2 ports allowed
- **Tariff Rules**: No overlapping time ranges within same tariff
- **Financial Operations**: Commercial mode only

## Extension Points and Plugin Architecture

### Future Integration Points
1. **API Adapter Layer**: Abstract data persistence for backend integration
2. **Plugin System**: Allow third-party extensions for analytics, reporting, etc.
3. **Theme System**: Support for custom branding and white-labeling
4. **Internationalization**: Multi-language support beyond Russian

### Modular Component Architecture
- **Feature Modules**: Self-contained feature packages (stations, tariffs, finance)
- **Shared Utilities**: Common utilities in `/src/utils` directory
- **Type Definitions**: Centralized types in `/src/types` directory
- **Context Providers**: Isolated state management per domain

## Code Quality Patterns and Anti-Patterns

### Current Code Quality Issues (Anti-Patterns)
1. **Type Safety Violations**:
   - `MobileLayout.tsx`: Using `any` type for icon props instead of proper LucideIcon type
   - **Impact**: Reduces type safety and IDE autocomplete support
   - **Fix**: Replace `any` with `LucideIcon` type from lucide-react

2. **React Hook Violations**:
   - `InlineStationEditForm.tsx`: `setState` in `useEffect` without dependencies array
   - **Impact**: Causes unnecessary re-renders and potential infinite loops
   - **Fix**: Add proper dependency array `[station]` to useEffect

3. **Variable Declaration Order**:
   - `StationForm.tsx`: Using `tariffs` variable before declaration (hook call order violation)
   - **Impact**: Runtime errors and unpredictable behavior
   - **Fix**: Reorder code to call hooks before using their values

### Recommended Code Quality Patterns
1. **Strict TypeScript Configuration**:
   - Use `strict: true` in tsconfig.json
   - Avoid `any` types with explicit interfaces
   - Use type guards and assertion functions

2. **React Hook Best Practices**:
   - Follow Rules of Hooks (call at top level, in same order)
   - Include all dependencies in useEffect dependency arrays
   - Use useCallback and useMemo for performance optimization

3. **Component Organization**:
   - Declare hooks at the top of component functions
   - Group related state and effects together
   - Separate business logic from presentation

### Performance Patterns
1. **Context Optimization**:
   - Split contexts to prevent unnecessary re-renders
   - Use React.memo for expensive components
   - Implement selective context consumption patterns

2. **Bundle Optimization**:
   - Lazy load route components
   - Tree shake unused imports
   - Code split by feature modules

### Testing Patterns (Future Implementation)
1. **Unit Testing**: Test utilities, hooks, and pure functions
2. **Component Testing**: Test UI components with React Testing Library
3. **Integration Testing**: Test context providers and data flows
4. **E2E Testing**: Test complete user flows with Cypress or Playwright

This system patterns document captures the architectural decisions, design patterns, and implementation approaches that define the CHARGE_admin application structure and behavior, including current code quality issues and recommended patterns for improvement.
