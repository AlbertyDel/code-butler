import React, { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { 
  X, Battery, Thermometer, Zap, Activity, 
  Cpu, Tag, BatteryCharging, Calendar, Hourglass,
  Info, BarChart3, Gauge
} from 'lucide-react';
import { Button } from '../ui/Button';
import { StationStatusBadge } from '../ui/StatusBadge';
import type { Station } from '../../data/stations';
import { ensureStationHasTechnicalParameters } from '../../data/stations';

interface StationDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  station: Station;
}

type TabType = 'overview' | 'technical' | 'performance' | 'usage';

export const StationDetailsModal: React.FC<StationDetailsModalProps> = ({
  isOpen,
  onClose,
  station,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const contentAreaRef = useRef<HTMLDivElement>(null);
  
  // Ensure station has all technical parameters
  const stationWithParams = ensureStationHasTechnicalParameters(station);

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  // Force overflow-y: auto with !important
  useEffect(() => {
    if (contentAreaRef.current) {
      contentAreaRef.current.style.setProperty('overflow-y', 'auto', 'important');
    }
  }, []);

  if (!isOpen) {
    return null;
  }

  const tabs = [
    { id: 'overview' as TabType, label: 'Обзор', icon: Info },
    { id: 'technical' as TabType, label: 'Технические', icon: Gauge },
    { id: 'performance' as TabType, label: 'Производительность', icon: BarChart3 },
    { id: 'usage' as TabType, label: 'Использование', icon: Activity },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Station Summary Card */}
            <div className="bg-gradient-to-r from-brand-light/20 to-brand-light/5 rounded-xl p-6 border border-brand/10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white rounded-lg shadow-sm">
                      <Battery className="h-6 w-6 text-brand" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-ink">{stationWithParams.name}</h3>
                      <p className="text-muted text-sm">ID: {stationWithParams.id}</p>
                    </div>
                  </div>
                  <p className="text-muted">{stationWithParams.location}</p>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <StationStatusBadge status={stationWithParams.status} forceShowText={true} />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-ink">{stationWithParams.power} кВт</p>
                    <p className="text-sm text-muted">Мощность</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-bg-2 rounded-lg p-4 border border-bg-2 hover:border-brand/20 transition-colors">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-info/20 rounded-lg">
                      <Cpu className="h-5 w-5 text-info" />
                    </div>
                    <div>
                      <p className="text-sm text-muted">Порты</p>
                      <p className="text-2xl font-bold text-ink">{stationWithParams.ports}</p>
                    </div>
                  </div>
                </div>

              <div className="bg-bg-2 rounded-lg p-4 border border-bg-2 hover:border-brand/20 transition-colors">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 bg-success/20 rounded-lg">
                    <Tag className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-sm text-muted">Тариф</p>
                    <p className="text-xl font-semibold text-ink">{stationWithParams.tariffName || 'Базовый'}</p>
                  </div>
                </div>
              </div>

              <div className="bg-bg-2 rounded-lg p-4 border border-bg-2 hover:border-brand/20 transition-colors">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 bg-brand/20 rounded-lg">
                    <BatteryCharging className="h-5 w-5 text-brand" />
                  </div>
                  <div>
                    <p className="text-sm text-muted">Энергия сегодня</p>
                    <p className="text-2xl font-bold text-ink">{stationWithParams.energyToday.toFixed(1)} кВт·ч</p>
                  </div>
                </div>
              </div>

              <div className="bg-bg-2 rounded-lg p-4 border border-bg-2 hover:border-brand/20 transition-colors">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 bg-warning/20 rounded-lg">
                    <Calendar className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-sm text-muted">Всего сессий</p>
                    <p className="text-2xl font-bold text-ink">{stationWithParams.totalSessions?.toLocaleString('ru-RU')}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'technical':
        return (
          <div className="space-y-6">
            {/* Electrical Parameters */}
            <div className="bg-bg-2 rounded-xl p-5">
              <h4 className="text-lg font-semibold text-ink mb-4 flex items-center gap-2">
                <Zap className="h-5 w-5 text-info" />
                Электрические параметры
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { label: 'Напряжение фаза 1', value: `${stationWithParams.voltagePhase1?.toFixed(1)} В` },
                  { label: 'Напряжение фаза 2', value: `${stationWithParams.voltagePhase2?.toFixed(1)} В` },
                  { label: 'Напряжение фаза 3', value: `${stationWithParams.voltagePhase3?.toFixed(1)} В` },
                  { label: 'Количество фаз', value: stationWithParams.phaseIndicator },
                  { label: 'Макс. ток порта', value: stationWithParams.maxCurrentLimit },
                  { label: 'Состояние реле порта', value: stationWithParams.portRelayStatus },
                ].map((item, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 border border-bg-2">
                    <p className="text-sm text-muted mb-1">{item.label}</p>
                    <p className="text-lg font-semibold text-ink">{item.value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Temperature Parameters */}
            <div className="bg-bg-2 rounded-xl p-5">
              <h4 className="text-lg font-semibold text-ink mb-4 flex items-center gap-2">
                <Thermometer className="h-5 w-5 text-warning" />
                Температурные параметры
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Темп. контактов на входе', value: `${stationWithParams.inputContactTemp?.toFixed(1)} °C` },
                  { label: 'Темп. порта 0', value: `${stationWithParams.outputPort0Temp?.toFixed(1)} °C` },
                  { label: 'Темп. порта 1', value: `${stationWithParams.outputPort1Temp?.toFixed(1)} °C` },
                  { label: 'Темп. внутри ЗУ', value: `${stationWithParams.internalTemp?.toFixed(1)} °C` },
                ].map((item, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 border border-bg-2">
                    <p className="text-sm text-muted mb-1">{item.label}</p>
                    <p className="text-xl font-bold text-ink">{item.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      
      case 'performance':
        return (
          <div className="space-y-6">
            {/* Performance Metrics */}
            <div className="bg-bg-2 rounded-xl p-5">
              <h4 className="text-lg font-semibold text-ink mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-brand" />
                Ключевые показатели
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-brand mb-2">{stationWithParams.totalSessions?.toLocaleString('ru-RU')}</div>
                  <p className="text-sm text-muted">Всего сессий</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-info mb-2">
                    {Math.round((stationWithParams.totalOperatingMinutes || 0) / 60).toLocaleString('ru-RU')}
                  </div>
                  <p className="text-sm text-muted">Часов работы</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-success mb-2">{stationWithParams.totalEnergyDelivered?.toFixed(0)}</div>
                  <p className="text-sm text-muted">кВт·ч отдано</p>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'usage':
        return (
          <div className="space-y-6">
            {/* Usage Statistics */}
            <div className="bg-bg-2 rounded-xl p-5">
              <h4 className="text-lg font-semibold text-ink mb-4 flex items-center gap-2">
                <Activity className="h-5 w-5 text-brand" />
                Статистика использования
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white rounded-lg p-5 border border-bg-2">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-brand/20 rounded-lg">
                      <Calendar className="h-5 w-5 text-brand" />
                    </div>
                    <div>
                      <p className="text-sm text-muted">Всего сессий</p>
                      <p className="text-2xl font-bold text-ink">{stationWithParams.totalSessions?.toLocaleString('ru-RU')}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg p-5 border border-bg-2">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-info/20 rounded-lg">
                      <Hourglass className="h-5 w-5 text-info" />
                    </div>
                    <div>
                      <p className="text-sm text-muted">Минут работы</p>
                      <p className="text-2xl font-bold text-ink">{stationWithParams.totalOperatingMinutes?.toLocaleString('ru-RU')}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg p-5 border border-bg-2">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-success/20 rounded-lg">
                      <Battery className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-sm text-muted">Отдано энергии</p>
                      <p className="text-2xl font-bold text-ink">{stationWithParams.totalEnergyDelivered?.toFixed(1)} кВт·ч</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return createPortal(
    <>
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        style={{ top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Modal container - Use flexbox centering like in MODAL_TRANSPARENCY_FIX.md */}
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none p-4"
        style={{ top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div 
          className="modal-responsive-container w-full flex flex-col border border-bg-2 rounded-lg shadow-xl pointer-events-auto bg-white"
          style={{ 
            height: '80vh',
            maxHeight: '80vh',
            minHeight: '400px',
            backgroundColor: '#FFFFFF'
          }}
          role="dialog"
          aria-labelledby="station-details-modal-title"
          aria-modal="true"
        >
          {/* Fixed header section */}
          <div className="flex-shrink-0">
            {/* Header */}
            <div className="border-b border-bg-2 p-6 flex items-center justify-between">
              <div>
                <h2 id="station-details-modal-title" className="text-2xl font-bold text-ink">
                  Детали станции
                </h2>
                <p className="text-muted mt-1">{stationWithParams.name} • ID: {stationWithParams.id}</p>
              </div>
              <Button variant="icon" onClick={onClose}>
                <X size={24} />
              </Button>
            </div>

            {/* Tabs - All tabs visible without scrolling */}
            <div className="border-b border-bg-2 bg-white">
              <div className="flex">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex-1 flex flex-col items-center justify-center min-w-0 px-1 sm:px-2 py-3 text-xs sm:text-sm font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'text-brand border-b-2 border-brand'
                          : 'text-muted hover:text-ink'
                      }`}
                      title={tab.label}
                    >
                      <Icon className="h-3 w-3 sm:h-4 sm:w-4 mb-1 flex-shrink-0" />
                      <span className="truncate w-full text-center text-[10px] xs:text-xs sm:text-sm">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Scrollable content area - constrained height with proper scrolling */}
          <div 
            ref={contentAreaRef}
            className="flex-1 p-6 overflow-y-auto" 
            style={{ 
              maxHeight: 'calc(80vh - 169px)',
              overflowY: 'auto'
            }}
          >
            {renderTabContent()}
          </div>
        </div>
      </div>
    </>,
    document.body
  );
};
