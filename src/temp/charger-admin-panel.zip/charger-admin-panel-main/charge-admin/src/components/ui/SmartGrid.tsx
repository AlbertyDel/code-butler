import React, { useState, useEffect, useRef, useMemo } from 'react';
import type { ReactNode } from 'react';
import { cn } from '../../utils/cn';

interface SmartGridProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  minColumnWidth?: number;
  maxColumns?: number;
  gap?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | number; // Allow custom numeric gap
  matchHeights?: boolean;
  mobileOptimization?: boolean;
  margin?: number; // Margin around the grid
  maxScaleFactor?: number; // Maximum scaling factor (default 1.1 = 10% scale)
  hoverMargin?: number; // Margin for hover expansion (0.025 = 2.5% on each side for 5% total scale)
}

export const SmartGrid: React.FC<SmartGridProps> = ({
  children,
  className,
  minColumnWidth = 280,
  maxColumns = 5,
  gap = 'md',
  matchHeights = true,
  mobileOptimization = true,
  margin = 16, // 16px margin around grid
  maxScaleFactor = 1.1, // Maximum 10% scale
  hoverMargin = 0.025, // 2.5% margin on each side for 5% hover scale (scale-105)
  ...props
}) => {
  const gridRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);
  const [itemDimensions, setItemDimensions] = useState<Array<{width: number, height: number, aspectRatio: number}>>([]);
  const [optimizedLayout, setOptimizedLayout] = useState<{heights: number[], columns: number, cardWidth: number, baseCardWidth?: number}>({heights: [], columns: 1, cardWidth: 0});

  const gaps = {
    none: {value: 0, class: 'gap-0'},
    sm: {value: 12, class: 'gap-3'}, // 12px
    md: {value: 24, class: 'gap-6'}, // 24px
    lg: {value: 32, class: 'gap-8'}, // 32px
    xl: {value: 40, class: 'gap-10'}, // 40px
  };

  // Calculate gap value - handle both string keys and numeric values
  const gapValue = typeof gap === 'number' ? gap : gaps[gap].value;

  // Calculate container width with margin and hover expansion protection
  useEffect(() => {
    const updateContainerWidth = () => {
      if (!gridRef.current) return;
      
      const parent = gridRef.current.parentElement;
      if (!parent) return;
      
      const parentWidth = parent.clientWidth;
      
      // Calculate effective margin: use margin for static cards, add hover expansion for animated cards
      // const effectiveMargin = hoverMargin > 0 ? margin + (minColumnWidth * hoverMargin) : margin;
      
      // Calculate available width for cards
      const availableWidth = Math.max(0, parentWidth - (margin * 2));
      
      setContainerWidth(availableWidth);
      
      // Apply the margin to the grid container (only margin, not effectiveMargin for width calculation)
      if (gridRef.current) {
        gridRef.current.style.marginLeft = `${margin}px`;
        gridRef.current.style.marginRight = `${margin}px`;
      }
    };

    updateContainerWidth();
    window.addEventListener('resize', updateContainerWidth);
    return () => window.removeEventListener('resize', updateContainerWidth);
  }, [margin, hoverMargin, minColumnWidth]);

  // Measure item dimensions (natural sizes) with debounce and stable state detection
  useEffect(() => {
    if (!gridRef.current) return;

    const measureItems = () => {
      const items = gridRef.current!.children;
      const dimensions: Array<{width: number, height: number, aspectRatio: number}> = [];

      for (let i = 0; i < items.length; i++) {
        const item = items[i] as HTMLElement;
        
        // Store original styles
        const originalDisplay = item.style.display;
        const originalWidth = item.style.width;
        const originalHeight = item.style.height;
        const originalMinHeight = item.style.minHeight;
        const originalPosition = item.style.position;
        const originalTransition = item.style.transition;
        const originalMaxWidth = item.style.maxWidth;
        const originalMaxHeight = item.style.maxHeight;
        
        // Disable transitions during measurement
        item.style.transition = 'none';
        
        // Make item visible but out of flow to measure natural size
        // Remove all constraints that might limit natural size
        item.style.display = 'block';
        item.style.width = 'auto';
        item.style.height = 'auto';
        item.style.minHeight = ''; // CRITICAL: Reset minHeight to measure natural size
        item.style.position = 'absolute';
        item.style.left = '-9999px';
        item.style.top = '-9999px';
        item.style.maxWidth = 'none';
        item.style.maxHeight = 'none';
        
        // Force reflow
        item.getBoundingClientRect();
        
        // Measure content height (excluding padding and margin)
        const contentHeight = item.scrollHeight;
        const contentWidth = item.scrollWidth;
        const aspectRatio = contentWidth > 0 ? contentHeight / contentWidth : 1;
        
        dimensions.push({ 
          width: contentWidth, 
          height: contentHeight, 
          aspectRatio 
        });
        
        // Restore original styles
        item.style.display = originalDisplay;
        item.style.width = originalWidth;
        item.style.height = originalHeight;
        item.style.minHeight = originalMinHeight;
        item.style.position = originalPosition;
        item.style.transition = originalTransition;
        item.style.maxWidth = originalMaxWidth;
        item.style.maxHeight = originalMaxHeight;
        item.style.left = '';
        item.style.top = '';
      }

      // Only update if we have measurements
      if (dimensions.length > 0) {
        setItemDimensions(dimensions);
        console.log('SmartGrid measured items:', dimensions.map(d => ({ width: d.width, height: d.height })));
      }
    };

    // Debounce measurements to avoid rapid recalculations
    const timeoutId = setTimeout(measureItems, 100);
    
    return () => clearTimeout(timeoutId);
  }, [children]);

  // NEW ALGORITHM: Use calculateOptimalLayout to fill available width
  useMemo(() => {
    if (containerWidth <= 0 || itemDimensions.length === 0) return;

    const items = itemDimensions;
    
    let optimalColumns = 1;
    let optimalCardWidth = containerWidth;
    
    // Always use the calculateOptimalLayout function which tries to fill available width
    // This works for both mobile and desktop
    const layout = calculateOptimalLayout(
      items,
      containerWidth,
      minColumnWidth,
      maxColumns,
      gapValue,
      maxScaleFactor
    );
    
    console.log('SmartGrid Algorithm Result:', {
      containerWidth,
      itemsCount: items.length,
      selectedColumns: layout.columns,
      cardWidth: layout.cardWidth,
      scaleFactor: layout.scaleFactor,
      efficiency: layout.efficiency,
      fits: layout.fits
    });
    
    if (layout.columns > 1 && layout.fits) {
      optimalColumns = layout.columns;
      optimalCardWidth = layout.cardWidth;
    }
    
    // Calculate heights for the optimal layout
    const targetHeights: number[] = [];
    const rows = Math.ceil(items.length / optimalColumns);
    
    for (let row = 0; row < rows; row++) {
      let rowHeight = 0;
      
      for (let col = 0; col < optimalColumns; col++) {
        const index = row * optimalColumns + col;
        if (index >= items.length) break;
        
        const item = items[index];
        // Use natural height, don't scale height with width
        // This prevents cards from becoming too tall when width increases
        const cardHeight = item.height;
        
        rowHeight = Math.max(rowHeight, cardHeight);
      }
      
      // Add minimal padding (8px top + 8px bottom = 16px total)
      const rowPadding = 16;
      const finalRowHeight = rowHeight + rowPadding;
      
      // Set same height for all cards in row
      for (let col = 0; col < optimalColumns; col++) {
        const index = row * optimalColumns + col;
        if (index >= items.length) break;
        targetHeights[index] = finalRowHeight;
      }
    }
    
    // For single column, use natural widths (not stretched)
    // For multi-column, use the calculated optimalCardWidth
    const finalCardWidth = optimalColumns === 1 ? containerWidth : optimalCardWidth;

    // Apply hover margin: reduce card width to create space for hover expansion
    // hoverMargin = 0.025 means 2.5% reduction on each side (5% total for scale-105)
    const cardWidthWithHoverMargin = finalCardWidth * (1 - (2 * hoverMargin));

    setOptimizedLayout({
      heights: targetHeights,
      columns: optimalColumns,
      cardWidth: cardWidthWithHoverMargin,
      baseCardWidth: finalCardWidth // Store original width for reference
    });
  }, [containerWidth, itemDimensions, minColumnWidth, maxColumns, gapValue, maxScaleFactor, hoverMargin]);

  // Apply optimized layout to children
  const renderChildren = () => {
    const childrenArray = React.Children.toArray(children);
    const { heights, cardWidth } = optimizedLayout;
    
    return childrenArray.map((child, index) => {
      if (!React.isValidElement<React.HTMLAttributes<HTMLElement>>(child)) return child;

      const childProps = child.props as any;
      
      // Use minHeight for flexibility, not fixed height
      const heightStyle = heights[index] 
        ? { 
            minHeight: `${heights[index]}px`,
            // Allow cards to grow naturally if content is taller
            height: 'auto',
            maxHeight: 'none' // Remove any max-height constraints
          }
        : {};

      // Account for card borders (typically 4px left border)
      // For static cards (hoverMargin === 0), don't subtract border width
      // to ensure margins match gap
      const borderWidth = hoverMargin === 0 ? 0 : 4; // Standard left border width
      const contentWidth = cardWidth - borderWidth;
      
      // Always use calculated widths (algorithm determines optimal width for all screen sizes)
      const widthStyle = { width: `${contentWidth}px` };
      
      const newProps = {
        key: child.key || index,
        style: {
          ...childProps.style,
          ...heightStyle,
          ...widthStyle,
        },
        className: cn(
          childProps.className,
          // Only match heights if explicitly requested
          matchHeights && 'h-full'
        ),
      };

      return React.cloneElement(child, newProps);
    });
  };

    // Use exact pixel widths for all screen sizes (algorithm determines optimal width)
    const gridTemplateColumns = optimizedLayout.columns > 1 
      ? `repeat(${optimizedLayout.columns}, ${optimizedLayout.cardWidth}px)`
      : '1fr';

    // Calculate exact grid width including gaps
    // Use baseCardWidth (without hover margin) for grid width calculation
    // But use cardWidth (with hover margin) for individual cards
    const baseWidth = optimizedLayout.baseCardWidth || optimizedLayout.cardWidth;
    const gridWidth = optimizedLayout.columns > 1 
      ? `${optimizedLayout.columns * baseWidth + gapValue * (optimizedLayout.columns - 1)}px`
      : `calc(100% - ${margin * 2}px)`;

  // Use auto rows for all screen sizes (algorithm handles height optimization)
  const gridAutoRows = 'auto';

  return (
    <div
      ref={gridRef}
      className={cn(
        'grid',
        // Don't center - let grid use natural width
        className
      )}
      style={{
        gridTemplateColumns,
        gridAutoRows,
        width: gridWidth,
        gap: `${gapValue}px`,
        boxSizing: 'border-box',
        ...props.style
      }}
      {...props}
    >
      {renderChildren()}
    </div>
  );
};

// Helper component for mobile-optimized card rows
export const MobileCardRow: React.FC<{ children: ReactNode; className?: string }> = ({
  children,
  className,
}) => {
  return (
    <div className={cn('flex flex-col md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6', className)}>
      {children}
    </div>
  );
};

// Utility function to calculate optimal layout
export const calculateOptimalLayout = (
  items: Array<{width: number, height: number}>,
  containerWidth: number,
  minColumnWidth: number,
  maxColumns: number,
  gap: number,
  maxScaleFactor: number = 1.1
) => {
  let bestLayout = {
    columns: 1,
    cardWidth: containerWidth,
    totalHeight: Infinity,
    fits: true,
    scaleFactor: 1,
    efficiency: 0
  };

  const maxScale = maxScaleFactor;
  
  // Try different column counts from max to min
  for (let testColumns = Math.min(maxColumns, items.length); testColumns >= 1; testColumns--) {
    // Calculate available width for cards (subtract gaps)
    const totalGapWidth = gap * (testColumns - 1);
    const availableCardWidth = containerWidth - totalGapWidth;
    const baseCardWidth = availableCardWidth / testColumns;
    
    // Check if cards meet minimum width requirement
    if (baseCardWidth < minColumnWidth) continue;
    
    // Group items by row
    const rows = Math.ceil(items.length / testColumns);
    let totalHeight = 0;
    let fits = true;
    let needsScaling = false;
    let scaleFactor = 1;
    
    // Calculate row heights and check scaling needs
    for (let row = 0; row < rows; row++) {
      let rowHeight = 0;
      
      for (let col = 0; col < testColumns; col++) {
        const index = row * testColumns + col;
        if (index >= items.length) break;
        
        const item = items[index];
        const naturalWidth = item.width;
        
        // Check if content fits at base width
        if (naturalWidth > baseCardWidth) {
          // Content is wider than available width
          const requiredScale = naturalWidth / baseCardWidth;
          if (requiredScale <= maxScale) {
            // Can scale down (up to maxScaleFactor)
            needsScaling = true;
            scaleFactor = Math.max(scaleFactor, 1 / requiredScale);
          } else {
            // Cannot fit even with scaling
            fits = false;
            break;
          }
        }
        
        // Calculate height for this card
        const cardHeight = item.height * (baseCardWidth / naturalWidth);
        rowHeight = Math.max(rowHeight, cardHeight);
      }
      
      if (!fits) break;
      totalHeight += rowHeight + (row < rows - 1 ? gap : 0);
    }
    
    if (!fits) continue;
    
    // Calculate space utilization efficiency
    const totalCardArea = items.reduce((sum, item) => sum + (item.width * item.height), 0);
    const usedArea = baseCardWidth * totalHeight * testColumns;
    const efficiency = totalCardArea / usedArea;
    
    // Prefer layouts that use more columns and have better efficiency
    const layoutScore = testColumns * 100 + efficiency * 1000;
    const currentBestScore = bestLayout.columns * 100 + bestLayout.efficiency * 1000;
    
    if (layoutScore > currentBestScore) {
      bestLayout = {
        columns: testColumns,
        cardWidth: baseCardWidth,
        totalHeight,
        fits: true,
        scaleFactor: needsScaling ? scaleFactor : 1,
        efficiency
      };
    }
  }

  return bestLayout;
};
