import type { Tariff } from '../types/tariff';

export const mockTariffs: Tariff[] = [
  {
    name: 'Базовый',
    description: 'Стандартный тариф для всех пользователей',
    basePricePerKwh: 30,
    rules: [],
    sessionLimits: {
      maxTime: 0,
      maxEnergy: 0,
    },
    createdAt: '2024-11-15',
    updatedAt: '2025-01-01',
    isActive: true,
  },
  {
    name: 'Премиум',
    description: 'Приоритетная зарядка',
    basePricePerKwh: 45,
    rules: [
      {
        id: 'rule1',
        days: [0, 1, 2, 3, 4], // Пн-Пт
        startTime: '08:00',
        endTime: '12:00',
        pricePerKwh: 50,
      },
      {
        id: 'rule2',
        days: [0, 1, 2, 3, 4], // Пн-Пт
        startTime: '17:00',
        endTime: '21:00',
        pricePerKwh: 55,
      },
    ],
    sessionLimits: {
      maxTime: 120,
      maxEnergy: 50,
    },
    createdAt: '2024-12-01',
    updatedAt: '2025-01-03',
    isActive: true,
  },
  {
    name: 'Ночной',
    description: 'Экономичный тариф с 23:00 до 07:00',
    basePricePerKwh: 18,
    rules: [
      {
        id: 'rule3',
        days: 'all',
        startTime: '23:00',
        endTime: '07:00',
        pricePerKwh: 15,
      },
    ],
    sessionLimits: {
      maxTime: 0,
      maxEnergy: 0,
    },
    createdAt: '2024-12-10',
    updatedAt: '2025-01-02',
    isActive: true,
  },
  {
    name: 'Пиковый',
    description: 'Тариф с динамическим ценообразованием в зависимости от времени суток и дня недели',
    basePricePerKwh: 35,
    rules: [
      {
        id: 'rule4',
        days: [0, 1, 2, 3, 4], // Пн-Пт
        startTime: '08:00',
        endTime: '12:00',
        pricePerKwh: 45,
      },
      {
        id: 'rule5',
        days: [0, 1, 2, 3, 4], // Пн-Пт
        startTime: '17:00',
        endTime: '21:00',
        pricePerKwh: 45,
      },
      {
        id: 'rule6',
        days: [0, 1, 2, 3, 4], // Пн-Пт
        startTime: '12:00',
        endTime: '17:00',
        pricePerKwh: 25,
      },
      {
        id: 'rule7',
        days: [5, 6], // Сб-Вс
        startTime: '00:00',
        endTime: '23:59',
        pricePerKwh: 20,
      },
    ],
    sessionLimits: {
      maxTime: 180,
      maxEnergy: 60,
    },
    createdAt: '2025-01-05',
    updatedAt: '2025-01-05',
    isActive: true,
  },
];