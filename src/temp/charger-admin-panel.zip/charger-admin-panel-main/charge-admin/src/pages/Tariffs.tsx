import React, { useState } from 'react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { TariffModal } from '../components/tariff/TariffModal';
import { useTariff } from '../contexts/useTariff';
import { TariffRuleVisualizer } from '../components/tariff/TariffRuleVisualizer';
import { useToast } from '../components/ui/useToast';
import type { Tariff, TariffFormData } from '../types/tariff';
import { 
  Zap, 
  Plus, 
  Edit,
  Trash2,
  Copy
} from 'lucide-react';

export const Tariffs: React.FC = () => {
  const { tariffs, addTariff, updateTariff, deleteTariff } = useTariff();
  const { showToast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTariff, setEditingTariff] = useState<Tariff | null>(null);

  const handleCreateTariff = () => {
    setEditingTariff(null);
    setIsModalOpen(true);
  };

  const handleEditTariff = (tariff: Tariff) => {
    setEditingTariff(tariff);
    setIsModalOpen(true);
  };

  const handleCopyTariff = (tariff: Tariff) => {
    const newTariff = {
      ...tariff,
      name: `${tariff.name} (копия)`,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    addTariff(newTariff);
    showToast(`Тариф "${tariff.name}" скопирован`, 'success');
  };

  const handleDeleteTariff = (name: string) => {
    // No confirmation dialog - immediate delete with toast notification
    deleteTariff(name);
    showToast(`Тариф "${name}" удален`, 'success');
  };

  const handleSubmitTariff = (tariffData: TariffFormData) => {
    if (editingTariff) {
      updateTariff(editingTariff.name, tariffData);
      showToast(`Тариф "${editingTariff.name}" обновлен`, 'success');
    } else {
      addTariff(tariffData);
      showToast(`Тариф "${tariffData.name}" создан`, 'success');
    }
    setIsModalOpen(false);
    setEditingTariff(null);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-ink">Тарифы</h2>
          <p className="text-muted">Управление тарифными планами и ценообразованием</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="primary" icon={Plus} onClick={handleCreateTariff}>
            Новый тариф
          </Button>
        </div>
      </div>

      {/* Tariffs list */}
      <Card className="mt-4">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {tariffs.map((tariff: Tariff) => (
              <div key={tariff.name} className="bg-bg2 border border-bg-2 rounded-lg p-4 shadow-sm">
                {/* Tariff Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-ink">{tariff.name}</h3>
                    <p className="text-sm text-muted mt-1">{tariff.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="icon" 
                      size="sm" 
                      className="p-1" 
                      onClick={() => handleEditTariff(tariff)}
                      aria-label={`Редактировать тариф ${tariff.name}`}
                    >
                      <Edit size={16} />
                    </Button>
                    <Button 
                      variant="icon" 
                      size="sm" 
                      className="p-1" 
                      onClick={() => handleCopyTariff(tariff)}
                      aria-label={`Копировать тариф ${tariff.name}`}
                    >
                      <Copy size={16} />
                    </Button>
                    <Button 
                      variant="icon" 
                      size="sm" 
                      className="p-1" 
                      onClick={() => handleDeleteTariff(tariff.name)}
                      aria-label={`Удалить тариф ${tariff.name}`}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>

                {/* Icon Row */}
                <div className="flex gap-4 mb-4">
                  <div className="flex items-center space-x-2 text-sm border-2 rounded-md px-2 py-1 shadow-sm"
                    style={{ borderColor: '#0ea5e9' }}
                  >
                    <div 
                      className="w-[1em] h-[1em] rounded-sm flex items-center justify-center"
                      style={{ backgroundColor: '#0ea5e9' }}
                    >
                      <Zap size={10} className="text-white" />
                    </div>
                    <span className="text-ink">
                      {tariff.basePricePerKwh}₽/кВч
                    </span>
                  </div>
                </div>

                {/* Session Limits */}
                <div className="bg-bg-2 rounded-lg p-3 mb-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted">Макс. время: </span>
                      <span className="font-medium text-ink">
                        {tariff.sessionLimits.maxTime > 0 ? `${tariff.sessionLimits.maxTime} мин` : 'Нет'}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted">Макс. энергия: </span>
                      <span className="font-medium text-ink">
                        {tariff.sessionLimits.maxEnergy > 0 ? `${tariff.sessionLimits.maxEnergy} кВт·ч` : 'Нет'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Rule Visualizer */}
                {tariff.rules.length > 0 && (
                  <TariffRuleVisualizer
                    rules={tariff.rules}
                    basePricePerKwh={tariff.basePricePerKwh}
                  />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tariff Modal */}
      <TariffModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTariff(null);
        }}
        onSubmit={handleSubmitTariff}
        initialData={editingTariff}
        existingNames={tariffs.filter(t => t.name !== editingTariff?.name).map(t => t.name)}
      />
    </div>
  );
};
