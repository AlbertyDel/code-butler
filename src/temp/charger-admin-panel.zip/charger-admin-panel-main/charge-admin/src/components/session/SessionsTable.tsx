import React from 'react';
import { Button } from '../ui/Button';
import { 
  Clock, 
  Zap, 
  // DollarSign, 
  Home,
  AlertTriangle,
  CreditCard,
  Calendar,
  Hash,
  MoreVertical
} from 'lucide-react';
import type { Session } from '../../data/sessions';
import { StatusBadge } from '../ui/StatusBadge';
import { HeaderCell } from '../station/HeaderCell';
import './SessionsTable.css';

interface SessionsTableProps {
  sessions: Session[];
  isCommercialMode: boolean;
  onSessionClick?: (session: Session) => void;
  onEdit?: (session: Session) => void;
  onDelete?: (id: string) => void;
}

export const SessionsTable: React.FC<SessionsTableProps> = ({
  sessions,
  isCommercialMode,
  onSessionClick,
  onEdit,
  onDelete,
}) => {
  if (sessions.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted">Сессии не найдены</p>
        <p className="text-sm text-muted mt-2">Попробуйте изменить параметры поиска или фильтры</p>
      </div>
    );
  }

  const handleSessionClick = (session: Session) => {
    if (onSessionClick) {
      onSessionClick(session);
    }
  };

  // Function to apply word count classes
  const applyWordCountClasses = () => {
    // This runs after render to apply word count classes
    setTimeout(() => {
      const table = document.querySelector('table');
      if (!table) return;
      
      // Find all text elements in station name and ID columns
      const textElements = table.querySelectorAll(`
        td.px-4:nth-child(3) > div > p.font-medium.text-ink,
        td.px-4:nth-child(2) > div.text-ink
      `);
      
      textElements.forEach(element => {
        const text = element.textContent || '';
        const isMultiWord = text.trim().includes(' ');
        element.classList.toggle('is-multiword', isMultiWord);
        element.classList.toggle('is-singleword', !isMultiWord);
      });
    }, 0);
  };

  // Apply word count classes after initial render and on updates
  React.useEffect(() => {
    applyWordCountClasses();
  }, [sessions, isCommercialMode]);

  // Mode-specific design tokens
  const modeTokens = isCommercialMode ? {
    primary: 'bg-commercial-primary-500',
    primaryHover: 'hover:bg-commercial-primary-600',
    textPrimary: 'text-commercial-text-primary',
    textSecondary: 'text-commercial-text-secondary',
    border: 'border-commercial-primary-300',
    focus: 'focus:ring-commercial-primary-300',
    cardBorder: 'border-l-commercial-primary-500',
    surface: 'bg-commercial-surface-DEFAULT',
    background: 'bg-commercial-background-DEFAULT',
    backgroundDark: 'bg-commercial-background-dark',
  } : {
    primary: 'bg-personal-primary-500',
    primaryHover: 'hover:bg-personal-primary-600',
    textPrimary: 'text-personal-text-primary',
    textSecondary: 'text-personal-text-secondary',
    border: 'border-personal-primary-200',
    focus: 'focus:ring-personal-primary-300',
    cardBorder: 'border-l-personal-primary-500',
    surface: 'bg-personal-surface-DEFAULT',
    background: 'bg-personal-background-DEFAULT',
    backgroundDark: 'bg-personal-background-dark',
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'active':
        return { type: 'success' as const, label: 'Активна' };
      case 'completed':
        return { type: 'info' as const, label: 'Завершена' };
      case 'cancelled':
        return { type: 'warning' as const, label: 'Отменена' };
      case 'failed':
        return { type: 'danger' as const, label: 'Ошибка' };
      default:
        return { type: 'info' as const, label: status };
    }
  };

  return (
    <div className={`sessions-table-container overflow-x-auto ${modeTokens.surface} border ${modeTokens.border} rounded-lg shadow-sm`}>
      <table className="min-w-full text-sm divide-y divide-bg-2" data-commercial-mode={isCommercialMode}>
        {/* Column definitions - using CSS custom properties for responsive widths */}
        <colgroup>
          {/* Status column - shrinkable */}
          <col className="status-col" />
          
          {/* Session ID column - hidden on mobile, elastic on desktop */}
          <col className="hidden sm:table-cell session-id-col" />
          
          {/* Station column - elastic */}
          <col className="station-col" />
          
          {/* Time column - hidden on mobile, elastic on desktop */}
          <col className="hidden sm:table-cell time-col" />
          
          {/* Duration column - shrinkable */}
          <col className="duration-col" />
          
          {/* Energy column - hidden on mobile, shrinkable on desktop */}
          <col className="hidden sm:table-cell energy-col" />
          
          {/* Cost column - conditional, only in commercial mode, shrinkable */}
          {isCommercialMode && (
            <col className="cost-col" />
          )}
          
          {/* Actions column - fit-content (if actions are enabled) */}
          {(onEdit || onDelete) && (
            <col className="actions-col" />
          )}
        </colgroup>
        <thead className={`${modeTokens.surface}`}>
          <tr>
            {/* Status column - AlertTriangle icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={AlertTriangle}
              text="Статус"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
            
            {/* Session ID column - hidden on mobile, Hash icon on tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Hash}
              text="ID сессии"
              showMobileIcon={false}
              showTabletIcon={true}
              showDesktopText={true}
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
              className="hidden sm:table-cell"
            />
            
            {/* Station column - Home icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Home}
              text="Станция"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
            />
            
            {/* Time column - hidden on mobile, Calendar icon on tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Calendar}
              text="Период"
              showMobileIcon={false}
              showTabletIcon={true}
              showDesktopText={true}
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="start"
              className="hidden sm:table-cell"
            />
            
            {/* Duration column - Clock icon on mobile/tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Clock}
              text="Цикл"
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="center"
              className="sm:text-center lg:text-center"
            />
            
            {/* Energy column - hidden on mobile, Zap icon on tablet, text on desktop (≥1024px) */}
            <HeaderCell
              icon={Zap}
              text="Энергия"
              showMobileIcon={false}
              showTabletIcon={true}
              showDesktopText={true}
              mobileAlign="center"
              tabletAlign="center"
              desktopAlign="center"
              className="hidden sm:table-cell sm:text-center lg:text-center"
            />
            
            {/* Cost column - CreditCard icon on mobile/tablet, text on desktop (≥1024px) (if commercial mode) */}
            {isCommercialMode && (
              <HeaderCell
                icon={CreditCard}
                text="Стоимость"
                mobileAlign="center"
                tabletAlign="center"
                desktopAlign="center"
                className="sm:text-center lg:text-center"
              />
            )}
            
            {/* Actions column - MoreVertical icon on mobile/tablet, text on desktop (≥1024px) (if actions are enabled) */}
            {(onEdit || onDelete) && (
              <HeaderCell
                icon={MoreVertical}
                text="Действия"
                mobileAlign="center"
                tabletAlign="center"
                desktopAlign="start"
              />
            )}
          </tr>
        </thead>
        <tbody className={`${modeTokens.surface} divide-y divide-bg-2`}>
          {sessions.map((session) => {
            const statusConfig = getStatusConfig(session.status);
            return (
              <tr key={session.id} className={`hover:${modeTokens.backgroundDark} transition-colors`}>
                {/* Status cell */}
                <td className="px-4 py-3">
                  <button
                    onClick={() => handleSessionClick(session)}
                    className={`focus:outline-none focus:ring-2 ${modeTokens.focus} focus:ring-offset-2 rounded`}
                    title="Показать детали сессии"
                    aria-label={`Показать детали сессии ${session.id}`}
                  >
                    <StatusBadge 
                      status={statusConfig.type} 
                      label={statusConfig.label}
                    />
                  </button>
                </td>
                
                {/* Session ID cell - hidden on mobile */}
                <td className="px-4 py-3 hidden sm:table-cell">
                  <div className="font-mono text-sm text-ink" title={session.id}>{session.id}</div>
                </td>
                
                {/* Station cell */}
                <td className="px-4 py-3">
                  <div>
                    <p className={`font-medium ${modeTokens.textPrimary}`}>{session.stationName}</p>
                    <p className={`text-sm ${modeTokens.textSecondary} font-mono hidden sm:block`}>ID: {session.stationId}</p>
                  </div>
                </td>
                
                {/* Time cell - hidden on mobile */}
                <td className="px-4 py-3 hidden sm:table-cell">
                  <div>
                    <p className={`text-sm ${modeTokens.textPrimary}`}>{session.startTime}</p>
                    {session.endTime && (
                      <p className={`text-xs ${modeTokens.textSecondary}`}>до {session.endTime}</p>
                    )}
                  </div>
                </td>
                
                {/* Duration cell */}
                <td className="px-4 py-3 sm:text-center">
                  <span className={`font-medium ${modeTokens.textPrimary}`}>{session.duration}</span>
                </td>
                
                {/* Energy cell - hidden on mobile */}
                <td className="px-4 py-3 hidden sm:table-cell sm:text-center">
                  <div className="flex items-center justify-center">
                    <Zap className="h-4 w-4 text-warning mr-1 flex-shrink-0" />
                    <span className={`font-medium ${modeTokens.textPrimary}`}>{session.energy} кВт·ч</span>
                  </div>
                </td>
                
                {/* Cost cell - only in commercial mode */}
                {isCommercialMode && (
                  <td className="px-4 py-3 sm:text-center">
                    <div className="flex items-center justify-center">
                      <span className="h-4 w-4 text-success mr-1 flex-shrink-0 font-bold" style={{ color: '#10B981' }}>₽</span>
                      <span className={`font-medium ${modeTokens.textPrimary}`}>{session.cost} ₽</span>
                    </div>
                  </td>
                )}
                
                {/* Actions cell - if actions are enabled */}
                {(onEdit || onDelete) && (
                  <td className="px-4 py-3 actions-cell">
                    <div className="actions-container">
                      {onEdit && (
                        <Button
                          variant="primary"
                          size="md"
                          onClick={() => onEdit(session)}
                          title="Редактировать"
                          aria-label={`Редактировать сессию ${session.id}`}
                          className="action-button"
                        >
                          <span className="hidden sm:inline">Редактировать</span>
                        </Button>
                      )}
                      {onDelete && (
                        <Button
                          variant="danger"
                          size="md"
                          onClick={() => onDelete(session.id)}
                          title="Удалить"
                          aria-label={`Удалить сессию ${session.id}`}
                          className="action-button"
                        >
                          <span className="hidden sm:inline">Удалить</span>
                        </Button>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
