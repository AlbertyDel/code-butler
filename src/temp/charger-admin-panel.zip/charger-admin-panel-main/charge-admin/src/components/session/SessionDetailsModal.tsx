import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import type { Session } from '../../data/sessions';
import { useMode } from '../../contexts/useMode';

interface SessionDetailsModalProps {
  session: Session | null;
  isOpen: boolean;
  onClose: () => void;
}

const getStatusConfig = (status: string) => {
  switch (status) {
    case 'active':
      return { type: 'success' as const, label: 'Активна' };
    case 'completed':
      return { type: 'info' as const, label: 'Завершена' };
    case 'cancelled':
      return { type: 'warning' as const, label: 'Отменена' };
    case 'failed':
      return { type: 'danger' as const, label: 'Ошибка' };
    default:
      return { type: 'info' as const, label: status };
  }
};

export const SessionDetailsModal: React.FC<SessionDetailsModalProps> = ({
  session,
  isOpen,
  onClose,
}) => {
  const { mode } = useMode();
  const contentAreaRef = useRef<HTMLDivElement>(null);

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  // Handle responsive modal height and scrolling
  useEffect(() => {
    if (!isOpen || !contentAreaRef.current) return;
    
    const updateModalSizes = () => {
      const isMobile = window.innerWidth < 768;
      const modalMaxHeight = isMobile ? '90vh' : '70vh';
      const contentMaxHeight = `calc(${modalMaxHeight} - 140px)`;
      
      // Update modal max-height
      const modal = document.querySelector('.modal-responsive-container');
      if (modal && modal instanceof HTMLElement) {
        modal.style.maxHeight = modalMaxHeight;
      }
      
      // Update content area
      if (contentAreaRef.current) {
        contentAreaRef.current.style.setProperty('overflow-y', 'auto', 'important');
        contentAreaRef.current.style.setProperty('max-height', contentMaxHeight, 'important');
      }
    };
    
    // Initial update
    updateModalSizes();
    
    // Update on resize
    window.addEventListener('resize', updateModalSizes);
    return () => window.removeEventListener('resize', updateModalSizes);
  }, [isOpen]);

  if (!isOpen || !session) {
    return null;
  }

  const statusConfig = getStatusConfig(session.status);
  const averageSpeed = session.endTime 
    ? (session.energy / (parseInt(session.duration) / 60)).toFixed(1)
    : '—';

  return createPortal(
    <>
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        style={{ top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Modal container - Use flexbox centering exactly like StationDetailsModal */}
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none p-4"
        style={{ top: 0, left: 0, right: 0, bottom: 0 }}
      >
        <div 
          className="modal-responsive-container w-full flex flex-col border border-bg-2 rounded-lg shadow-xl pointer-events-auto bg-white overflow-hidden"
          style={{ 
            maxHeight: '70vh',
            height: 'auto',
            minHeight: '400px',
            backgroundColor: '#FFFFFF'
          }}
          role="dialog"
          aria-labelledby="session-details-modal-title"
          aria-modal="true"
          data-mode={mode}
        >
          {/* Fixed header section */}
          <div className="flex-shrink-0">
            {/* Header */}
            <div className="border-b border-bg-2 p-6 flex items-center justify-between">
              <div>
                <h2 id="session-details-modal-title" className="text-2xl font-bold text-ink">Детали сессии</h2>
                <p className="text-muted">ID: {session.id}</p>
              </div>
              <Button
                variant="icon"
                onClick={onClose}
                className="h-10 w-10"
              >
                <X size={20} />
              </Button>
            </div>
          </div>

          {/* Scrollable content area - constrained height with proper scrolling */}
          <div 
            ref={contentAreaRef}
            className="flex-1 p-6 overflow-y-auto" 
            style={{ 
              maxHeight: 'calc(70vh - 140px)', // Will be overridden by useLayoutEffect for mobile
              overflowY: 'auto'
            }}
          >
            <div className="space-y-6">
              {/* Status and Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-muted">Статус</h3>
                    <StatusBadge status={statusConfig.type} label={statusConfig.label} size="lg" forceShowText={true} />
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted mb-2">Станция</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-ink">Название:</span>
                      <span className="font-medium text-ink text-right">{session.stationName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink">ID:</span>
                      <span className="font-medium text-ink text-right">{session.stationId}</span>
                    </div>
                  </div>
                </div>

                {mode === 'commercial' && (
                  <div>
                    <h3 className="text-sm font-medium text-muted mb-2">Пользователь</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-ink">Имя:</span>
                        <span className="font-medium text-ink text-right">{session.userName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-ink">ID:</span>
                        <span className="font-medium text-ink text-right">{session.userId}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted mb-2">Время</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-ink">Начало:</span>
                      <span className="font-medium text-ink">{session.startTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink">Окончание:</span>
                      <span className="font-medium text-ink">{session.endTime || 'В процессе'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink">Длительность:</span>
                      <span className="font-medium text-ink">{session.duration}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Energy Details */}
            <div className="bg-bg2 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-ink mb-4">Энергия</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted">Потреблено</span>
                  <span className="text-2xl font-bold text-ink">{session.energy} кВт·ч</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted">Мощность</span>
                  <span className="text-2xl font-bold text-ink">{session.power} кВт</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted">Средняя скорость</span>
                  <span className="text-2xl font-bold text-ink">{averageSpeed} кВт</span>
                </div>
              </div>
            </div>

            {/* Financial Details (Commercial Mode Only) */}
            {mode === 'commercial' && (
              <div className="bg-bg2 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-ink mb-4">Финансы</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted">Стоимость</span>
                    <span className="text-3xl font-bold text-ink">{session.cost.toLocaleString()} ₽</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted">Тариф</span>
                    <span className="text-lg font-medium text-ink">30 ₽/кВт·ч</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted">Способ оплаты</span>
                    <span className="text-lg font-medium text-ink capitalize">{session.paymentMethod}</span>
                  </div>
                  
                  {session.paymentMethod === 'карта' && session.cardNumber && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted">Номер карты</span>
                      <span className="text-lg font-medium text-ink">{session.cardNumber}</span>
                    </div>
                  )}
                  
                  {session.paymentMethod === 'кошелёк' && session.walletId && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted">ID кошелька</span>
                      <span className="text-lg font-medium text-ink">{session.walletId}</span>
                    </div>
                  )}
                  
                  {session.paymentMethod === 'QR-код' && session.qrCodeId && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted">ID QR-кода</span>
                      <span className="text-lg font-medium text-ink">{session.qrCodeId}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            </div>
          </div>

        </div>
      </div>
    </>,
    document.body
  );
};
