import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Save, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { useTariff } from '../../contexts/useTariff';
import { useMode } from '../../contexts/useMode';
import type { Station } from '../../data/stations';

// Mode-specific design tokens for StationModal
const modalTokens = {
  personal: {
    primary: 'bg-personal-primary-500',
    primaryHover: 'hover:bg-personal-primary-600',
    border: 'border-l-personal-primary-500',
    text: 'text-personal-primary-500',
    focus: 'focus:ring-personal-primary-300',
    buttonPrimary: 'bg-personal-primary-500 hover:bg-personal-primary-600',
  },
  commercial: {
    primary: 'bg-commercial-primary-500',
    primaryHover: 'hover:bg-commercial-primary-600',
    border: 'border-l-commercial-primary-500',
    text: 'text-commercial-primary-500',
    focus: 'focus:ring-commercial-primary-300',
    buttonPrimary: 'bg-commercial-primary-500 hover:bg-commercial-primary-600',
  }
};

interface StationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (station: Station) => void;
  initialData?: Station | null;
}

export const StationModal: React.FC<StationModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const { tariffs } = useTariff();
  const { mode: appMode } = useMode();
  
  // Get mode-specific tokens
  const tokens = modalTokens[appMode];
  
  const [formData, setFormData] = useState<Station>(() => {
    if (initialData) {
      return initialData;
    }
    // Generate new ID for new station
    const newId = `CHG-${Math.floor(1000 + Math.random() * 9000)}`;
    return {
      id: newId,
      name: '',
      status: 'ready' as const,
      power: 11,
      location: '',
      tariffName: tariffs.length > 0 ? tariffs[0].name : '',
      ports: 1,
      energyToday: 0,
    };
  });

  const [errors, setErrors] = useState<{
    name?: string;
    id?: string;
    location?: string;
    tariffName?: string;
  }>({});

  // Sync formData with initialData when it changes or modal opens
  useEffect(() => {
    if (!isOpen) return;
    
    // Use setTimeout to avoid synchronous setState in effect
    const timer = setTimeout(() => {
      if (initialData) {
        setFormData(initialData);
      } else {
        // Reset to default for creating new station
        const newId = `CHG-${Math.floor(1000 + Math.random() * 9000)}`;
        setFormData({
          id: newId,
          name: '',
          status: 'ready' as const,
          power: 11,
          location: '',
          tariffName: tariffs.length > 0 ? tariffs[0].name : '',
          ports: 1,
          energyToday: 0,
        });
      }
      // Reset errors when modal opens
      setErrors({});
    }, 0);
    
    return () => clearTimeout(timer);
  }, [initialData, tariffs, isOpen]);

  // Open/close dialog based on isOpen prop
  useEffect(() => {
    if (!dialogRef.current) return;
    
    if (isOpen) {
      dialogRef.current.showModal();
    } else {
      dialogRef.current.close();
    }
  }, [isOpen]);

  // Handle click on backdrop to close
  const handleBackdropClick = (e: React.MouseEvent<HTMLDialogElement>) => {
    if (e.target === dialogRef.current) {
      onClose();
    }
  };

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const validateForm = (): boolean => {
    const newErrors: typeof errors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Название станции обязательно';
    } else if (formData.name.length > 100) {
      newErrors.name = 'Название не должно превышать 100 символов';
    }

    if (!formData.id.trim()) {
      newErrors.id = 'Введите ID станции';
    } else if (formData.id.length !== 8) {
      newErrors.id = 'Неверный формат';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Локация обязательна';
    }

    // In commercial mode, tariff is required
    if (appMode === 'commercial' && !formData.tariffName?.trim()) {
      newErrors.tariffName = 'Выберите тариф для станции';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
      onClose();
    }
  };

  if (!isOpen) {
    return null;
  }

  return createPortal(
    <dialog
      ref={dialogRef}
      onClick={handleBackdropClick}
      className="fixed inset-0 z-50 flex items-center justify-center bg-transparent border-0 shadow-none charge-dialog-override"
      aria-labelledby="station-modal-title"
    >
      {/* Single container with solid background - TRANSPARENCY FIX */}
      <div 
        className={`modal-responsive-container w-full max-w-2xl flex-shrink-0 h-auto border-l-4 ${tokens.border} border border-bg-2 rounded-lg shadow-xl max-h-[calc(100vh-4rem)] overflow-visible p-4`}
        style={{ backgroundColor: '#FFFFFF' }} // Using design system color directly
        data-mode={appMode}
      >
        {/* Header */}
        <div className="border-b border-bg-2 p-6 flex items-center justify-between">
          <h2 id="station-modal-title" className="text-2xl font-bold text-ink">
            {initialData ? 'Редактировать станцию' : 'Создать новую станцию'}
          </h2>
          <Button variant="icon" onClick={onClose}>
            <X size={24} />
          </Button>
        </div>

        {/* Form content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="relative">
            <label htmlFor="station-name" className="block text-sm font-medium text-muted mb-2">
              Название станции *
            </label>
            <input
              id="station-name"
              name="station-name"
              type="text"
              maxLength={100}
              className={`w-full bg-bg-2 border ${errors.name ? 'border-[#EF4444]' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand box-border`}
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Введите название станции"
            />
            {errors.name && (
              <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                <div className="bg-[#EF4444] text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative" style={{ color: '#FFFFFF' }}>
                  <AlertCircle size={14} className="flex-shrink-0" style={{ color: '#FFFFFF' }} />
                  <span>{errors.name}</span>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-[#EF4444]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="relative">
            <label htmlFor="station-id" className="block text-sm font-medium text-muted mb-2">
              ID станции
            </label>
            <input
              id="station-id"
              name="station-id"
              type="text"
              maxLength={8}
              readOnly={!!initialData}
              className={`w-full ${initialData ? 'bg-bg-1 cursor-not-allowed' : 'bg-bg-2'} border ${errors.id ? 'border-[#EF4444]' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand box-border`}
              value={formData.id}
              onChange={(e) => setFormData({ ...formData, id: e.target.value })}
              placeholder="CHG-XXXX"
            />
            {errors.id && (
              <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                <div className="bg-[#EF4444] text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative" style={{ color: '#FFFFFF' }}>
                  <AlertCircle size={14} className="flex-shrink-0" style={{ color: '#FFFFFF' }} />
                  <span>{errors.id}</span>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-[#EF4444]"></div>
                </div>
              </div>
            )}
            <p className="mt-1 text-xs text-muted">Ровно 8 символов (например: CHG-1000)</p>
          </div>

          <div className="relative">
            <label htmlFor="station-location" className="block text-sm font-medium text-muted mb-2">
              Локация *
            </label>
            <input
              id="station-location"
              name="station-location"
              type="text"
              className={`w-full bg-bg-2 border ${errors.location ? 'border-[#EF4444]' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand box-border`}
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder="Введите адрес станции"
            />
            {errors.location && (
              <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                <div className="bg-[#EF4444] text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative" style={{ color: '#FFFFFF' }}>
                  <AlertCircle size={14} className="flex-shrink-0" style={{ color: '#FFFFFF' }} />
                  <span>{errors.location}</span>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-[#EF4444]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="station-power" className="block text-sm font-medium text-muted mb-2">
                Мощность (кВт) *
              </label>
              <select
                id="station-power"
                name="station-power"
                className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                value={formData.power}
                onChange={(e) => setFormData({ ...formData, power: Number(e.target.value) })}
              >
                <option value="7">7 кВт</option>
                <option value="11">11 кВт</option>
                <option value="22">22 кВт</option>
              </select>
            </div>

            <div>
              <label htmlFor="station-ports" className="block text-sm font-medium text-muted mb-2">
                Количество портов *
              </label>
              <select
                id="station-ports"
                name="station-ports"
                className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
                value={formData.ports}
                onChange={(e) => setFormData({ ...formData, ports: Number(e.target.value) })}
              >
                <option value="1">1 порт</option>
                <option value="2">2 порта</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="station-status" className="block text-sm font-medium text-muted mb-2">
              Статус *
            </label>
            <select
              id="station-status"
              name="station-status"
              className="w-full bg-bg-2 border border-bg-1 rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as Station['status'] })}
            >
              <option value="ready">Готова</option>
              <option value="charging">Заряжает</option>
              <option value="offline">Оффлайн</option>
              <option value="pending">Ожидание</option>
              <option value="fault">Неисправность</option>
            </select>
          </div>

          {/* Tariff selection (only in commercial mode) */}
          {appMode === 'commercial' && (
            <div className="relative">
              <label htmlFor="station-tariff" className="block text-sm font-medium text-muted mb-2">
                Тариф *
              </label>
              <select
                id="station-tariff"
                name="station-tariff"
                className={`w-full bg-bg-2 border ${errors.tariffName ? 'border-[#EF4444]' : 'border-bg-1'} rounded-lg px-4 py-2 text-ink focus:outline-none focus:ring-2 focus:ring-brand box-border`}
                value={formData.tariffName || ''}
                onChange={(e) => setFormData({ ...formData, tariffName: e.target.value })}
              >
                <option value="">Выберите тариф</option>
                {tariffs.map((tariff) => (
                  <option key={tariff.name} value={tariff.name}>
                    {tariff.name}
                  </option>
                ))}
              </select>
              {errors.tariffName && (
                <div className="absolute z-50" style={{ top: '22px', left: '50%', transform: 'translate(-50%, -100%)' }}>
                  <div className="bg-[#EF4444] text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 whitespace-nowrap relative" style={{ color: '#FFFFFF' }}>
                    <AlertCircle size={14} className="flex-shrink-0" style={{ color: '#FFFFFF' }} />
                    <span>{errors.tariffName}</span>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-[#EF4444]"></div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Buttons */}
          <div className="pt-4 border-t border-bg-2 flex justify-end space-x-4">
            <Button variant="secondary" onClick={onClose} icon={X} type="button">
              Отмена
            </Button>
            <Button variant="primary" type="submit" icon={Save}>
              Сохранить
            </Button>
          </div>
        </form>
      </div>
    </dialog>,
    document.body
  );
};
