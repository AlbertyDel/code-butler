# CHARGE_admin Project Analysis

## 1. Project Overview

CHARGE_admin is a React-based admin dashboard for managing electric vehicle charging stations, built with TypeScript and Vite. It implements a dual-mode architecture supporting personal and commercial operation modes.

**Key Characteristics:**
- **Dual-Mode Architecture**: Supports both "personal" and "commercial" operation modes
- **Responsive Design**: Fully responsive layouts for desktop and mobile devices
- **Modern Tech Stack**: React 19, TypeScript, Tailwind CSS, Vite
- **Local-First Data**: Uses localStorage for data persistence with mock data fallback
- **Comprehensive Feature Set**: Station management, session tracking, tariff pricing, financial operations, and user profile management

**Primary Use Cases:**
1. **Personal Mode**: Individual EV station owners managing their own charging infrastructure
2. **Commercial Mode**: Commercial operators managing multiple stations with complex pricing, financial reporting, and organizational features

## 2. Technology Stack

### Core Framework & Tools
- **React 19.2.0** with TypeScript for type-safe development
- **Vite 7.2.5** (Rolldown-based) for fast builds and development server
- **Tailwind CSS 4.1.18** with PostCSS for utility-first styling
- **ESLint** with TypeScript rules for code quality enforcement

### Key Dependencies
- **State Management**: React Context API for domain-specific state (ModeContext, UserContext, TariffContext, FinanceContext)
- **Routing**: React Router DOM v7.11.0 for client-side navigation with lazy loading and protected routes
- **UI Components**: Lucide React as the primary icon library with custom UI components (Button, Card, StatusBadge, Skeleton) built with Tailwind CSS
- **Charts**: Recharts for data visualization in the Dashboard and EnergyChart component
- **Mock Data**: @faker-js/faker with Russian locale for deterministic mock data generation in `src/data/` modules
- **LocalStorage Persistence**: Custom `usePersistentData` hook and context-based persistence for all major data domains

### Development Setup
- **TypeScript**: Configured with separate `tsconfig.app.json` and `tsconfig.node.json`
- **PostCSS**: With Autoprefixer for CSS processing
- **ESLint**: Configured for React Hooks and TypeScript rules
- **Package Management**: npm with scripts for development, building, and preview

## 3. Project Architecture

### Directory Structure
```
charge-admin/
├── src/
│   ├── components/        # Reusable UI components
│   │   ├── layout/       # Layout components (ResponsiveLayout, DesktopLayout, MobileLayout)
│   │   ├── station/      # Station-related components
│   │   │   ├── StationCard.tsx     # Card component for displaying a station in grid layout
│   │   │   ├── StationModal.tsx    # Modal wrapper for station create/edit forms
│   │   │   ├── StationForm.tsx     # Form component for creating/editing stations
│   │   │   ├── StationDetailView.tsx # Detailed station information view
│   │   │   ├── InlineStationForm.tsx # Inline form for station creation
│   │   │   ├── InlineStationEditForm.tsx # Inline form for station editing
│   │   │   ├── StationsTable.tsx   # Table component for displaying stations
│   │   │   └── StationTableRow.tsx # Table row component for stations
│   │   ├── tariff/       # Tariff management components
│   │   │   ├── TariffForm.tsx      # Form for creating/editing tariffs
│   │   │   ├── TariffModal.tsx     # Modal wrapper for tariff forms
│   │   │   └── TariffRuleVisualizer.tsx # Visual representation of tariff rules
│   │   └── ui/           # Base UI components
│   │       ├── Button.tsx    # Button component with variants
│   │       ├── Card.tsx      # Card container component
│   │       ├── EnergyChart.tsx # Chart component using Recharts
│   │       ├── MetricCard.tsx # Metric card for dashboard KPIs
│   │       ├── Skeleton.tsx  # Loading skeleton component
│   │       └── StatusBadge.tsx # Status badge with color coding
│   ├── contexts/         # React Context providers
│   │   ├── ModeContext.tsx    # Personal/Commercial mode management
│   │   ├── UserContext.tsx    # User profile management with localStorage
│   │   ├── TariffContext.tsx  # Tariff management with CRUD operations
│   │   └── FinanceContext.tsx # Financial operations, balance, withdrawals, subscriptions
│   ├── pages/            # Route pages (6 main pages)
│   │   ├── Dashboard.tsx   # Dual-mode dashboard with KPI cards and charts
│   │   ├── Stations.tsx    # Station management page using modal forms
│   │   ├── Sessions.tsx    # Session history and monitoring
│   │   ├── Tariffs.tsx     # Tariff management with collapsible inline form
│   │   ├── Finance.tsx     # Financial operations and reports (commercial only)
│   │   └── Profile.tsx     # User profile with vertical tabs
│   ├── types/            # TypeScript type definitions
│   │   ├── tariff.ts     # Tariff interfaces (Tariff, TariffRule, SessionLimits)
│   │   └── finance.ts    # Finance interfaces (FinancialOperation, WithdrawalRequest, etc.)
│   ├── hooks/            # Custom React hooks
│   │   ├── useMediaQuery.ts   # Media query hook for responsive design
│   │   └── usePersistentData.ts # Hook for localStorage-backed state
│   ├── utils/            # Utility functions
│   │   ├── cn.ts         # Classname utility (Tailwind CSS class merging)
│   │   └── resetLocalStorage.ts # Utility to reset localStorage data
│   └── data/             # Deterministic mock data modules
│       ├── stations.ts    # Default station list with Faker-generated Russian names
│       ├── tariffs.ts     # Default tariffs with pricing rules
│       ├── sessions.ts    # Default charging sessions
│       ├── finance.ts     # Default finance data (balance, operations)
│       ├── dashboard.ts   # KPI metrics for dashboard
│       ├── user.ts        # Default user profile data
│       └── index.ts       # Aggregated exports for convenience
├── public/               # Static assets (vite.svg)
├── package.json          # Dependencies and scripts
├── vite.config.ts       # Vite configuration with React plugin
├── tailwind.config.cjs  # Tailwind CSS configuration with custom colors
├── tsconfig.json        # TypeScript base configuration
├── tsconfig.app.json    # TypeScript configuration for app (React)
├── tsconfig.node.json   # TypeScript configuration for Node (build tools)
└── README.md            # Project documentation
```

### Key Architectural Patterns

**Dual-Mode Architecture:**
The application supports both "personal" and "commercial" modes via `ModeContext`. The mode affects:
- **UI/UX**: Different dashboard layouts, KPI cards, and available pages
- **Access Control**: Protected routes for "Тарифы" (Tariffs) and "Финансы" (Finance) pages (only accessible in commercial mode)
- **Navigation**: Filtered navigation items in both `DesktopLayout` and `MobileLayout`
- **Data Display**: Conditional rendering of columns (e.g., cost column in Sessions table only in commercial mode)

**Context-Based State Management:**
Four main contexts provide global state with localStorage persistence:
- **ModeContext**: Manages current mode (personal/commercial) without localStorage persistence
- **UserContext**: Manages user profile data with full CRUD operations and localStorage key `'userData'`
- **TariffContext**: Manages tariff data with complex validation (rule overlap, time ranges) and localStorage key `'charge_admin_tariffs'`
- **FinanceContext**: Manages financial data (balance, operations, withdrawal requests, subscriptions) with localStorage key `'charge_admin_finance'`

**Responsive Design System:**
- **Layout Components**: `ResponsiveLayout` automatically switches between `DesktopLayout` (sidebar navigation) and `MobileLayout` (bottom navigation) based on screen size
- **Tailwind CSS**: Custom design tokens for consistent styling across components
- **Media Queries**: `useMediaQuery` hook for conditional rendering based on breakpoints
- **Mobile-First**: All components designed mobile-first with responsive breakpoints

**Component-Based Architecture:**
- **Reusable UI Components**: Base components (Button, Card, StatusBadge) with consistent variants
- **Feature Components**: Domain-specific components (StationForm, TariffForm, TariffRuleVisualizer)
- **Layout Components**: Separate layout implementations for desktop and mobile with shared navigation logic
- **Page Components**: Each route corresponds to a page component with specific functionality

## 4. Core Features

### 4.1 Dashboard (Dashboard.tsx)
**Dual-mode display**: Different KPIs and station overviews based on mode. The dashboard uses mock data (`mockStations`, `mockEnergyData`) for demonstration.

**Commercial Mode:**
- **KPIs**: 4 metric cards with icons (Battery, Clock, Zap, DollarSign): "Active Stations" (8, +2), "Today's Sessions" (24, +5), "Energy (kWh)" (1,248, +312), "Revenue (RUB)" (45,620, +8,240)
- **Energy Chart**: Weekly energy consumption visualization using Recharts
- **Stations Table**: Table with 7 columns: Status, Device ID/Name, Tariff, Power (kW), Sessions, Location, Actions
- **Actions**: "Start"/"Stop" buttons with conditional display based on station status (Stop for 'charging', Start for other statuses). Buttons log to console as placeholders.

**Personal Mode:**
- **My Stations**: Card-based display (up to 3 stations) with detailed information: power, sessions today, location. Each card has "Start"/"Stop" buttons.
- **Quick Stats**: Two cards: "Today's Charging" (42 kWh with Zap icon), "Charging Time" (3h 42min with Clock icon)
- **Energy Chart**: Personal energy consumption visualization using Recharts
- **Real-time Connection**: Status card showing "Real-time connection active" with green indicator and StatusBadge "Connected"

**Technical Implementation Details:**
- Uses `useMode` hook to determine current mode and conditionally render content
- All data is mock data (no API integration)
- Responsive grid layouts using Tailwind CSS (`grid-cols-1 md:grid-cols-2 lg:grid-cols-4`)
- Components: Card, Button, StatusBadge, StationStatusBadge, MetricCard, EnergyChart
- Russian language labels throughout (e.g., "Панель управления", "Станции", "Добавить станцию")

### 4.2 Station Management (Stations.tsx)
**Table-based Layout**: Stations are displayed in a table using the `StationsTable` component.
**Data Persistence**: Station data is persisted via the `usePersistentData` hook with localStorage. The `normalizeStations` function ensures data consistency (power: 7, 11, or 22 kW; ports: 1 or 2; default tariff name).
**Status Badges**: Five statuses (charging, ready, offline, pending, fault) with visual indicators via `StationStatusBadge`.
**Modal Forms**: Station creation and editing use modal forms (`StationModal`) with `StationForm` component.
**Individual Actions**: Edit and delete per station with confirmation. No bulk operations.
**Mode-Specific Features**: Commercial mode shows "Add Station" button; personal mode shows only station list.
**Technical Implementation**:
  - Uses `usePersistentData` hook for localStorage persistence with initial data from `defaultStations` in `src/data/stations.ts`
  - `normalizeStations` function corrects invalid power and port values and adds default tariff names
  - Russian language labels throughout (e.g., "Станции", "Добавить станцию")
  - Components: `StationsTable`, `StationModal`, `StationForm`, `Card`, `Button`

### 4.3 Tariff Management (Tariffs.tsx)
**Card-based Layout**: Tariffs are displayed in a responsive grid of cards (2 columns on large screens, 1 on mobile).
**Search Functionality**: Real-time search by tariff name or description.
**Collapsible Form**: Inline `TariffForm` component with expandable/collapsible design for creating/editing tariffs.
**Four Demo Tariffs** (from `mockTariffs` in `TariffContext`):
  1. **Basic**: Simple tariff with no rules, base price 30 ₽/kWh
  2. **Premium**: 2 rules for weekday peak hours, session limits (120 min, 50 kWh)
  3. **Night**: 1 rule for all days (23:00-07:00 at 15 ₽/kWh)
  4. **Peak**: 4 rules demonstrating complex pricing with session limits (180 min, 60 kWh)
**Tariff Card Details**: Each card displays:
  - Name and description
  - Base price per kWh with Zap icon
  - Number of rules with Calendar icon
  - Session limits (max time and energy)
  - Created and updated dates
  - Action buttons: Edit, Copy, Delete, Expand/Collapse
**Rule Visualization**: Expanded view shows `TariffRuleVisualizer` component with detailed time-based rule breakdown.
**Data Management**: Uses `TariffContext` with localStorage persistence (`'charge_admin_tariffs'` key).
**Validation**: Form includes validation for tariff name uniqueness, rule time ranges, and overlapping rules.
**Technical Implementation**:
  - Uses `useTariff` hook for CRUD operations (addTariff, updateTariff, deleteTariff)
  - `TariffForm` handles both create and edit modes with initial data
  - `TariffRuleVisualizer` provides visual representation of time-based pricing rules
  - Russian language labels throughout (e.g., "Тарифы", "Новый тариф", "Поиск тарифов")

### 4.4 Finance Management (Finance.tsx) - Commercial Only
**Balance Management**: Current balance display with currency formatting
**Operations History**: Table of financial operations with status badges
**Withdrawal Requests**: Form for creating withdrawal requests with balance validation
**Subscription Management**: Current subscription details and plan selection modal
**Access Control**: Only accessible in commercial mode with dedicated "Access Denied" UI for personal mode

### 4.5 User Profile Management (Profile.tsx)
**Vertical Tab Layout**: Account, Company, Contacts, Security tabs in vertical navigation
**Mode-Specific Tabs**: Company and Contacts tabs only visible in commercial mode
**Form Editing**: Edit user profile, organization details, and contact persons
**Data Persistence**: User data saved to localStorage via `UserContext`

### 4.6 Sessions Management (Sessions.tsx)
**Session History Table**: Columns: Session ID, Station, Time, Duration, Energy, Cost (commercial only), Status, Details
**Mode-Based Display**: Cost column and payment/tariff details only shown in commercial mode
**Expanded Details**: Collapsible section showing session details (power, payment method, tariff, average speed)
**Statistics Overview**: Cards for Total Sessions, Active, Energy, Revenue (commercial only)
**Simplified UI**: Removed user column, "New Report" button, and simplified action column to single chevron

### 4.7 Navigation & Layout
**Responsive Layout**: `ResponsiveLayout` switches between desktop and mobile layouts
**Protected Routes**: `ProtectedRoute` component restricts access to /tariffs and /finance routes
**Mode-Aware Navigation**: Navigation items filtered based on current mode
**Access Control**: Seamless redirection to dashboard when accessing restricted pages

## 5. Data Flow & State Management

### Context Providers Architecture
The application uses four React Contexts for state management:

1. **ModeContext** (`src/contexts/ModeContext.tsx`):
   - Purpose: Manages application mode (personal/commercial)
   - State: `mode: 'personal' | 'commercial'`
   - Persistence: No localStorage persistence
   - Hook: `useMode()` returns `{ mode, setMode }`
   - Impact: Controls UI rendering, navigation filtering, and page access

2. **UserContext** (`src/contexts/UserContext.tsx`):
   - Purpose: Manages user profile and organization data
   - State: `UserData` with personal and commercial fields
   - Persistence: localStorage key `'userData'`
   - Hook: `useUser()` returns `{ userData, updateUserData }`

3. **TariffContext** (`src/contexts/TariffContext.tsx`):
   - Purpose: Manages charging tariffs with complex pricing rules
   - State: `tariffs: Tariff[]`, `defaultBasePrice: number`
   - Persistence: localStorage keys `'charge_admin_tariffs'` and `'charge_admin_default_price'`
   - Hook: `useTariff()` returns CRUD methods: `addTariff`, `updateTariff`, `deleteTariff`, `setDefaultBasePrice`, `getTariffByName`

4. **FinanceContext** (`src/contexts/FinanceContext.tsx`):
   - Purpose: Manages financial operations, balance, withdrawals, and subscriptions
   - State: `FinanceData` with balance, operations, withdrawalRequests, currentSubscription, availablePlans
   - Persistence: localStorage key `'charge_admin_finance'`
   - Hook: `useFinance()` returns methods: `updateBalance`, `addOperation`, `addWithdrawalRequest`, `updateSubscription`, `updateWithdrawalStatus`

### Data Persistence Strategy
**LocalStorage Integration**:
- Each context saves to localStorage when state changes
- Keys are prefixed with `'charge_admin_'` for namespace separation
- On initialization, each context attempts to parse saved data and falls back to mock defaults

**usePersistentData Hook**:
- Custom hook `usePersistentData<T>(key, initialData)` in `src/hooks/usePersistentData.ts`
- Wraps `useState`, initializing from localStorage with fallback to initialData
- Automatically persists updates to localStorage

**Mock Data Fallback**:
- `TariffContext`: `mockTariffs` with 4 demonstration tariffs
- `UserContext`: `defaultUserData` with sample user profile
- `FinanceContext`: `initialData` with sample balance, operations, and subscription plans

### State Update Patterns
- **Immutability**: All context updates use functional updates with spread operators
- **Validation**: Context methods include validation (e.g., checking balance before withdrawal)
- **Timestamps**: Automatic `createdAt` and `updatedAt` management for tariff changes
- **ID Generation**: Contexts generate unique IDs for operations, withdrawal requests, and tariff rules

## 6. Styling System

### Tailwind Configuration
Custom color palette with semantic names defined in `tailwind.config.cjs`:
- `brand`: Primary brand color (green) with variants: DEFAULT (#12B76A), light (#D1FADF), dark (#0E9957), hover (#49C584), active (#2E8E5F)
- `info` (#2E90FA), `warning` (#F79009), `success` (#039855), `error` (#EF4444)
- Text and background tokens: `ink` (#101828) for primary text, `muted` (#667085) for secondary text, `bg1` (#F9FAFB) for main background, `bg2` (#FFFFFF) for card background
- Legacy colors for backward compatibility: `bg-0`, `bg-1`, `bg-2`, `danger`

### Component Variants
- **Button**: `primary`, `secondary`, `ghost`, `icon` variants
- **Card**: `default`, `filled` variants
- **StatusBadge**: `success`, `warning`, `error`, `info`, `neutral` statuses
- **StationStatusBadge**: `charging`, `ready`, `offline`, `pending`, `fault` statuses

### Theme Implementation
- **Light Theme**: Bright, professional light theme with custom CSS variables in `src/index.css`
- **Custom CSS Variables**: All design tokens available as CSS custom properties for consistency
- **Responsive Design**: Mobile-first responsive utilities with Tailwind breakpoints
- **Table Styling**: Striped rows and hover effects for improved readability

## 7. Development Workflow

### Available Scripts
- `npm run dev`: Starts development server on `localhost:5173`, killing any existing process on port 5173 first
- `npm run build`: Builds for production to `dist/` directory (TypeScript compilation + Vite build)
- `npm run lint`: Runs ESLint for code quality checks
- `npm run preview`: Previews production build locally

### Build Configuration
- **Vite 7.2.5 (Rolldown-based)**: Fast development server and optimized production builds
- **TypeScript**: Separate configurations for app (`tsconfig.app.json`) and build tools (`tsconfig.node.json`) with strict type checking
- **Tailwind CSS 4.1.18**: Utility-first CSS with PostCSS and Autoprefixer for vendor prefixes
- **Asset Optimization**: Images and assets optimized during build

## 8. Current Issues & Solutions

### 1. Code Quality Linting Issues
The project has several ESLint errors that need to be addressed for better code quality and maintainability:
- **Unexpected any type** in `MobileLayout.tsx` (line 29:57): Using `any` type reduces type safety.
- **setState in useEffect** in `InlineStationEditForm.tsx` (line 32:5): Synchronous state updates within effects can cause cascading renders and performance issues.
- **Variable accessed before declaration** in `StationForm.tsx` (line 48:19): The variable `tariffs` is used before it is declared, which can lead to stale data.

**Impact**: These issues do not break the application but affect code quality and potential performance.

### 2. No Critical Runtime Issues
The application builds and runs without critical errors. All core features are functional.

## 9. Current Project Status

### Foundation
- **React + TypeScript foundation** with Vite and Tailwind CSS
- **Context-based state management** with localStorage persistence
- **React Router** with 6 main pages and protected routes for mode-based access control

### UI/UX Implementation
- **Dual-mode architecture** with access control for commercial-only pages (Tariffs, Finance)
- **Table-based station management** with modal forms for create/edit
- **Card-based tariff management** with collapsible inline form
- **Vertical tab profile page** with mode-specific tabs (Company, Contacts in commercial mode)
- **Simplified interfaces** without bulk operations

### Feature Completeness
- **Dashboard** with dual-mode KPI cards and energy charts
- **Station management** with create, edit, delete operations
- **Tariff management** with complex rule system and validation
- **Financial operations** for commercial mode (balance, withdrawals, subscriptions)
- **Session tracking** with mode-based display of cost and tariff details
- **User profile management** with personal and commercial fields

### Data Management
- **Mock data** for initial visualization, with localStorage persistence
- **Data persistence** across all contexts (User, Tariff, Finance) and station data via custom hook
- **Fallback to mock data** when localStorage is empty

### Code Quality
- **Well-organized codebase** with clear separation of concerns
- **TypeScript types** for all major data structures
- **ESLint errors present** (any types, setState in effects, variable access before declaration) but no critical runtime errors
- **Responsive components** with Tailwind CSS

### Development Readiness
- **Project builds successfully** with `npm run build`
- **Development server** runs without errors on `localhost:5173`
- **Linting configured** but with existing errors that need addressing
- **Production builds** optimized by Vite

### Key Implementation Patterns
1. **ProtectedRoute component** for mode-based access control
2. **Conditional UI rendering** based on mode (personal/commercial)
3. **LocalStorage persistence** with mock data fallback
4. **Responsive design system** with mobile-first approach

This project is well-architected and ready for further development. The dual-mode approach makes it suitable for both individual station owners and commercial operators, with a clean, professional interface that can be extended with additional features as needed.

**Future Consideration**: The current implementation uses localStorage and mock data for visual development. This is a temporary solution that will be replaced with backend integration in future versions.

