module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Base design system colors (shared between modes)
        brand: {
          DEFAULT: '#4F46E5',  // Indigo primary
          light: '#EEF2FF',    // Indigo-50
          dark: '#3730A3',     // Indigo-800
          hover: '#6366F1',    // Indigo-500
          active: '#4338CA',   // Indigo-700
        },
        info: '#2E90FA',       // blue accent (kept for info messages)
        warning: '#F59E0B',    // Amber
        success: '#10B981',    // Emerald
        error: '#EF4444',      // Red
        muted: '#6B7280',      // Gray-500
        ink: '#1F2937',        // Gray-900
        bg1: '#F9FAFB',        // main page background
        bg2: '#FFFFFF',        // card background
        
        // Legacy colors for backward compatibility
        "bg-0": "#F6F8FA",
        "bg-1": "#FFFFFF",
        "bg-2": "#F2F4F7",
        danger: "#EF4444",     // alias for error
        
        // Personal Mode Colors (Modern & Playful - matches CSS variables)
        personal: {
          primary: {
            50: '#F5F3FF',
            100: '#EDE9FE',
            200: '#DDD6FE',
            300: '#C4B5FD',
            400: '#A78BFA',
            500: '#8B5CF6',    // Vibrant purple - matches CSS var --mode-primary
            600: '#7C3AED',
            700: '#6D28D9',
            800: '#5B21B6',
            900: '#4C1D95',
          },
          secondary: {
            50: '#FFFBEB',
            100: '#FEF3C7',
            200: '#FDE68A',
            300: '#FCD34D',
            400: '#FBBF24',
            500: '#F59E0B',    // Amber/orange - matches CSS var --mode-secondary
            600: '#D97706',
            700: '#B45309',
            800: '#92400E',
            900: '#78350F',
          },
          background: {
            light: '#F8FAFC',
            DEFAULT: '#F1F5F9',
            dark: '#E2E8F0',
          },
          surface: {
            light: '#FFFFFF',
            DEFAULT: '#F8FAFC',
            dark: '#F1F5F9',
          },
          text: {
            primary: '#1E293B',
            secondary: '#475569',
            muted: '#64748B',
          }
        },
        
        // Commercial Mode Colors (Professional & Vibrant - matches CSS variables)
        commercial: {
          primary: {
            50: '#EEF2FF',
            100: '#E0E7FF',
            200: '#C7D2FE',
            300: '#A5B4FC',
            400: '#818CF8',
            500: '#4F46E5',    // Vibrant indigo - matches CSS var --mode-primary
            600: '#4338CA',
            700: '#3730A3',
            800: '#312E81',
            900: '#1E1B4B',
          },
          secondary: {
            50: '#D1FAE5',
            100: '#A7F3D0',
            200: '#6EE7B7',
            300: '#34D399',
            400: '#10B981',    // Emerald green - matches CSS var --mode-secondary
            500: '#10B981',
            600: '#059669',
            700: '#047857',
            800: '#065F46',
            900: '#064E3B',
          },
          accent: {
            50: '#EFF6FF',
            100: '#DBEAFE',
            200: '#BFDBFE',
            300: '#93C5FD',
            400: '#60A5FA',
            500: '#3B82F6',    // Blue accent for data highlights
            600: '#2563EB',
            700: '#1D4ED8',
            800: '#1E40AF',
            900: '#1E3A8A',
          },
          background: {
            light: '#FFFFFF',
            DEFAULT: '#F9FAFB',
            dark: '#F3F4F6',
          },
          surface: {
            light: '#FFFFFF',
            DEFAULT: '#FFFFFF',
            dark: '#F9FAFB',
          },
          text: {
            primary: '#111827',
            secondary: '#374151',
            muted: '#6B7280',
          }
        }
      },
      
      // Typography Scale
      fontSize: {
        'display-lg': ['3rem', { lineHeight: '1.1', fontWeight: '800', letterSpacing: '-0.02em' }],
        'display-md': ['2.25rem', { lineHeight: '1.2', fontWeight: '700', letterSpacing: '-0.01em' }],
        'display-sm': ['1.875rem', { lineHeight: '1.3', fontWeight: '700', letterSpacing: '-0.01em' }],
        'heading-lg': ['1.5rem', { lineHeight: '1.4', fontWeight: '600', letterSpacing: '-0.01em' }],
        'heading-md': ['1.25rem', { lineHeight: '1.5', fontWeight: '600' }],
        'heading-sm': ['1.125rem', { lineHeight: '1.6', fontWeight: '600' }],
        'body-lg': ['1.125rem', { lineHeight: '1.7', fontWeight: '400' }],
        'body-md': ['1rem', { lineHeight: '1.7', fontWeight: '400' }],
        'body-sm': ['0.875rem', { lineHeight: '1.7', fontWeight: '400' }],
        'caption': ['0.75rem', { lineHeight: '1.7', fontWeight: '400', letterSpacing: '0.01em' }],
        'code': ['0.875rem', { lineHeight: '1.5', fontWeight: '400', fontFamily: 'monospace' }],
      },
      
      // Font Weight Scale
      fontWeight: {
        'thin': '100',
        'extralight': '200',
        'light': '300',
        'normal': '400',
        'medium': '500',
        'semibold': '600',
        'bold': '700',
        'extrabold': '800',
        'black': '900',
      },
      
      // Letter Spacing Scale
      letterSpacing: {
        'tighter': '-0.05em',
        'tight': '-0.025em',
        'normal': '0',
        'wide': '0.025em',
        'wider': '0.05em',
        'widest': '0.1em',
      },
      
      // Enhanced Spacing Scale
      spacing: {
        '0.5': '0.125rem',
        '1.5': '0.375rem',
        '2.5': '0.625rem',
        '3.5': '0.875rem',
        '4.5': '1.125rem',
        '5.5': '1.375rem',
        '6.5': '1.625rem',
        '7.5': '1.875rem',
        '8.5': '2.125rem',
        '9.5': '2.375rem',
        '10.5': '2.625rem',
        '11.5': '2.875rem',
        '12.5': '3.125rem',
        '13.5': '3.375rem',
        '14.5': '3.625rem',
        '15.5': '3.875rem',
      },
      
      // Border Radius Scale
      borderRadius: {
        'none': '0',
        'sm': '0.125rem',
        'DEFAULT': '0.375rem',
        'md': '0.5rem',
        'lg': '0.75rem',
        'xl': '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
        'full': '9999px',
      },
      
      // Animation Utilities
      animation: {
        'spin-slow': 'spin 2s linear infinite',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'shimmer': 'shimmer 2s infinite',
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
        'bounce-subtle': 'bounceSubtle 0.6s ease-in-out',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        bounceSubtle: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
      
      // Shadow & Elevation Tokens
      boxShadow: {
        'xs': '0 1px 2px 0 rgb(0 0 0 / 0.05)',
        'sm': '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
        'DEFAULT': '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
        'md': '0 6px 10px -1px rgb(0 0 0 / 0.1), 0 4px 6px -2px rgb(0 0 0 / 0.1)',
        'lg': '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
        'xl': '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
        '2xl': '0 25px 50px -12px rgb(0 0 0 / 0.25)',
        'inner': 'inset 0 2px 4px 0 rgb(0 0 0 / 0.05)',
        'personal': '0 10px 25px -5px rgba(139, 92, 246, 0.1), 0 10px 10px -5px rgba(139, 92, 246, 0.04)',
        'commercial': '0 4px 14px 0 rgba(79, 70, 229, 0.1)',
        'none': 'none',
      },
      
      // Border Width Scale
      borderWidth: {
        '0': '0',
        '1': '1px',
        '2': '2px',
        '3': '3px',
        '4': '4px',
        '8': '8px',
      },
      
      // Opacity Scale
      opacity: {
        '0': '0',
        '5': '0.05',
        '10': '0.1',
        '15': '0.15',
        '20': '0.2',
        '25': '0.25',
        '30': '0.3',
        '35': '0.35',
        '40': '0.4',
        '45': '0.45',
        '50': '0.5',
        '55': '0.55',
        '60': '0.6',
        '65': '0.65',
        '70': '0.7',
        '75': '0.75',
        '80': '0.8',
        '85': '0.85',
        '90': '0.9',
        '95': '0.95',
        '100': '1',
      },
      
      // Gradient Definitions
      backgroundImage: {
        'gradient-personal': 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)',
        'gradient-commercial': 'linear-gradient(135deg, #4F46E5 0%, #10B981 100%)',
        'gradient-subtle': 'linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%)',
        'gradient-card': 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)',
        'gradient-overlay': 'linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.1) 100%)',
      },
      
      // Z-Index Scale
      zIndex: {
        '0': '0',
        '10': '10',
        '20': '20',
        '30': '30',
        '40': '40',
        '50': '50',
        'auto': 'auto',
      },
      
      fontFamily: {
        sans: ["Segoe UI", "Tahoma", "Geneva", "Verdana", "sans-serif"],
        mono: ["monospace"],
      },
      screens: {
        'xs': {'max': '399px'}, // Custom breakpoint for very small screens
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
      },
    },
  },
  plugins: [],
}
