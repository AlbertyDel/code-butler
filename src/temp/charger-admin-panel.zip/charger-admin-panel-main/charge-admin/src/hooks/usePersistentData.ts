import { useEffect, useState } from 'react';

/**
 * A simple hook for persisting data in localStorage.
 * When the data changes, it serializes and saves to localStorage under the provided key.
 * If no saved data exists, it uses the provided initialData.
 */
export function usePersistentData<T>(key: string, initialData: T): [T, (newData: T) => void] {
  const [data, setData] = useState<T>(() => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initialData;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(data));
  }, [key, data]);

  return [data, setData];
}