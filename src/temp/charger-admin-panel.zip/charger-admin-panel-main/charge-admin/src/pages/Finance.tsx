import React, { useState } from 'react';
import { Card, CardHeader, CardContent, CardFooter } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { useMode } from '../contexts/useMode';
import { useFinance } from '../contexts/useFinance';
import { formatCurrency, getStatusBadgeVariant } from '../types/finance';
import { DollarSign, CreditCard, Banknote, Calendar, CheckCircle, XCircle } from 'lucide-react';

// Компонент вкладок
const TabButton: React.FC<{
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}> = ({ active, onClick, children }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
      active
        ? 'bg-brand text-white'
        : 'text-muted hover:text-ink hover:bg-bg-2'
    }`}
  >
    {children}
  </button>
);

// Виджет текущего баланса
const BalanceWidget: React.FC<{ balance: number }> = ({ balance }) => (
  <Card variant="filled" className="mb-6">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Текущий баланс</p>
          <p className="text-4xl font-bold text-ink">{formatCurrency(balance)}</p>
          <p className="text-sm text-muted mt-2">Доступно для вывода</p>
        </div>
        <div className="h-16 w-16 rounded-full bg-brand/10 flex items-center justify-center">
          <DollarSign className="h-8 w-8 text-brand" />
        </div>
      </div>
    </CardContent>
  </Card>
);

// Вкладка "Операции"
const OperationsTab: React.FC = () => {
  const { operations } = useFinance();

  return (
    <Card>
      <CardHeader
        title="История операций"
        description="Все начисления и списания"
      />
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-bg-2">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted">Дата</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted">Тип операции</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted">Сумма</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted">Статус</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted">Детали</th>
              </tr>
            </thead>
            <tbody>
              {operations.map((operation) => (
                <tr key={operation.id} className="border-b border-bg-2 hover:bg-bg-1">
                  <td className="py-3 px-4">
                    <span className="text-sm text-ink">{operation.date}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-ink">{operation.type}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-medium ${operation.amount >= 0 ? 'text-brand' : 'text-error'}`}>
                      {operation.amount >= 0 ? '+' : ''}{formatCurrency(operation.amount)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <StatusBadge
                      status={getStatusBadgeVariant(operation.status)}
                      label={operation.status === 'completed' ? 'Завершено' : 
                             operation.status === 'pending' ? 'В обработке' : 'Ошибка'}
                    />
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-muted">{operation.details}</span>
                    {operation.sessionId && (
                      <p className="text-xs text-muted mt-1">ID: {operation.sessionId}</p>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
      <CardFooter align="center">
        <Button variant="ghost">Загрузить больше</Button>
      </CardFooter>
    </Card>
  );
};

// Вкладка "Вывод средств"
const WithdrawalTab: React.FC = () => {
  const { balance, withdrawalRequests, addWithdrawalRequest } = useFinance();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'банковская карта' | 'расчетный счет'>('банковская карта');
  const [details, setDetails] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('Введите корректную сумму');
      return;
    }

    if (numAmount > balance) {
      setError('Запрашиваемая сумма превышает доступный баланс');
      return;
    }

    if (!details.trim()) {
      setError('Введите реквизиты');
      return;
    }

    try {
      addWithdrawalRequest(numAmount, method, details);
      setAmount('');
      setDetails('');
      setError('');
      alert('Заявка на вывод успешно создана!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader
          title="Запрос выплаты"
          description="Заполните форму для вывода средств"
        />
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <div className="mb-2">
                <div className="text-sm text-brand font-medium bg-brand/5 px-3 py-1 rounded-md mb-1 inline-block">
                  Доступно: {formatCurrency(balance)}
                </div>
                <label className="block text-sm font-semibold text-ink">
                  Сумма к выводу
                </label>
              </div>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-4 py-2 border border-bg-2 rounded-lg bg-bg-1 text-ink focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                placeholder="Введите сумму"
                min="1"
                max={balance}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-ink mb-2">
                Способ получения
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setMethod('банковская карта')}
                  className={`p-4 border rounded-lg flex flex-col items-center justify-center space-y-2 transition-colors ${
                    method === 'банковская карта'
                      ? 'border-brand bg-brand/5'
                      : 'border-bg-2 hover:border-brand'
                  }`}
                >
                  <CreditCard className="h-6 w-6 text-ink" />
                  <span className="text-sm font-medium">Банковская карта</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMethod('расчетный счет')}
                  className={`p-4 border rounded-lg flex flex-col items-center justify-center space-y-2 transition-colors ${
                    method === 'расчетный счет'
                      ? 'border-brand bg-brand/5'
                      : 'border-bg-2 hover:border-brand'
                  }`}
                >
                  <Banknote className="h-6 w-6 text-ink" />
                  <span className="text-sm font-medium">Расчетный счет</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-ink mb-2">
                Реквизиты
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full px-4 py-2 border border-bg-2 rounded-lg bg-bg-1 text-ink focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                placeholder={
                  method === 'банковская карта'
                    ? 'Номер карты (например: 1234 5678 9012 3456)'
                    : 'Реквизиты расчетного счета'
                }
                rows={3}
              />
            </div>

            {error && (
              <div className="p-3 bg-error/10 border border-error/20 rounded-lg">
                <p className="text-sm text-error">{error}</p>
              </div>
            )}

            <Button type="submit" className="w-full" icon={DollarSign}>
              Заказать выплату
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader
          title="История заявок"
          description="Ваши предыдущие запросы на вывод"
        />
        <CardContent>
          {withdrawalRequests.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted">Нет заявок на вывод</p>
            </div>
          ) : (
            <div className="space-y-4">
              {withdrawalRequests.map((request) => (
                <div
                  key={request.id}
                  className="p-4 border border-bg-2 rounded-lg hover:bg-bg-1"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <p className="font-medium text-ink">{formatCurrency(-request.amount)}</p>
                      <p className="text-sm text-muted">{request.method}</p>
                    </div>
                    <StatusBadge
                      status={getStatusBadgeVariant(request.status)}
                      label={
                        request.status === 'completed' ? 'Выполнено' :
                        request.status === 'processing' ? 'В обработке' :
                        request.status === 'pending' ? 'Ожидает' : 'Отклонено'
                      }
                    />
                  </div>
                  <p className="text-sm text-muted mb-2">{request.details}</p>
                  <div className="flex items-center justify-between text-xs text-muted">
                    <span>Создано: {request.createdAt}</span>
                    {request.completedAt && <span>Завершено: {request.completedAt}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

// Вкладка "Подписка"
const SubscriptionTab: React.FC = () => {
  const { currentSubscription, availablePlans, updateSubscription } = useFinance();
  const { mode } = useMode();
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <Card>
        <CardHeader
          title="Текущая подписка"
          description="Информация о вашем тарифном плане"
        />
        <CardContent>
          <div className="space-y-6">
            <div className="p-6 border border-bg-2 rounded-lg bg-bg-1">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-ink">{currentSubscription.name}</h3>
                  <p className="text-muted">{currentSubscription.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-ink">{formatCurrency(currentSubscription.price)}</p>
                  <p className="text-sm text-muted">в месяц</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-medium text-ink mb-3">Включено:</h4>
                <ul className="space-y-2">
                  {currentSubscription.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-brand mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-bg-2">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-muted mr-2" />
                  <div>
                    <p className="text-sm font-medium text-ink">Следующее списание</p>
                    <p className="text-sm text-muted">{currentSubscription.nextChargeDate}</p>
                  </div>
                </div>
                <Button onClick={() => setShowModal(true)}>
                  Изменить подписку
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Модальное окно выбора подписки */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className={`w-full max-w-2xl bg-mode-surface border border-mode-border rounded-lg shadow-xl max-h-[90vh] overflow-y-auto`} data-mode={mode}>
            {/* Header */}
            <div className="border-b border-bg-2 p-6 flex items-center justify-between">
              <h3 className="text-2xl font-bold text-ink">Выбор тарифного плана</h3>
              <button
                onClick={() => setShowModal(false)}
                className="inline-flex items-center justify-center font-medium transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transform-gpu origin-center will-change-transform motion-reduce:transition-none motion-reduce:transform-none p-2 hover:bg-mode-surface-alt active:bg-mode-surface active:scale-[0.95] transition-all duration-200 ease-out p-3 min-w-[44px] min-h-[44px] rounded-lg"
              >
                <XCircle className="h-6 w-6 text-ink" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {availablePlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`p-6 border rounded-lg ${
                      plan.id === currentSubscription.id
                        ? 'border-brand bg-brand/5'
                        : 'border-bg-2 hover:border-brand'
                    }`}
                  >
                    <div className="mb-4">
                      <h4 className="text-lg font-bold text-ink">{plan.name}</h4>
                      <p className="text-muted text-sm">{plan.description}</p>
                    </div>

                    <div className="mb-6">
                      <p className="text-3xl font-bold text-ink mb-2">
                        {formatCurrency(plan.price)}
                        <span className="text-sm font-normal text-muted">/месяц</span>
                      </p>
                    </div>

                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start text-sm">
                          <CheckCircle className="h-4 w-4 text-brand mr-2 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Button
                      variant={plan.id === currentSubscription.id ? 'primary' : 'secondary'}
                      className="w-full"
                      onClick={() => {
                        updateSubscription(plan.id);
                        setShowModal(false);
                        alert(`Подписка изменена на "${plan.name}"`);
                      }}
                      disabled={plan.id === currentSubscription.id}
                    >
                      {plan.id === currentSubscription.id ? 'Текущий план' : 'Выбрать'}
                    </Button>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="pt-4 border-t border-bg-2 flex justify-end">
                <Button variant="secondary" onClick={() => setShowModal(false)}>
                  Отмена
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export const Finance: React.FC = () => {
  const { mode } = useMode();
  const { balance } = useFinance();
  const [activeTab, setActiveTab] = useState<'operations' | 'withdrawal' | 'subscription'>('operations');

  // Если режим не коммерческий, показываем сообщение
  if (mode !== 'commercial') {
    return (
      <div className="space-y-6 max-w-7xl mx-auto w-full">
        <div className="flex items-center justify-between">
          <div>
            {/* Larger heading for better hierarchy */}
            <h2 className="text-3xl font-bold text-ink">Финансовая аналитика</h2>
            <p className="text-muted">Управление финансами и аналитика доходов</p>
          </div>
        </div>
        <div className="bg-bg-2 rounded-lg p-12 text-center">
          <div className="max-w-md mx-auto">
            <div className="h-16 w-16 rounded-full bg-bg-1 flex items-center justify-center mx-auto mb-6">
              <span className="text-2xl">🔒</span>
            </div>
            <h3 className="text-xl font-bold text-ink mb-2">Доступ ограничен</h3>
            <p className="text-muted mb-6">
              Финансовый модуль доступен только в коммерческом режиме.
              Переключитесь в коммерческий режим для доступа к финансовой аналитике.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full">
      {/* Заголовок */}
      <div className="flex items-center justify-between">
        <div>
          {/* Increase heading size */}
          <h2 className="text-3xl font-bold text-ink">Финансовая аналитика</h2>
          <p className="text-muted">Управление финансами и аналитика доходов</p>
        </div>
      </div>

      {/* Виджет баланса */}
      <BalanceWidget balance={balance} />

      {/* Вкладки */}
      <div className="flex space-x-2 border-b border-bg-2 pb-2">
        <TabButton
          active={activeTab === 'operations'}
          onClick={() => setActiveTab('operations')}
        >
          Операции
        </TabButton>
        <TabButton
          active={activeTab === 'withdrawal'}
          onClick={() => setActiveTab('withdrawal')}
        >
          Вывод средств
        </TabButton>
        <TabButton
          active={activeTab === 'subscription'}
          onClick={() => setActiveTab('subscription')}
        >
          Подписка
        </TabButton>
      </div>

      {/* Контент вкладок */}
      <div className="pt-4">
        {activeTab === 'operations' && <OperationsTab />}
        {activeTab === 'withdrawal' && <WithdrawalTab />}
        {activeTab === 'subscription' && <SubscriptionTab />}
      </div>
    </div>
  );
};
